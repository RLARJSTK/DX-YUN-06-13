#pragma once
class Pilde
{
};

