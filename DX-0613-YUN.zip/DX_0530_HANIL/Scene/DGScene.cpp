#include "framework.h"
#include "DGScene.h"

DGScene::DGScene()
{
	//_arin = make_shared<Texture>(L"Resource/ARIN.png");
	_pilde = make_shared<Texture>(L"Resource/PILDE.png");

	_worldBuffer = make_shared<MatrixBuffer>();
}

DGScene::~DGScene()
{
}

void DGScene::Update()
{
	//if (GetAsyncKeyState(VK_LEFT))
	//{
	//	_arin->GetPos().x -= 5.0f;
	//}
	//if (GetAsyncKeyState(VK_RIGHT))
	//{
	//	_arin->GetPos().x += 5.0f;
	//}
	_worldBuffer->Update();
	//_arin->Update();
	_pilde->Update();
}

void DGScene::Render()
{
	_worldBuffer->SetVSBuffer(0);


	//_arin->Render();
	_pilde->Render();
}
