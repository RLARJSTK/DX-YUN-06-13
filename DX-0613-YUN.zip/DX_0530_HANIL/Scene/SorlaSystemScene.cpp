#include "framework.h"
#include "SorlaSystemScene.h"

SorlaSystemScene::SorlaSystemScene()
{
	_texture1 = make_shared<Texture>(L"Resource/SUN.png");
	_texture2 = make_shared<Texture>(L"Resource/EARTH.png");
	_texture3 = make_shared<Texture>(L"Resource/MOON.png");
	_texture2->GetPos().x = 350;
	_texture2->GetScale().x *= 0.5f;
	_texture2->GetScale().y *= 0.5f;
	_texture3->GetPos().x = 450;
	_texture3->GetScale().x *= 0.5f;
	_texture3->GetScale().y *= 0.5f;
	_texture2->SetParent(_texture1->GetMatrix());
	_texture3->SetParent(_texture2->GetMatrix());
}

SorlaSystemScene::~SorlaSystemScene()
{
}

void SorlaSystemScene::Update()
{
	_texture1->GetAnagle()+= 0.001f;
	_texture2->GetAnagle()+= 0.001f;
	_texture3->GetAnagle()+= 0.001f;
	_texture1->Update();
	_texture2->Update();
	_texture3->Update();
}

void SorlaSystemScene::Render()
{
	_texture1->Render();
	_texture2->Render();
	_texture3->Render();
}
