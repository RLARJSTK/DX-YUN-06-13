#include "framework.h"
#include "Arin.h"

Arin::Arin()
{
	
}

Arin::~Arin()
{
}

void Arin::Update()
{
}

void Arin::Render()
{

}
