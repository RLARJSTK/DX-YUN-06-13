#pragma once
class Arin
{
public:
	Arin();
	~Arin();
	void Update();
	void Render();

private:
};