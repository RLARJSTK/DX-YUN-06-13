#pragma once
class Bullet
{
};

