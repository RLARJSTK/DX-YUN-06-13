#pragma once

#define WIN_WIDTH 1280
#define WIN_HEIGHT 720

#define DEVICE Device::GetInstance()->GetDevice()
#define DEVICE_CONTEXT Device::GetInstance()->GetDeviceContext()
#define DELTA_TIME Timer::GetInstance()->GetDeltaTime()
#define KEY_PRESS(k) InputManager::GetInstance()->Press(k)
#define KEY_DOWN(k) InputManager::GetInstance()->Down(k)
#define KEY_UP(k) InputManager::GetInstance()->Up(k) 
#define MOUSE_POS InputManager::GetInstance()->GetMousePos()
#define SAMPLER_MANGER StateManger::GetInstance()->GetSamplerState->SetState()
#define ALPHA_MANGER StateManger::GetInstance()->GetAlphaState()->SetState()
#define ADDITIVE_MANGER StateManger::GetInstance()->GetAdditiveState()->SetState()
#define BLEND_MANGER StateManger::GetInstance()->GetBlendState()->SetState()
#define RESTERIZER_MANGER StateManger::GetInstance()->GetResterizerState()->SetState()