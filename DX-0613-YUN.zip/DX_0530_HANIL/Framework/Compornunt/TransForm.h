#pragma once
//class TransForm
//{
//public:
//	TransForm();
//	~TransForm();
//    void UpdateWorldBuffer();
//    void SetWorldBuffer(int slot=0);
//    XMFLOAT2& GetPos() { return _pos; }
//    XMFLOAT2& GetScale() { return _scale; }
//    float& GetAnagle() { return _angle; }
//    XMMATRIX* GetMatrix() { return &_srt_Matrix; }
//    void SetParent(XMMATRIX* matrix) { _parentMatrix = matrix; }
//private:
//
//
//    XMFLOAT2 _scale = { 1,1 };
//    float _angle = { 0.0f };
//    XMFLOAT2 _pos = { 0,0 };
//    XMMATRIX _srt_Matrix;
//    XMMATRIX* _parentMatrix = nullptr;
//    shared_ptr<MatrixBuffer> _worldBuffer;
//};
