#include "framework.h"
#include "TransForm.h"

//TransForm::TransForm()
//{
//
//	_worldBuffer = make_shared<MatrixBuffer>();
//}
//
//TransForm::~TransForm()
//{
//}
//
//void TransForm::UpdateWorldBuffer()
//{  
//    XMMATRIX s = XMMatrixScaling(_scale.x, _scale.y, 1);
//    XMMATRIX r = XMMatrixRotationZ(_angle);
//    XMMATRIX t = XMMatrixTranslation(_pos.x, _pos.y, 0);
//
//    _srt_Matrix = s * r * t;
//    if (_parentMatrix != nullptr)
//        _srt_Matrix *= (*_parentMatrix);
//
//    _worldBuffer->SetMatrix(_srt_Matrix);
//
//    _worldBuffer->Update();
//}
//
//void TransForm::SetWorldBuffer(int slot = 0)
//{
//}



