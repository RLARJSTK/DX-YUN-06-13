#pragma once
class StateManger
{
private:
	StateManger();
	~StateManger();
public:
	static void Create()
	{
		if (_instance == nullptr)
			_instance = new StateManger();
	}
	static void Delete()
	{
		if (_instance != nullptr)
		{
			delete _instance;
		}
	}

	static StateManger* GetInstance()
	{
		if (_instance != nullptr)
			return _instance;

		return nullptr;
	}
	shared_ptr<SamplerState> GetSamplerState() { return _samplerState;}
	shared_ptr<BlendState> GetAlphaState() { return _alphaState; }
	shared_ptr<BlendState> GetAdditiveState() { return _additiveState; }
	shared_ptr<BlendState> GetBlendState() { return _blendState; }
	shared_ptr<BlendState> GetBlendState() { return _blendState; }
	shared_ptr<RasterizerState> GetResterizerState() { return _rasterizerState; }
private:
	static StateManger* _instance;
	shared_ptr<SamplerState> _samplerState;
	shared_ptr<BlendState>   _alphaState;
	shared_ptr<BlendState>   _additiveState;
	shared_ptr<BlendState>   _blendState;
	shared_ptr<RasterizerState > _rasterizerState;
	
};