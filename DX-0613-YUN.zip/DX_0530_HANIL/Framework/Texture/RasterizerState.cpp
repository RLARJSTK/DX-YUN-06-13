#include "framework.h"
#include "RasterizerState.h"
#include <d3d12.h>
#include <d3d11_3.h>

RasterizerState::RasterizerState()
{
	_desc.CullMode = D3D11_CULL_NONE;
	_desc.FillMode = D3D11_FILL_SOLID;

	Changed();
}

RasterizerState::~RasterizerState()
{
}

void RasterizerState::Changed()
{
	if (_rasterizerState != nullptr)
		_rasterizerState->Release();

	DEVICE->CreateRasterizerState(&_desc, _rasterizerState.GetAddressOf());

}
