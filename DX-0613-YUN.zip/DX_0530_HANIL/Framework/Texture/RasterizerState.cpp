#include "framework.h"
#include "RasterizerState.h"
#include <d3d12.h>
#include <d3d11_3.h>

RasterizerState::RasterizerState()
{
	_desc.CullMode
}

RasterizerState::~RasterizerState()
{
}

void RasterizerState::SetState()
{
}

void RasterizerState::Changed()
{
}
