#include "framework.h"
#include "BlendState.h"

BlendState::BlendState()
{
	_blendDesc.AlphaToCoverageEnable = true;
	_blendDesc.IndependentBlendEnable = true;
		_blendDesc.RenderTarget[0];
		_blendDesc.RenderTarget[0];
		_blendDesc.RenderTarget[0];
		_blendDesc.RenderTarget[0];
		_blendDesc.RenderTarget[0];
		_blendDesc.RenderTarget[0];
		_blendDesc.RenderTarget[0];
		_blendDesc.RenderTarget[0];
		Changed();
}

BlendState::~BlendState()
{
}

void BlendState::SetState()
{
	float blendFactor[] = { 0,0,0,0 };
	DEVICE_CONTEXT->OMSetBlendState(_state.Get(), blendFactor, 0xfffffff);
}

void BlendState::Alpha()
{
	//_blendDesc.RenderTarget[0]
	//	1_blendDesc.RenderTarget[0]
	//	2_blendDesc.RenderTarget[0]
	//	3_blendDesc.RenderTarget[0]
	Changed();
}

void BlendState::Additive()
{
	//_blendDesc.RenderTarget[0]
	//	1_blendDesc.RenderTarget[0]
	//	_blendDesc.RenderTarget[0]
	//	3_blendDesc.RenderTarget[0]
	Changed();
}

void BlendState::Changed()
{
	if (_state != nullptr)
		_state->Release();
	DEVICE->CreateBlendState(&_blendDesc, _state.GetAddressOf());
}

