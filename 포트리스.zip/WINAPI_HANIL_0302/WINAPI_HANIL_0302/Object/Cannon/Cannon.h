#pragma once
class Cannon
{
public:
	Cannon();
	~Cannon();

	void Update();
	void Render(HDC hdc);

	shared_ptr<CircleCollider> GetBody() { return _body; }
	shared_ptr<Line> GetBarrel() { return _barrel; }
	float& GetBarrelAngle() { return _barrelAngle; }

	void Fire();
	bool BulletHit(shared_ptr<Cannon> cannon);

	bool _isActive = true;
private:
	shared_ptr<CircleCollider> _body;
	shared_ptr<Line> _barrel;
	shared_ptr<Bullet> _bullet;

	float _fireSpeed = 5.0f;
	float _barrelAngle = 0.0f;
};

