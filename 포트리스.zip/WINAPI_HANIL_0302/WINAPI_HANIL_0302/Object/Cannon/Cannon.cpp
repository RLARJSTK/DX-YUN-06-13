#include "Framework.h"
#include "Cannon.h"

Cannon::Cannon()
{
	_body = make_shared<CircleCollider>(80, Vector2(CENTER_X, CENTER_Y));
	_barrel = make_shared<Line>();
	_barrel->_startPos = _body->GetCenter();
	_barrel->_endPos = Vector2(_body->_center._x + 150, _body->_center._y);

	_bullet = make_shared<Bullet>();
	_bullet->_isActive = false;
}

Cannon::~Cannon()
{
}

void Cannon::Update()
{
	if (_isActive == false)
		return;

	// ��������
	_barrel->_startPos = _body->_center;
	_barrel->_endPos._x = _barrel->_startPos._x + cos(_barrelAngle) * 150;
	_barrel->_endPos._y = _barrel->_startPos._y + sin(_barrelAngle) * 150;

	_body->Update();
	_barrel->Update();
	_bullet->Update();
}

void Cannon::Render(HDC hdc)
{
	if (_isActive == false)
		return;

	_body->Render(hdc);
	_barrel->Render(hdc);
	_bullet->Render(hdc);
}

void Cannon::Fire()
{
	if (_isActive == false)
		return;

	_bullet->_isActive = true;
	Vector2 fireVector = _barrel->_endPos - _barrel->_startPos;
	_bullet->Fire(fireVector, _fireSpeed, _barrel->_endPos);
}

bool Cannon::BulletHit(shared_ptr<Cannon> cannon)
{
	if (_isActive == false || cannon->_isActive == false)
		return false;

	if (_bullet->IsCollision(cannon))
	{
		_bullet->_isActive = false;
		return true;
	}

	return false;
}
