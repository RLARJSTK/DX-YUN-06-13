#include "Framework.h"
#include "PotrisScene.h"

PotrisScene::PotrisScene()
{
	_cannon1 = make_shared<Cannon>();
	_cannon2 = make_shared<Cannon>();  // ������ǰ���ũ�� ����   �߽ɿ��� X���̵� Y���̵�
	_rectCol1 = make_shared<RectCollider>(Vector2(550.0f, 30.0f), Vector2(10.0f, 30.0f));                                  
	_rectCol2 = make_shared<RectCollider>(Vector2(530.0f, 30.0f), Vector2(30.0f, 100.0f));
	_rectCol3 = make_shared<RectCollider>(Vector2(300.0f, 30.0f), Vector2(1000.0f, 30.0f));
	_rectCol4 = make_shared<RectCollider>(Vector2(300.0f, 30.0f), Vector2(1000.0f, 100.0f));
}

PotrisScene::~PotrisScene()
{
	
}

void PotrisScene::Update()
{
		// �¿�� ������
	if (GetAsyncKeyState(VK_LEFT))
	{
		_cannon1->GetBody()->_center -= Vector2(1.0f, 0.0f) * 1.5f;
	}

	if (GetAsyncKeyState(VK_RIGHT))
	{
		_cannon1->GetBody()->_center += Vector2(1.0f, 0.0f) * 1.5f;
	}

	if (GetAsyncKeyState(VK_UP))
	{
		_cannon1->GetBarrelAngle() -= 0.1f;
	}

	if (GetAsyncKeyState(VK_DOWN))
	{
		_cannon1->GetBarrelAngle() += 0.1f;
	}

	if (GetAsyncKeyState(VK_SPACE))
	{
		_cannon1->Fire();
	}

	if (GetAsyncKeyState(VK_NUMPAD4))
	{
		_cannon2->GetBody()->_center -= Vector2(1.0f, 0.0f) * 1.5f;
	}

	if (GetAsyncKeyState(VK_NUMPAD6))
	{
		_cannon2->GetBody()->_center += Vector2(1.0f, 0.0f) * 1.5f;
	}

	if (GetAsyncKeyState(VK_NUMPAD8))
	{
		_cannon2->GetBarrelAngle() -= 0.1f;
	}

	if (GetAsyncKeyState(VK_NUMPAD2))
	{
		_cannon2->GetBarrelAngle() += 0.1f;
	}

	if (GetAsyncKeyState(VK_NUMPAD5))
	{
		_cannon2->Fire();
	}
	//VK_        0x60
	// 
	// 
	// ���� ĳ��1�� �߻��� �ҷ��� ĳ��2�� �浹������ ĳ��2 isActive ����.

	// 1. ĳ��1�� �ҷ��� �����´�.

	// 2. ĳ��1���� �ҷ����� ĳ��2�� �浹�ϰ� �ϰ�
	//		ĳ��1���� ĳ��2�� �˷��ش�.
	if (_cannon1->BulletHit(_cannon2))
	{
		_cannon2->_isActive = false;
		_rectCol3->_isActive = false;
		_rectCol4->_isActive = false;
	}

	if (_cannon2->BulletHit(_cannon1))
	{
		_cannon1->_isActive = false;
		_rectCol3->_isActive = false;
		_rectCol4->_isActive = false;
	}
	_cannon1->Update();
	_cannon2->Update();
	_rectCol1->Update();
	_rectCol2->Update();
	_rectCol3->Update();
	_rectCol4->Update();
}

void PotrisScene::Render(HDC hdc)
{
	_cannon1->Render(hdc);
	_cannon2->Render(hdc);
	_rectCol1->Render(hdc);
	_rectCol2->Render(hdc);
	_rectCol3->Render(hdc);
	_rectCol4->Render(hdc);
	
}
