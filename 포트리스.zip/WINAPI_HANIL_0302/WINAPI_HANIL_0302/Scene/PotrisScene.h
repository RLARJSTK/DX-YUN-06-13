#pragma once
class PotrisScene : public Scene
{
public:
	PotrisScene();
	virtual ~PotrisScene();

	virtual void Update() override;
	virtual void Render(HDC hdc) override;

private:
	shared_ptr<Cannon> _cannon1;
	shared_ptr<Cannon> _cannon2;
	shared_ptr<Collider> _rectCol1;
	shared_ptr<Collider> _rectCol2;
	shared_ptr<Collider> _rectCol3;
	shared_ptr<Collider> _rectCol4;
	// ����
	// 1. ĳ�� class �ۼ�
	// 2. bullet class �ۼ�
	
};

