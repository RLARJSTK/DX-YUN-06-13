#include "Framework.h"
#include "Program.h"

#include "../Scene/PaintScene.h"
#include "../Scene/LineScene.h"
#include "../Scene/PotrisScene.h"

Program::Program()
{
	_scene = make_shared<PotrisScene>();
}

Program::Program(HWND hWnd)
{
	_scene = make_shared<PotrisScene>();
}

Program::~Program()
{
}

void Program::Update()
{
	_scene->Update();
}

void Program::Render(HDC hdc)
{
	_scene->Render(hdc);
}
