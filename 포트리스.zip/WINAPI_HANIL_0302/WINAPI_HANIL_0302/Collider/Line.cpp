#include "Framework.h"
#include "Line.h"

Line::Line()
{
}

Line::~Line()
{
}

void Line::Update()
{
}

void Line::Render(HDC hdc)
{
	MoveToEx(hdc, _startPos._x, _startPos._y, nullptr);
	LineTo(hdc, _endPos._x, _endPos._y);
}

bool Line::IsCollision(shared_ptr<Line> line)
{
	// ���� ���̿� �ֳ� Between
	Vector2 AStoBS = line->_startPos - _startPos;
	Vector2 AStoBE = line->_endPos - _startPos;

	Vector2 AVec = _endPos - _startPos;

	float between1 = AVec.Cross(AStoBS) * AVec.Cross(AStoBE);

	// ���� ���̿� �ֳ� Between
	Vector2 BStoAS = _startPos - line->_startPos;
	Vector2 BStoAE = _endPos - line->_startPos;

	Vector2 BVec = line->_endPos - line->_startPos;

	float between2 = BVec.Cross(BStoAS) * BVec.Cross(BStoAE);

	// ���̿� �ִ�.
	if (between1 < 0.0f && between2 < 0.0f)
		return true;

	return false;
}
