#include "Framework.h"
#include "Collider.h"

Collider::Collider()
{
	_pens.push_back(CreatePen(PS_SOLID, 3, RGB(0, 255, 0)));
	_pens.push_back(CreatePen(PS_SOLID, 3, RGB(255, 0, 0)));
}

Collider::~Collider()
{
	for (auto& pen : _pens)
		DeleteObject(pen);
}

void Collider::Render(HDC hdc)
{
	// ���� ����
	if (_color)
		SelectObject(hdc, _pens[1]);
	else
		SelectObject(hdc, _pens[0]);
}

bool Collider::IsCollision(Collider& col) const
{
	switch (col._type)
	{
	case ColType::CIRCLE:
	{
		if (this->IsCollision(dynamic_cast<CircleCollider&>(col)))
			return true;
		break;
	}

	case ColType::RECT:
	{
		if (this->IsCollision(dynamic_cast<RectCollider&>(col)))
			return true;
		break;
	}

	default:
		break;
	}

	return false;
}

void Collider::SetRedColor()
{
	_color = true;
}

void Collider::SetGreenColor()
{
	_color = false;
}
