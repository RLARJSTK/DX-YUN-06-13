#pragma once
class CircleCollider : public Collider
{
public:
	CircleCollider();
	CircleCollider(float radius, const Vector2& center);
	virtual ~CircleCollider();

	void SetCircle(float radius, const Vector2& center)
	{
		_radius = radius;
		_center = center;
	}

	virtual void Update() override;
	virtual void Render(HDC hdc) override;

	virtual bool IsCollision(const Vector2& pos) const override;
	virtual bool IsCollision(const CircleCollider& col) const override;
	virtual bool IsCollision(const RectCollider& col) const override;

	const float& GetRadius() const { return _radius; }

private:
	float _radius = 0.0f;
};

