#pragma once
class CircleCollider;
class RectCollider;

class Collider
{
public:
	enum class ColType
	{
		DEFAULT,
		CIRCLE,
		RECT
	};

public:
	Collider();
	virtual ~Collider();

	virtual void Update() abstract;
	virtual void Render(HDC hdc);

	void Move(const Vector2& pos) { _center = pos; }

	virtual bool IsCollision(const Vector2& pos) const abstract;
	virtual bool IsCollision(const CircleCollider& col) const abstract;
	virtual bool IsCollision(const RectCollider& col) const abstract;

	bool IsCollision(Collider& col)const;
	const Vector2& GetCenter() const { return _center; }

	void SetRedColor();
	void SetGreenColor();

	Vector2 _center = { 0,0 };
	bool _isActive = true;

protected:
	bool _color = false;
	ColType _type = ColType::DEFAULT;

	vector<HPEN> _pens;
};

