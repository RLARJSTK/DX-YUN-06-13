#pragma once
class RectCollider : public Collider
{
public:
	RectCollider();
	RectCollider(const Vector2& halfSize, const Vector2& center);
	virtual ~RectCollider();

	const int& Left() const { return static_cast<int>(_center._x - _halfSize._x); }
	const int& Top() const { return static_cast<int>(_center._y - _halfSize._y); }
	const int& Right() const { return static_cast<int>(_center._x + _halfSize._x); }
	const int& Bottom() const { return static_cast<int>(_center._y + _halfSize._y); }

	void SetRect(const Vector2& halfSize, const Vector2& center)
	{
		_halfSize = halfSize;
		_center = center;
	}

	virtual void Update() override;
	virtual void Render(HDC hdc) override;

	// �浹
	virtual bool IsCollision(const Vector2& pos) const override;
	virtual bool IsCollision(const CircleCollider& col) const override;
	virtual bool IsCollision(const RectCollider& col) const override;

private:

	Vector2 _halfSize;
};

