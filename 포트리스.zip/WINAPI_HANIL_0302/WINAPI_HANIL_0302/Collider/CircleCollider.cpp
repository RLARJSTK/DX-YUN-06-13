#include "Framework.h"
#include "CircleCollider.h"

CircleCollider::CircleCollider()
{
	_type = ColType::CIRCLE;
}

CircleCollider::CircleCollider(float radius, const Vector2& center)
: _radius(radius)
{
	_type = ColType::CIRCLE;
	_center = center;
}

CircleCollider::~CircleCollider()
{
}

void CircleCollider::Update()
{
}

void CircleCollider::Render(HDC hdc)
{
	// ���� ����
	Collider::Render(hdc);

	int left	 = static_cast<int>(_center._x - _radius);
	int top		 = static_cast<int>(_center._y - _radius);
	int right	 = static_cast<int>(_center._x + _radius);
	int bottom	 = static_cast<int>(_center._y + _radius);

	Ellipse(hdc, left, top, right, bottom);
}

bool CircleCollider::IsCollision(const Vector2& pos) const
{
	// ���� �� �浹
	Vector2 center = _center;
	if (_radius >= center.Distance(pos))
		return true;

	return false;
}

bool CircleCollider::IsCollision(const CircleCollider& col) const
{
	// ���� 1: ���� �� �浹
	Vector2 center = _center;
	float distance = (center - col._center).Length();
	float distance2 = _radius + col._radius;

	return distance2 > distance;
}

bool CircleCollider::IsCollision(const RectCollider& col) const
{
	return col.IsCollision(*this);
}
