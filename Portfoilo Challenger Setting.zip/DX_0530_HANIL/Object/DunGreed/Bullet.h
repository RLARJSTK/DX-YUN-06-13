#pragma once
class Bullet
{
public:
	Bullet();
	~Bullet();

	void Update();
	void Render();

	shared_ptr<Transform> GetTransfom() { return _quad->GetTransform(); }
	void SetDirection(Vector2 dir);
	void SetPosition(Vector2 pos) { _quad->GetTransform()->GetPos() = pos; }

	shared_ptr<Collider> GetCollider() { return _collider; }

	bool isActive = false;

private:
	shared_ptr<Quad> _quad;

	shared_ptr<Collider> _collider;

	Vector2 _direction;

	float _runTime = 0.0f;
	float _destroyTime = 3.0f;
};

