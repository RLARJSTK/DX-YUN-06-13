#include "framework.h"
#include "Challenger.h"

Challenger::Challenger()
{


	_sprite = make_shared<Sprite>(L"Resource/challenger Left.png", Vector2(10, 8));
	_sprite = make_shared<Sprite>(L"Resource/challenger Right.png", Vector2(10, 8));
	//_sprite = make_shared<Sprite>(L"Resource/challenger LeftJump.png", Vector2(10, 8));
	//_sprite = make_shared<Sprite>(L"Resource/challenger LeftRun.png", Vector2(10, 8));
	//_sprite = make_shared<Sprite>(L"Resource/challenger LeftStand.png", Vector2(10, 8));
	//_sprite = make_shared<Sprite>(L"Resource/challenger RightJump.png png", Vector2(10, 8));
	//_sprite = make_shared<Sprite>(L"Resource/challenger RightRun.png", Vector2(10, 8));
	//_sprite = make_shared<Sprite>(L"Resource/challenger RightStand.png", Vector2(10, 8));
	_sprite->GetTransform()->GetPos() = Vector2(WIN_WIDTH, WIN_HEIGHT) * 0.5f;
	_collider = make_shared<RectCollider>(_sprite->GetHalfFrameSize());
	_collider->SetParent(_sprite->GetTransform());

	CreateActions();
}

Challenger::~Challenger()
{
}

void Challenger::CreateActions()
{
	_actions.reserve(6);
	//x= ������ǥ ,y�� ������ǥ
// Action ����
	{
		vector<Action::Clip> clips;
		float w = 1200.0f / 20.0f;  //= ������ ����/ �׻����� ���α׸��ִ밹��
		float h = 1040.0f / 8.0f;  //= ������ ����/ �׻����� ���α׸��ִ밹��
		float y = 0;
		//���ʴ��
		{
			clips.emplace_back(0 + w * 2, y, w, h, Texture::Add(L"Resource/challenger Left.png"));
		}
		_actions.push_back(make_shared<Action>(clips, "L_IDLE"));
		clips.clear();
		y = 1040 * (3.0f / 8.0f);
		// ���� ����
		{
			clips.emplace_back(0 + w * 19, y, w, h, Texture::Add(L"Resource/challenger Left.png"));
			clips.emplace_back(0 + w * 18, y, w, h, Texture::Add(L"Resource/challenger Left.png"));
			clips.emplace_back(0 + w * 17, y, w, h, Texture::Add(L"Resource/challenger Left.png"));
			clips.emplace_back(0 + w * 16, y, w, h, Texture::Add(L"Resource/challenger Left.png"));
			clips.emplace_back(0 + w * 15, y, w, h, Texture::Add(L"Resource/challenger Left.png"));
			clips.emplace_back(0 + w * 14, y, w, h, Texture::Add(L"Resource/challenger Left.png"));
			clips.emplace_back(0 + w * 13, y, w, h, Texture::Add(L"Resource/challenger Left.png"));
		}
		_actions.push_back(make_shared<Action>(clips, "L_JUMP"));
		clips.clear();



		y = 1040 * (4.0f / 8.0f);
		// ���� �޸���
		{
			clips.emplace_back(0 + w * 16, y, w, h, Texture::Add(L"Resource/challenger Left.png"));
			clips.emplace_back(0 + w * 15, y, w, h, Texture::Add(L"Resource/challenger Left.png"));
			clips.emplace_back(0 + w * 14, y, w, h, Texture::Add(L"Resource/challenger Left.png"));
			clips.emplace_back(0 + w * 13, y, w, h, Texture::Add(L"Resource/challenger Left.png"));
			clips.emplace_back(0 + w * 12, y, w, h, Texture::Add(L"Resource/challenger Left.png"));
			clips.emplace_back(0 + w * 11, y, w, h, Texture::Add(L"Resource/challenger Left.png"));
			clips.emplace_back(0 + w * 10, y, w, h, Texture::Add(L"Resource/challenger Left.png"));
			clips.emplace_back(0 + w * 9, y, w, h,  Texture::Add(L"Resource/challenger Left.png"));
			clips.emplace_back(0 + w * 8, y, w, h,  Texture::Add(L"Resource/challenger Left.png"));
			clips.emplace_back(0 + w * 7, y, w, h,  Texture::Add(L"Resource/challenger Left.png"));
			clips.emplace_back(0 + w * 6, y, w, h,  Texture::Add(L"Resource/challenger Left.png"));
			clips.emplace_back(0 + w * 5, y, w, h,  Texture::Add(L"Resource/challenger Left.png"));
			clips.emplace_back(0 + w * 4, y, w, h,  Texture::Add(L"Resource/challenger Left.png"));
			clips.emplace_back(0 + w * 3, y, w, h,  Texture::Add(L"Resource/challenger Left.png"));
			clips.emplace_back(0 + w * 2, y, w, h,  Texture::Add(L"Resource/challenger Left.png"));
			clips.emplace_back(0 + w, y, w, h,      Texture::Add(L"Resource/challenger Left.png"));
			clips.emplace_back(0, y, w, h,          Texture::Add(L"Resource/challenger Left.png"));

		}
		_actions.push_back(make_shared<Action>(clips, "L_RUN"));
		clips.clear();
	}
	{
		vector<Action::Clip> clips;
		float w = 1200.0f / 20.0f;  //= ������ ����/ �׻����� ���α׸��ִ밹��
		float h = 1040.0f / 8.0f;  //= ������ ����/ �׻����� ���α׸��ִ밹��
		// �����ʴ��  
		float y = 0;
		{
			clips.emplace_back(0 + w * 2, y, w, h, Texture::Add(L"Resource/challenger Right.png"));
		}
		_actions.push_back(make_shared<Action>(clips, "R_IDLE"));
		clips.clear();

		y = 1040 * (4.0f / 8.0f);
		// ���������� �޸���
		{
			clips.emplace_back(0, y, w, h,          Texture::Add(L"Resource/challenger Right.png"));
			clips.emplace_back(0 + w, y, w, h,      Texture::Add(L"Resource/challenger Right.png"));
			clips.emplace_back(0 + w * 2, y, w, h,  Texture::Add(L"Resource/challenger Right.png"));
			clips.emplace_back(0 + w * 3, y, w, h,  Texture::Add(L"Resource/challenger Right.png"));
			clips.emplace_back(0 + w * 4, y, w, h,  Texture::Add(L"Resource/challenger Right.png"));
			clips.emplace_back(0 + w * 5, y, w, h,  Texture::Add(L"Resource/challenger Right.png"));
			clips.emplace_back(0 + w * 6, y, w, h,  Texture::Add(L"Resource/challenger Right.png"));
			clips.emplace_back(0 + w * 7, y, w, h,  Texture::Add(L"Resource/challenger Right.png"));
			clips.emplace_back(0 + w * 8, y, w, h,  Texture::Add(L"Resource/challenger Right.png"));
			clips.emplace_back(0 + w * 9, y, w, h,  Texture::Add(L"Resource/challenger Right.png"));
			clips.emplace_back(0 + w * 10, y, w, h, Texture::Add(L"Resource/challenger Right.png"));
			clips.emplace_back(0 + w * 11, y, w, h, Texture::Add(L"Resource/challenger Right.png"));
			clips.emplace_back(0 + w * 12, y, w, h, Texture::Add(L"Resource/challenger Right.png"));
			clips.emplace_back(0 + w * 13, y, w, h, Texture::Add(L"Resource/challenger Right.png"));
			clips.emplace_back(0 + w * 14, y, w, h, Texture::Add(L"Resource/challenger Right.png"));
			clips.emplace_back(0 + w * 15, y, w, h, Texture::Add(L"Resource/challenger Right.png"));
			clips.emplace_back(0 + w * 16, y, w, h, Texture::Add(L"Resource/challenger Right.png"));
			
		}
		_actions.push_back(make_shared<Action>(clips, "R_RUN"));
		clips.clear();


		y = 1040 * (3.0f / 8.0f);
		// ������ ����
		{
			clips.emplace_back(0 , y, w, h, Texture::Add(L"Resource/challenger Right.png"));
			clips.emplace_back(0 + w , y, w, h, Texture::Add(L"Resource/challenger Right.png"));
			clips.emplace_back(0 + w * 2, y, w, h, Texture::Add(L"Resource/challenger Right.png"));
			clips.emplace_back(0 + w * 3, y, w, h, Texture::Add(L"Resource/challenger Right.png"));
			clips.emplace_back(0 + w * 4, y, w, h, Texture::Add(L"Resource/challenger Right.png"));
			clips.emplace_back(0 + w * 5, y, w, h, Texture::Add(L"Resource/challenger Right.png"));
			clips.emplace_back(0 + w * 6, y, w, h, Texture::Add(L"Resource/challenger Right.png"));

		}
		shared_ptr<Action> rightRUN = make_shared<Action>(clips, "R_JUMP");
		clips.clear();

	}
	//{
	//	vector<Action::Clip> clips;
	//float w = 176.0f / 4.0f;  //= ������ ����/ �׻����� ���α׸��ִ밹��
	//float h = 123.0f / 1.0f;  //= ������ ����/ �׻����� ���α׸��ִ밹��
	//
	//float y = 0;
	//{
	//	clips.emplace_back(0 + y, w, h, Texture::Add(L"Resource/challenger LeftStand.png"));
	//}
	//_actions.push_back(make_shared<Action>(clips, "L_IDLE"));
	//clips.clear();
	//}
	//
	//{
	//	vector<Action::Clip> clips;
	//	float w = 906.0f / 17.0f;  //= ������ ����/ �׻����� ���α׸��ִ밹��
	//	float h = 133.0f / 1.0f;  //= ������ ����/ �׻����� ���α׸��ִ밹��
	//
	//	float y = 0;
	//	{
	//		clips.emplace_back(0 + w * 16, y, w, h, Texture::Add(L"Resource/challenger LeftRun.png"));
	//		clips.emplace_back(0 + w * 15, y, w, h, Texture::Add(L"Resource/challenger LeftRun.png"));
	//		clips.emplace_back(0 + w * 14, y, w, h, Texture::Add(L"Resource/challenger LeftRun.png"));
	//		clips.emplace_back(0 + w * 13, y, w, h, Texture::Add(L"Resource/challenger LeftRun.png"));
	//		clips.emplace_back(0 + w * 12, y, w, h, Texture::Add(L"Resource/challenger LeftRun.png"));
	//		clips.emplace_back(0 + w * 11, y, w, h, Texture::Add(L"Resource/challenger LeftRun.png"));
	//		clips.emplace_back(0 + w * 10, y, w, h, Texture::Add(L"Resource/challenger LeftRun.png"));
	//		clips.emplace_back(0 + w * 9, y, w, h,  Texture::Add(L"Resource/challenger LeftRun.png"));
	//		clips.emplace_back(0 + w * 8, y, w, h,  Texture::Add(L"Resource/challenger LeftRun.png"));
	//		clips.emplace_back(0 + w * 7, y, w, h,  Texture::Add(L"Resource/challenger LeftRun.png"));
	//		clips.emplace_back(0 + w * 6, y, w, h,  Texture::Add(L"Resource/challenger LeftRun.png"));
	//		clips.emplace_back(0 + w * 5, y, w, h,  Texture::Add(L"Resource/challenger LeftRun.png"));
	//		clips.emplace_back(0 + w * 4, y, w, h,  Texture::Add(L"Resource/challenger LeftRun.png"));
	//		clips.emplace_back(0 + w * 3, y, w, h,  Texture::Add(L"Resource/challenger LeftRun.png"));
	//		clips.emplace_back(0 + w * 2, y, w, h,  Texture::Add(L"Resource/challenger LeftRun.png"));
	//		clips.emplace_back(0 + w, y, w, h,      Texture::Add(L"Resource/challenger LeftRun.png"));
	//		clips.emplace_back(0 + y, w, h,         Texture::Add(L"Resource/challenger LeftRun.png"));
	//	}
	//	_actions.push_back(make_shared<Action>(clips, "L_IDLE"));
	//	clips.clear();
	//}
	//{
	//	vector<Action::Clip> clips;
	//	float w = 397.0f / 7.0f;  //= ������ ����/ �׻����� ���α׸��ִ밹��
	//	float h = 128.0f / 1.0f;  //= ������ ����/ �׻����� ���α׸��ִ밹��
	//
	//	float y = 0;
	//	{
	//		clips.emplace_back(0 + w * 6, y, w, h, Texture::Add(L"Resource/challenger LeftJump.png"));
	//		clips.emplace_back(0 + w * 5, y, w, h, Texture::Add(L"Resource/challenger LeftJump.png"));
	//		clips.emplace_back(0 + w * 4, y, w, h, Texture::Add(L"Resource/challenger LeftJump.png"));
	//		clips.emplace_back(0 + w * 3, y, w, h, Texture::Add(L"Resource/challenger LeftJump.png"));
	//		clips.emplace_back(0 + w * 2, y, w, h, Texture::Add(L"Resource/challenger LeftJump.png"));
	//		clips.emplace_back(0 + w, y, w, h,     Texture::Add(L"Resource/challenger LeftJump.png"));
	//		clips.emplace_back(0 + y, w, h,        Texture::Add(L"Resource/challenger LeftJump.png"));
	//	}
	//	_actions.push_back(make_shared<Action>(clips, "L_IDLE"));
	//	clips.clear();
	//}
	/////// 
	//{
	//	vector<Action::Clip> clips;
	//	float w = 197.0f / 4.0f;  //= ������ ����/ �׻����� ���α׸��ִ밹��
	//	float h = 133.0f / 1.0f;  //= ������ ����/ �׻����� ���α׸��ִ밹��
	//
	//	float y = 0;
	//	{ 
	//		clips.emplace_back(0 + y, w, h,        Texture::Add(L"Resource/challenger RightStand.png"));
	//	}
	//	_actions.push_back(make_shared<Action>(clips, "L_IDLE"));
	//	clips.clear();
	//}
	//
	//{
	//	vector<Action::Clip> clips;
	//	float w = 872.0f / 17.0f;  //= ������ ����/ �׻����� ���α׸��ִ밹��
	//	float h = 120.0f / 1.0f;  //= ������ ����/ �׻����� ���α׸��ִ밹��
	//
	//	float y = 0;
	//	{
	//		clips.emplace_back(0 + y, w, h,         Texture::Add(L"Resource/challenger RightRun.png"));
	//		clips.emplace_back(0 + w, y, w, h,      Texture::Add(L"Resource/challenger RightRun.png"));
	//		clips.emplace_back(0 + w * 2, y, w, h,  Texture::Add(L"Resource/challenger RightRun.png"));
	//		clips.emplace_back(0 + w * 3, y, w, h,  Texture::Add(L"Resource/challenger RightRun.png"));
	//		clips.emplace_back(0 + w * 4, y, w, h,  Texture::Add(L"Resource/challenger RightRun.png"));
	//		clips.emplace_back(0 + w * 5, y, w, h,  Texture::Add(L"Resource/challenger RightRun.png"));
	//		clips.emplace_back(0 + w * 6, y, w, h,  Texture::Add(L"Resource/challenger RightRun.png"));
	//		clips.emplace_back(0 + w * 7, y, w, h,  Texture::Add(L"Resource/challenger RightRun.png"));
	//		clips.emplace_back(0 + w * 8, y, w, h,  Texture::Add(L"Resource/challenger RightRun.png"));
	//		clips.emplace_back(0 + w * 9, y, w, h,  Texture::Add(L"Resource/challenger RightRun.png"));
	//		clips.emplace_back(0 + w * 10, y, w, h, Texture::Add(L"Resource/challenger RightRun.png"));
	//		clips.emplace_back(0 + w * 11, y, w, h, Texture::Add(L"Resource/challenger RightRun.png"));
	//		clips.emplace_back(0 + w * 12, y, w, h, Texture::Add(L"Resource/challenger RightRun.png"));
	//		clips.emplace_back(0 + w * 13, y, w, h, Texture::Add(L"Resource/challenger RightRun.png"));
	//		clips.emplace_back(0 + w * 14, y, w, h, Texture::Add(L"Resource/challenger RightRun.png"));
	//		clips.emplace_back(0 + w * 15, y, w, h, Texture::Add(L"Resource/challenger RightRun.png"));
	//		clips.emplace_back(0 + w * 16, y, w, h, Texture::Add(L"Resource/challenger RightRun.png"));
	//	}
	//	_actions.push_back(make_shared<Action>(clips, "L_IDLE"));
	//	clips.clear();
	//}
	//{
	//	vector<Action::Clip> clips;
	//	float w = 396.0f / 7.0f;  //= ������ ����/ �׻����� ���α׸��ִ밹��
	//	float h = 120.0f / 1.0f;  //= ������ ����/ �׻����� ���α׸��ִ밹��
	//
	//	float y = 0;
	//	{
	//		clips.emplace_back(0 + y, w, h,       Texture::Add(L"Resource/challenger RightJump.png"));
	//		clips.emplace_back(0 + w, y, w, h,     Texture::Add(L"Resource/challenger RightJump.png"));
	//		clips.emplace_back(0 + w * 2, y, w, h, Texture::Add(L"Resource/challenger RightJump.png"));
	//		clips.emplace_back(0 + w * 3, y, w, h, Texture::Add(L"Resource/challenger RightJump.png"));
	//		clips.emplace_back(0 + w * 4, y, w, h, Texture::Add(L"Resource/challenger RightJump.png"));
	//		clips.emplace_back(0 + w * 5, y, w, h, Texture::Add(L"Resource/challenger RightJump.png"));
	//		clips.emplace_back(0 + w * 6, y, w, h, Texture::Add(L"Resource/challenger RightJump.png"));
	//	}
	//	_actions.push_back(make_shared<Action>(clips, "L_IDLE"));
	//	clips.clear();
	//}



	for (auto& action : _actions)
		action->Pause();

	_actions[_aniState]->Play();
}

void Challenger::Update()
{
	_sprite->Update();
	_collider->Update();

	PlayMoveByKeyBoard();

	for (auto& action : _actions)
	{
		action->Update();
		if (!action->IsPlay())
			continue;
		_sprite->SetClipToActionBuffer(action->GetCurClip());
	}

}

void Challenger::Render()
{
	_sprite->Render();
}


void Challenger::SetPostion(float x, float y)
{
	_sprite->GetTransform()->GetPos() = { x,y };
	_challengerPos = { x,y };
}

void Challenger::SetAnimation(State aniState)
{
	if (_actions[aniState]->IsPlay() && _actions[aniState]->GetAnimType() == Action::LOOP)
		return;

	for (auto& action : _actions)
	{
		if (action->IsPlay() && _aniState == aniState)
			continue;

		action->Reset();
	}

	_actions[aniState]->Play();
	_aniState = aniState;
}

void Challenger::PlayMoveByKeyBoard()
{
	this->SetPostion(_challengerPos.x, _challengerPos.y);

	if (KEY_PRESS('A'))
	{
		_challengerPos.x -= _speed * DELTA_TIME;
		this->SetAnimation(Challenger::State::L_RUN);

		return;
	}
	if (KEY_PRESS('D'))
	{
		_challengerPos.x += _speed * DELTA_TIME;
		this->SetAnimation(Challenger::State::R_RUN);

		return;
	}

	SetIDLE();
}
void Challenger::SetIDLE()
{
	switch (_aniState)
	{
	case Challenger::L_RUN:
		SetAnimation(State::L_IDLE);
		break;
	case Challenger::R_RUN:
		SetAnimation(State::R_IDLE);
		break;
	case Challenger::L_JUMP:
		SetAnimation(State::L_IDLE);
		break;
	case Challenger::R_JUMP:
		SetAnimation(State::R_IDLE);
		break;
	default:
		break;
	}
};


