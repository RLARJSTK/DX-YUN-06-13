#pragma once
class CircleCollider : public Collider
{
public:
	CircleCollider(float radius);
	~CircleCollider();

	virtual void CreateData() override;

	virtual void Update() override;
	virtual void Render() override;

	virtual bool IsCollision(const Vector2& pos) override;
	virtual bool IsCollision(shared_ptr<CircleCollider> other, bool isObb = false) override;
	virtual bool IsCollision(shared_ptr<class RectCollider> other, bool obb = false) override;

	float GetRadius() { return _radius * _transform->GetWorldScale().x; }

private:
	float _radius;
};

