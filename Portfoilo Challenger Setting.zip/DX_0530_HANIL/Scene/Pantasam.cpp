#include "framework.h"
#include "Pantasam.h"

Pantasam::Pantasam()
{
	_cha = make_shared<Challenger>();
	//_chaPos = { WIN_WIDTH * 0.5f, WIN_HEIGHT * 0.5f };
	_cha->SetPostion(WIN_WIDTH * 0.5f, WIN_HEIGHT * 0.5f);
}

Pantasam::~Pantasam()
{
}

void Pantasam::Update()
{
	_cha->Update();
}

void Pantasam::Render()
{
	_cha->Render();

}

void Pantasam::PostRender()
{
}
