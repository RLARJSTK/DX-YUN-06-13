#pragma once
class Pantasam : public Scene
{
public:
	Pantasam();
	virtual ~Pantasam();

	virtual void Update() override;
	virtual void Render() override;
	virtual void PostRender() override;

private:
	shared_ptr<Challenger> _cha;

	Vector2 _chaPos = { 0,0 };
};

