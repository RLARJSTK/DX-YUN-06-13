#pragma once
class MathUtillity
{
public:
	static int RandomInt(int min, int max);
	static float RandomFloat(float min, float max);
};

