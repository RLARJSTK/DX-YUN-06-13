#pragma once
class PantasmaScene : public Scene
{
public:
	PantasmaScene();
	virtual ~PantasmaScene();

	virtual void Update() override;
	virtual void Render() override;



private:
	shared_ptr<Quad> _stage;
	shared_ptr<Sprite> _start;
	shared_ptr<Sprite> _goal;
	shared_ptr<Collider> _collider;
	shared_ptr<Maze> _maze;

};

