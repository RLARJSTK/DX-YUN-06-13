#include "framework.h"
#include "InstancingScene.h"

InstancingScene::InstancingScene()
{
	//_quads.reserve(_poolCount);

	//for (int i = 0; i < _poolCount; i++)
	//{
	//	shared_ptr<Quad> quad = make_shared<Quad>(L"Resource/Player.png");
	//	quad->GetTransform()->GetPos() = { (float)MathUtillity::RandomInt(0,WIN_WIDTH), (float)MathUtillity::RandomInt(0,WIN_HEIGHT) };
	//	quad->GetTransform()->GetScale() *= MathUtillity::RandomFloat(0.0f, 1.0f);
	//	_quads.emplace_back(quad);
	//}

	_quad = make_shared<Quad>(L"Resource/Player.png",
								L"Shaders/InstancingVertexShader.hlsl",
								L"Shaders/InstancingPixelShader.hlsl");


	_instancingDataes.resize(_poolCount);

	for (auto& matrix : _instancingDataes)
	{
		Transform transform;
		transform.GetPos() = { (float)MathUtillity::RandomInt(0,WIN_WIDTH), (float)MathUtillity::RandomInt(0,WIN_HEIGHT) };
		transform.GetScale() *= MathUtillity::RandomFloat(0.0f, 1.0f);

		transform.UpdateWorldBuffer();

		matrix = XMMatrixTranspose(transform.GetMatrix());
	}

	_instanceBuffer = make_shared<VertexBuffer>(_instancingDataes.data(), sizeof(XMMATRIX), _poolCount);
}

InstancingScene::~InstancingScene()
{
}

void InstancingScene::Update()
{
}

void InstancingScene::Render()
{
	_instanceBuffer->IASet(1);

	_quad->SetRender();

	DEVICE_CONTEXT->DrawIndexedInstanced(6, _poolCount, 0, 0, 0);
}
