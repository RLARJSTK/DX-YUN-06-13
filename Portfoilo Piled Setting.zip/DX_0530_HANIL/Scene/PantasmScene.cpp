#include "framework.h"
#include "PantasmScene.h"

PantasmScene::PantasmScene()
{
	//_cha = make_shared <Challenger >();
	//_loadPos = { WIN_WIDTH * 0.5f, WIN_HEIGHT * 0.5f };
	//_cha -> SetPostion(WIN_WIDTH * 0.5f, WIN_HEIGHT * 0.5f);
	for (int y = 0; y < _poolCountY; y++)
	{
		for (int x = 0; x < _poolCountX; x++)
		{
			shared_ptr<Piled> newBlock = make_shared<Piled>();
			newBlock->SetPosition(Vector2(22 * x + CENTER_X * 0.5f, 22 * y + 60));
			_blocks.emplace_back(newBlock);
			_blockMatrix[x][y] = newBlock;
		}
	}
	_blocks.back()->_type = Piled::PassType::END;

}

PantasmScene::~PantasmScene()
{
}

void PantasmScene::Update()
{
	//_cha->Update();
//
	//_cha->SetPostion(_loadPos.x, _loadPos.y);
	for (auto& block : _blocks)
		block->Update();

	//_blockMatrix[static_cast<int>(_player->GetPos()._x)][static_cast<int>(_player->GetPos()._y)]
	//	->SetType(Piled::PassType::PLAYER);

}

void PantasmScene::Render(HDC hdc)
{
	//_cha->Render();
	for (auto& block : _blocks)
		block->Render(hdc);
}

void PantasmScene::GenerateMap()
{

	for (int y = 0; y < _poolCountY; y++)
	{
		for (int x = 0; x < _poolCountX; x++)
		{
			if (x % 2 == 0 || y % 2 == 0)
			{
				_blockMatrix[x][y]->SetType(Block::PassType::DISABLE);
			}
			else
			{
				_blockMatrix[x][y]->SetType(Block::PassType::ABLE);
			}
		}
	}

	// �������� ���� Ȥ�� �Ʒ��� ���� �մ� �۾�
	for (int y = 0; y < _poolCountY; y++)
	{
		for (int x = 0; x < _poolCountX; x++)
		{
			if (x % 2 == 0 || y % 2 == 0)
				continue;

			//// �̷ΰ� ������ �����̸� �� �ձ� ����
			if (x == _poolCountX - 2 && y == _poolCountY - 2)
			{
				_blockMatrix[x][y]->SetType(Block::PassType::END);
				continue;
			}

			if (y == _poolCountX - 2)
			{
				_blockMatrix[x + 1][y]->SetType(Block::PassType::ABLE);
				continue;
			}

			if (x == _poolCountX - 2)
			{
				_blockMatrix[x][y + 1]->SetType(Block::PassType::ABLE);
				continue;
			}

			const int randValue = rand() % 2;
			if (randValue == 0)
				_blockMatrix[x][y + 1]->SetType(Block::PassType::ABLE);
			else
				_blockMatrix[x + 1][y]->SetType(Block::PassType::ABLE);
		}
	}

}



// Player::Player(shared_ptr<Maze> maze)
//: _maze(maze)
//{
//	_pos = _maze->GetEnterPos();
//
//	Bfs();
//}
//
//Player::~Player()
//{
//}
//
//void Player::Update()
//{
//	if (_pathIndex >= _path.size())
//		return;
//
//	_time += 0.1f;
//
//	if (_time >= 1.0f)
//	{
//		_pos = _path[_pathIndex];
//
//		if (_pathIndex != 0)
//		{
//			Vector2 temp = _path[_pathIndex - 1];
//			_maze->GetBlock(temp)->SetType(Block::PassType::FOOTPRINT);
//		}
//
//		_time = 0.0f;
//		_pathIndex++;
//	}
//}
//
//void Player::Bfs()
//{
//	Vector2 frontPos[4] =
//	{
//		// ����� ��ǥ���
//		Vector2 { -1, 0}, // Up
//		Vector2 {0, -1}, // Left
//		Vector2 {1 , 0}, // Down
//		Vector2 {0 , 1} // Right
//	};
//
//	vector<vector<bool>> discovered;
//	vector<vector<Vector2>> parent;
//
//	discovered = vector<vector<bool>>(25, vector<bool>(25, false));
//	parent = vector<vector<Vector2>>(25, vector<Vector2>(25, Vector2(-1, -1)));
//
//	// ������
//	Vector2 start = _maze->GetEnterPos();
//	Vector2 end = _maze->GetEndPos();
//	// ����
//
//	queue<Vector2> q;
//	q.push(start);
//	discovered[start._x][start._y] = true;
//
//	while (q.empty() == false)
//	{
//		Vector2 here = q.front();
//		if (here == end)
//			break;
//
//		q.pop();
//
//		for (int i = 0; i < 4; i++)
//		{
//			Vector2 there = here + frontPos[i];
//			if (CanGo(there) && discovered[there._x][there._y] == false)
//			{
//				// �ѹ��� �ȹ�ƺð�, ���� ���� �ƴϴ�!
//				discovered[there._x][there._y] = true;
//				parent[there._x][there._y] = here;
//				q.push(there);
//			}
//		}
//	}
//
//	// ��ȸ�ϸ鼭 endPos�� ã������ endPos�� �θ� �� Ÿ�� �ö󰡺���
//	Vector2 parentVec = end;
//	while (true)
//	{
//		if (parentVec == start)
//		{
//			break;
//		}
//		_path.push_back(parentVec);
//		parentVec = parent[parentVec._x][parentVec._y];
//	}
//	std::reverse(_path.begin(), _path.end());
//}

//bool Player::CanGo(Vector2 pos)
//{
//	if (_maze->GetBlockType(pos) == Block::PassType::DISABLE)
//	{
//		return false;
//	}
//
//	return true;
//}

//Maze::Maze()
//{
//	for (int y = 0; y < _poolCountY; y++)
//	{
//		for (int x = 0; x < _poolCountX; x++)
//		{
//			shared_ptr<Block> newBlock = make_shared<Block>();
//			newBlock->SetPosition(Vector2(22 * x + CENTER_X * 0.5f, 22 * y + 60));
//			_blocks.emplace_back(newBlock);
//			_blockMatrix[x][y] = newBlock;
//		}
//	}
//	_blocks.back()->_type = Block::PassType::END;
//
//	GenerateMap();
//
//	_player = make_shared<Player>(make_shared<Maze>(*this));
//}
//
//Maze::~Maze()
//{
//}
//
//void Maze::Update()
//{
//	for (auto& block : _blocks)
//		block->Update();
//
//	_blockMatrix[static_cast<int>(_player->GetPos()._x)][static_cast<int>(_player->GetPos()._y)]
//		->SetType(Block::PassType::PLAYER);
//
//	_player->Update();
//}
//
//void Maze::Render()
//{
//
//
//	for (auto& block : _blocks)
//		block->Render(hdc);
//}
//
//void Maze::GenerateMap()
//{
//	for (int y = 0; y < _poolCountY; y++)
//	{
//		for (int x = 0; x < _poolCountX; x++)
//		{
//			if (x % 2 == 0 || y % 2 == 0)
//			{
//				_blockMatrix[x][y]->SetType(Block::PassType::DISABLE);
//			}
//			else
//			{
//				_blockMatrix[x][y]->SetType(Block::PassType::ABLE);
//			}
//		}
//	}
//
//	// �������� ���� Ȥ�� �Ʒ��� ���� �մ� �۾�
//	for (int y = 0; y < _poolCountY; y++)
//	{
//		for (int x = 0; x < _poolCountX; x++)
//		{
//			if (x % 2 == 0 || y % 2 == 0)
//				continue;
//
//			//// �̷ΰ� ������ �����̸� �� �ձ� ����
//			if (x == _poolCountX - 2 && y == _poolCountY - 2)
//			{
//				_blockMatrix[x][y]->SetType(Block::PassType::END);
//				continue;
//			}
//
//			if (y == _poolCountX - 2)
//			{
//				_blockMatrix[x + 1][y]->SetType(Block::PassType::ABLE);
//				continue;
//			}
//
//			if (x == _poolCountX - 2)
//			{
//				_blockMatrix[x][y + 1]->SetType(Block::PassType::ABLE);
//				continue;
//			}
//
//			const int randValue = rand() % 2;
//			if (randValue == 0)
//				_blockMatrix[x][y + 1]->SetType(Block::PassType::ABLE);
//			else
//				_blockMatrix[x + 1][y]->SetType(Block::PassType::ABLE);
//		}
//	}
//}
