#include "framework.h"
#include "DungreedScene.h"

DungreedScene::DungreedScene()
{
	_player = make_shared<Player>();
	_aim = make_shared<Quad>(L"Resource/aim.png");
	_aim->GetTransform()->GetScale() *= 0.2f;

	_enemy = make_shared<Enemy>();

	_enemy->GetTransform()->GetPos() = Vector2(WIN_WIDTH, WIN_HEIGHT) * 0.8f;
}

DungreedScene::~DungreedScene()
{
}

void DungreedScene::Update()
{
	_player->Update();
	_enemy->Update();
	_aim->Update();

	_player->AttackEnemy(_enemy);

	_aim->GetTransform()->GetPos() = MOUSE_POS;
}

void DungreedScene::Render()
{
	_player->Render();
	_enemy->Render();
	_aim->Render();
}

void DungreedScene::PostRender()
{
}
