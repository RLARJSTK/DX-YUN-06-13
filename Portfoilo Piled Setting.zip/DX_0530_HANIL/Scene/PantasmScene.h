#pragma once
class PantasmScene : public Scene
{
public:
	PantasmScene();
	virtual ~PantasmScene();

	// Scene��(��) ���� ��ӵ�
	virtual void Update() override;
	virtual void Render(HDC hdc)override;
	virtual void GenerateMap()override;
	Piled::PassType GetBlockType(Vector2 pos)
	{
		return _blockMatrix[static_cast<int>(pos.x)][static_cast<int>(pos.y)]->_type;
	}
	shared_ptr<Piled> GetBlock(Vector2 pos)
	{ return _blockMatrix[static_cast<int>(pos.x)][static_cast<int>(pos.y)]; }
private:
	//shared_ptr<Challenger> _cha;

	Vector2 _loadPos = { 0,0 };

	const unsigned int _poolCountX = 25;
	const unsigned int _poolCountY = 25;
	vector < shared_ptr<Piled>> _blocks; 
	shared_ptr<Piled> _blockMatrix[25][25];
};
//#pragma once
//
//class Maze;
//
//class Player
//{
//public:
//	Player(shared_ptr<Maze> maze);
//	~Player();
//
//	void Update();
//	void SetPos(Vector2 pos) { _pos = pos; }
//	Vector2 GetPos() { return _pos; }
//	void Bfs();
//
//	bool CanGo(Vector2 pos);
//
//private:
//	Vector2 _pos = { 0.0f, 0.0f };
//	shared_ptr<Maze> _maze;
//
//	vector<Vector2> _path;
//	int _pathIndex = 0;
//	float _time = 0.0f;
//};
// #pragma once
//class Maze
//{
//public:
//	Maze();
//	~Maze();
//
//	void Update();
//	void Render(HDC hdc);
//
//	void GenerateMap();
//
//	Vector2 GetEnterPos() { return Vector2(1, 1); }
//	Vector2 GetEndPos() { return Vector2(_poolCountX - 2, _poolCountY - 2); }
//	Block::PassType GetBlockType(Vector2 pos) 
// { return _blockMatrix[static_cast<int>(pos._x)][static_cast<int>(pos._y)]->_type; }
//	shared_ptr<Block> GetBlock(Vector2 pos) \
// { return _blockMatrix[static_cast<int>(pos._x)][static_cast<int>(pos._y)]; }
//
//private:
//	const unsigned int _poolCountX = 25;
//	const unsigned int _poolCountY = 25;
//	vector<shared_ptr<Block>> _blocks;
//	shared_ptr<Block> _blockMatrix[25][25];
//
//	shared_ptr<Player> _player;
//};
////