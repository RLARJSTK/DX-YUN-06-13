#include "framework.h"
#include "PantasmaScene.h"

PantasmaScene::PantasmaScene()
{
	_stage = make_shared<Quad>(L"Resource/pilde1.png");
	_stage->GetTransform()->GetPos().x += _stage->GetHalfSize().x;
	_stage->GetTransform()->GetPos().y += _stage->GetHalfSize().y;

	_start = make_shared<Sprite>(L"Resource/Start.png");
	_start->GetTransform()->GetPos() = Vector2(WIN_WIDTH, WIN_HEIGHT) * 0.5f;
	_collider = make_shared<RectCollider>(_start->GetHalfFrameSize());
	_collider->SetParent(_start->GetTransform());
	
	_goal = make_shared<Sprite>(L"Resource/goal.png");
	_goal->GetTransform()->GetPos() = Vector2(WIN_WIDTH, WIN_HEIGHT) * 5.0f;
	_collider = make_shared<RectCollider>(_goal->GetHalfFrameSize());
	_collider->SetParent(_goal->GetTransform());
	_maze = make_shared<Maze>();
}

PantasmaScene::~PantasmaScene()
{
}

void PantasmaScene::Update()
{
	_collider->Update();
	_start->Update();
	_goal->Update();
	_stage->Update();
	
}

void PantasmaScene::Render()
{
	_collider->Render();
	_start->Render();
	_goal->Render();
	_stage->Render();
	_maze->Render();
}
