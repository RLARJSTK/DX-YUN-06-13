#pragma once
class Player
{
public:
	enum State
	{
		GROUND,
		JUMPING,
		ATTACK
	};


	Player();
	~Player();

	void Update();
	void Render();

	void AttackEnemy(shared_ptr<class Enemy> enemy);

private:
	void Move();
	void Aiming();
	void Fire();
	void Jump();

private:
	shared_ptr<Quad> _quad;

	shared_ptr<Collider> _collider;

	shared_ptr<class Gun> _gun;
	shared_ptr<Transform> _gunTrans;

	vector<shared_ptr<class Bullet>> _bullets;
	UINT _poolCount = 30;

	float _jumpPower = 300.0f;
	float _gravity = 100.0f;
	State _state = GROUND;
};

