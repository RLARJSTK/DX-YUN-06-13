#pragma once

class Piled
{
public:
	enum class PassType
	{
		ABLE,

		DISABLE,
		END,
	
	};

	Piled();
	~Piled();

	void Update();
	void Render(HDC hdc);


	void SetPosition(Vector2 core) { _rect->_core =core; }
	void SetType(Piled::PassType t) { _type = t; }
	PassType _type = Piled::PassType::ABLE;
private:
	Vector2 _core = { 0,0 };
	HBRUSH _hBrush[5]; 
	shared_ptr<RectCollider> _rect;
};
// #pragma once
//class Maze
//{
//public:
//	Maze();
//	~Maze();
//
//	void Update();
//	void Render(HDC hdc);
//
//	void GenerateMap();
//
//	Vector2 GetEnterPos() { return Vector2(1, 1); }
//	Vector2 GetEndPos() { return Vector2(_poolCountX - 2, _poolCountY - 2); }
//	Block::PassType GetBlockType(Vector2 pos) 
// { return _blockMatrix[static_cast<int>(pos._x)][static_cast<int>(pos._y)]->_type; }
//	shared_ptr<Block> GetBlock(Vector2 pos) \
// { return _blockMatrix[static_cast<int>(pos._x)][static_cast<int>(pos._y)]; }
//
//private:
//	const unsigned int _poolCountX = 25;
//	const unsigned int _poolCountY = 25;
//	vector<shared_ptr<Block>> _blocks;
//	shared_ptr<Block> _blockMatrix[25][25];
//
//	shared_ptr<Player> _player;
//};
////