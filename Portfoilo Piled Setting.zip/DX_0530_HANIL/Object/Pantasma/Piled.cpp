#include "framework.h"
#include "Piled.h"


// �̵ΰ��� ��Ҹ� �ϳ��� ����=���� �ƴϸ� Scene �� �ٰ� �������
// 
//������ ��� ����
//Piled::Piled()
//
//	_rect = make_shared<RectCollider>(Vector2(8, 8), Vector2(0, 0));
//
//
//	_hBrush[static_cast<unsigned char>(PassType::DISABLE)] = CreateSolidBrush(RED);
//	_hBrush[static_cast<unsigned char>(PassType::END)] = CreateSolidBrush(BLUE);
//
//
//Piled::~Piled()
//
//	for (int i = 0; i < 4; i++)
//	{
//		DeleteObject(_hBrush[i]);
//	}
//
//
//void Piled::Update()
//
//
//
//void Piled::Render()
//
//	switch (_type)
//	{
//	case Piled::PassType::DISABLE:
//	{
//		SelectObject(hdc, _hBrush[static_cast<unsigned char>(PassType::DISABLE)]);
//	}
//	break;
//	case Piled::PassType::END:
//	{
//		SelectObject(hdc, _hBrush[static_cast<unsigned char>(PassType::END)]);
//	}
//	break;
//
//	default:
//		break;
//	}
//	_rect->Render();
// 

Piled::Piled()
{
	_rect = make_shared<RectCollider>(Vector2(8, 8), Vector2(0, 0));


	_hBrush[static_cast<unsigned char>(PassType::DISABLE)] = CreateSolidBrush(UNRED);
	_hBrush[static_cast<unsigned char>(PassType::END)] = CreateSolidBrush(UNBLUE);


}

Piled::~Piled()
{
	for (int i = 0; i < 4; i++)
	{
		DeleteObject(_hBrush[i]);
	}

}

void Piled::Update()
{
}

void Piled::Render(HDC hdc)
{
	
	switch (_type)
	{
	case Piled::PassType::DISABLE:
	{
		SelectObject(hdc, _hBrush[static_cast<unsigned char>(PassType::DISABLE)]);
	}
	break;
	case Piled::PassType::END:
	{
		SelectObject(hdc, _hBrush[static_cast<unsigned char>(PassType::END)]);
	}
	break;

	default:
		break;
	}
	_rect->Render();
}
