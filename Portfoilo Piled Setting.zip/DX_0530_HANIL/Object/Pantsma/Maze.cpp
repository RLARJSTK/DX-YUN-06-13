#include "framework.h"
#include "Maze.h"

Maze::Maze()
{
	//_quad = make_shared<Sprite>( L"Resource/GreenBlock.png");
	_quad = make_shared<Quad>(L"Resource/GreenBlock.png",
		L"Shaders/InstancingVertexShader.hlsl",
		L"Shaders/InstancingPixelShader.hlsl");

	_collider = make_shared<RectCollider>(_quad->GetHalfFrameSize());
	_collider-> SetParent(_quad->GetTransform());
	_collider = make_shared<RectCollider>(_quad->GetHalfSize() * 20.0f);
	_instancingDataes.resize(_poolCount);

	for (auto& matrix : _instancingDataes)
	{
		Transform transform;
		transform.GetPos() = { (float)MathUtillity::RandomInt(0,WIN_WIDTH), (float)MathUtillity::RandomInt(0,WIN_HEIGHT) };
		transform.GetScale() *= MathUtillity::RandomFloat(0.0f, 1.0f);

		transform.UpdateWorldBuffer();

		matrix = XMMatrixTranspose(transform.GetMatrix());
	}

	_instanceBuffer = make_shared<VertexBuffer>(_instancingDataes.data(), sizeof(XMMATRIX), _poolCount);


}

Maze::~Maze()
{
	
}

void Maze::Update()
{
}

void Maze::Render()
{
	_instanceBuffer->IASet(1);

	_quad->SetRender();

	DEVICE_CONTEXT->DrawIndexedInstanced(6, _poolCount, 0, 0, 0);
}

