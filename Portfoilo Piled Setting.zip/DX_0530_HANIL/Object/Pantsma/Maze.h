#pragma once
class Maze
{
public:
	Maze();
	~Maze();
	void Update();
	void Render();

	
private:

	shared_ptr<Quad> _quad;
	shared_ptr<Collider> _collider;

	vector<XMMATRIX> _instancingDataes;
	shared_ptr<VertexBuffer> _instanceBuffer;

	UINT _poolCount = 100;

};
