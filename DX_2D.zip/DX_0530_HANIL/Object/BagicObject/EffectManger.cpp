#include "framework.h"
#include "EffectManger.h"
EffectManger* EffectManger::_instance = nullptr;
void EffectManger::Add(wstring effectFile, Vector2 maxFrame, float speed, UINT poolcount)
{
	size_t t = effectFile.find(L"Effects/", 0);
	string temp = WstringToString(effectFile.substr( t+  8, effectFile.length()));
	temp.substr(0, temp.size() - 4);
	if (_effectMap.count(temp) > 0)
		return;
	vector<shared_ptr<Effect>> v;
	v.reserve(poolcount);
	for (int i = 0; i < poolcount; i++)
	{
		shared_ptr<Effect> effect = make_shared<Effect>(effectFile, maxFrame, speed);
		v.emplace_back(effect);
	}

	_effectMap[temp] = v;
}

void EffectManger::Play(string effect, Vector2 pos)
{
	if (_effectMap.count(effect) == 0)
		return;
	for (auto& effect : _effectMap[effect])
	{
		if (effect->_isActive == false)
		{
			effect->Player(pos);
				return;
		}
	}
}

void EffectManger::Update()
{
	for (auto& effect : _effectMap)
	{
		for (auto& effect : effect.second)
		{
			effect->Update();
		}
	}
}

void EffectManger::Render()
{
	for (auto& effect : _effectMap)
	{
		for (auto& effect : effect.second)
		{
			effect->Render();
		}
	}
}

