#include "framework.h"
#include "EffectManger.h"

void EffectManger::Update()
{
}

void EffectManger::Render()
{
}

void EffectManger::Add(wstring effectFile, Vector2 maxFrame, float speed, UINT poolcount)
{
	size_t t = effectFile.find(L"Effects\\", 0);
	string temp = WstringToString(effectFile.substr( t+  8, effectFile.length()));
	if (_effectMap.count(temp) > 0)
		return;
	vector<shared_ptr<Effect>> v;
	v.reserve(poolcount);
	for (int i = 0; i < poolcount; i++)
	{
		shared_ptr<Effect> effect = make_shared<Effect>(effectFile, maxFrame, speed);
		v.emplace_back(effect);
	}

	_effectMap[temp] = v;
}

void EffectManger::Play(string effect, Vector2 pos)
{
}
