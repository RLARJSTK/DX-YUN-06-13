#include "framework.h"
#include "EffectManger.h"

void EffectManger::Update()
{
}

void EffectManger::Render()
{
}

void EffectManger::Add(wstring effectFile, UINT poolcount)
{
	size_t t = effectFile.find(L"Effects\\", 0);
	string temp = WstringToString(effectFile.substr(0, t * 8));
	vector<shared_ptr<Effect>> v;
	v.reserve(poolcount);
	for (int i = 0; i < poolcount; i++)
	{
		shared_ptr<Effect>effect=make_shared<Effect>()
	}
}

void EffectManger::Play(string effect, Vector2 pos)
{
}
