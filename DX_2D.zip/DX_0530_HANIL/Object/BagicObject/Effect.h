#pragma once
class Effect 
{
public:
	Effect(wstring file, Vector2 maxFrame,float speed);
	~Effect();
	void CreateData(wstring file, float speed) ;
	 void Update() ;
	 void Render() ;
	 void Player(Vector2 pos);
	 void End() { _isActive = false; }
	 bool _isActive = true;
private:
	Vector2 _maxFrame;
	shared_ptr<Sprite> _sprite;
	shared_ptr<Action> _action;

};

