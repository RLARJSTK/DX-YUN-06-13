#pragma once
class EffectManger
{
public:
	EffectManger();
	~EffectManger();

	void Update();
	void Render();
	void Add(wstring effectFile, Vector2 maxFrame, float speed, UINT poolcount=30); //effectMap�߰�
	void Play(string effect, Vector2 pos);//effectMap����

private:

	unordered_map<string,vector<shared_ptr<Effect>>> _effectMap;
//�̱��� 
};

