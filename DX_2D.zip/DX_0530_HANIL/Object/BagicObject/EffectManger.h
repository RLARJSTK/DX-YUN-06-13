#pragma once
class EffectManger
{
public:
	static void Create()
	{
		if (_instance == nullptr)
		{
			_instance = new EffectManger();
		}
	}

	static void Delete()
	{
		if (_instance != nullptr)
		{
			delete _instance;
		}
	}

	static EffectManger* GetInstance()
	{
		if (_instance != nullptr)
			return _instance;

		return nullptr;
	}

	void Add(wstring effectFile, Vector2 maxFrame, float speed, UINT poolcount=30); //effectMap�߰�
	void Play(string effect, Vector2 pos);

	void Update();
	void Render();
private:
	//EffectManger();
	//~EffectManger();
	static EffectManger* _instance;
	unordered_map<string,vector<shared_ptr<Effect>>> _effectMap;
//�̱��� 
};

