#pragma once
class Butten
{
public:
	enum ButtenState
	{
		NONE,
		HOVER,
		CLICK
	};

	Butten();
	~Butten();

	void Update();
	void PostRender();

	void SetPosition(Vector2 pos);
	void SetScale(Vector2 scale);
	void SetText(string text);
	void SetState();

	shared_ptr<RectCollider> GetRectCollider() { return _col; }

private:
	ButtenState _state;

	shared_ptr<Quad> _quad;
	shared_ptr<RectCollider> _col;
	shared_ptr<ButtenBuffer> _bub;

	string _text;
	Vector2 _textPos = { 0,0 };
};

