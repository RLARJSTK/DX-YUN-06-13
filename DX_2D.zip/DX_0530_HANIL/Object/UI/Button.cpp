#include "framework.h"
#include "Button.h"

Butten::Butten()
{
	_state = Butten::ButtenState::NONE;
	_quad = make_shared<Quad>(L"Resource/UI/Button.png", L"Shaders/TextureVertexShader.hlsl", L"Shaders/ButtonPixelShader.hlsl");
	_quad->SetParent(Camera::GetInstance()->GetTransform());

	_col = make_shared<RectCollider>(_quad->GetHalfSize());
	_col->SetParent(_quad->GetTransform());
	_bub = make_shared<ButtenBuffer>();
	_bub->data.state = 0;
	_bub->data.hovered = 0.3f;
	_bub->data.clicked = 0.5f;
}

Butten::~Butten()
{
}

void Butten::Update()
{
	_quad->Update();
	_col->Update();
	SetState();
}

void Butten::PostRender()
{
	_bub->SetPSBuffer(0);
	_quad->Render();
	{
		wstring text = StringToWstring(_text);
		float offSetX = _quad->GetHalfSize().x * _quad->GetTransform()->GetScale().x * 0.5f;
		float offSetY = _quad->GetHalfSize().y * _quad->GetTransform()->GetScale().y * 0.5f;
		float sizeX = _quad->GetHalfSize().x * _quad->GetTransform()->GetScale().x;
		float sizeY = _quad->GetHalfSize().y * _quad->GetTransform()->GetScale().y;

		float left = _textPos.x - sizeX + offSetX;
		float top = _textPos.y - sizeY + offSetY;
		float right = _textPos.x + sizeX + offSetX;
		float bottom = _textPos.y + sizeY + offSetY;
		RECT rect = { left,top, right, bottom };
		DirectWrite::GetInstance()->RenderText(text, rect);
	}
	ImGui::SliderFloat("HoverColor", &_bub->data.hovered, 0.0f, 1.0f);
	ImGui::SliderFloat("ClickColor", &_bub->data.clicked, 0.0f, 1.0f);
}

void Butten::SetPosition(Vector2 pos)
{
	_quad->GetTransform()->GetPos() = pos;
	_textPos = pos;
}

void Butten::SetScale(Vector2 scale)
{
	_quad->GetTransform()->GetScale() = scale;
}

void Butten::SetText(string text)
{
	_text = text;
}

void Butten::SetState()
{
	if (_col->IsCollision(MOUSE_WORLD_POS))
	{
		_state = HOVER;
		if(KEY_PRESS(VK_LBUTTON))
		{
			_state = CLICK;
		}
	}
	else
	{
		_state = NONE;
	}
	switch (_state)
	{
	case Butten::NONE:
		_bub->data.state = 0;
		break;
	case Butten::HOVER:
		_bub->data.state = 1;
		break;
	case Butten::CLICK:
		_bub->data.state = 2;
		break;
	default:
		break;
	}
}
