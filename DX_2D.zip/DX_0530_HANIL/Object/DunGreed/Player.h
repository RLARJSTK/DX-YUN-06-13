#pragma once
class Player
{
public:
	Player();
	~Player();

	void Update();
	void Render();

	void AttackEnemy(shared_ptr<class Enemy> enemy);

private:
	void Move();
	void Aiming();
	void Fire();

private:
	shared_ptr<Quad> _quad;

	shared_ptr<Collider> _collider;

	shared_ptr<class Gun> _gun;
	shared_ptr<Transform> _gunTrans;

	vector<shared_ptr<class Bullet>> _bullets;
	UINT _poolCount = 30;
};

