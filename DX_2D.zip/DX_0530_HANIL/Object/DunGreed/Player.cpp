#include "framework.h"
#include "Player.h"

Player::Player()
{
	_quad = make_shared<Quad>(L"Resource/player.png");
	_quad->GetTransform()->GetScale() = { 0.5f,0.5f };

	_gunTrans = make_shared<Transform>();
	_gunTrans->SetParent(_quad->GetTransform());
	_gunTrans->GetPos().x = _quad->GetHalfSize().x;

	_gun = make_shared<Gun>();
	_gun->SetPlayer(_gunTrans);

	_bullets.reserve(30);
	for (int i = 0; i < _poolCount; i++)
	{
		shared_ptr<Bullet> bullet = make_shared<Bullet>();
		bullet->isActive = false;
		_bullets.push_back(bullet);
	}

	_collider = make_shared<RectCollider>(_quad->GetHalfSize());
	_collider->SetParent(_quad->GetTransform());
}

Player::~Player()
{
}

void Player::Update()
{
	Move();
	Aiming();
	Fire();

	_quad->Update();
	_gunTrans->UpdateWorldBuffer();

	_gun->Update();

	for (auto& bullet : _bullets)
	{
		bullet->Update();
	}

	_collider->Update();
}

void Player::Render()
{
	_quad->Render();

	_gun->Render();

	for (auto& bullet : _bullets)
	{
		bullet->Render();
	}

	_collider->Render();
}

void Player::Move()
{
	if (KEY_PRESS('W'))
	{
		_quad->GetTransform()->GetPos().y += 100.0f * DELTA_TIME;
	}
	if (KEY_PRESS('S'))
	{
		_quad->GetTransform()->GetPos().y -= 100.0f * DELTA_TIME;
	}
	if (KEY_PRESS('A'))
	{
		_quad->GetTransform()->GetPos().x -= 100.0f * DELTA_TIME;
	}
	if (KEY_PRESS('D'))
	{
		_quad->GetTransform()->GetPos().x += 100.0f * DELTA_TIME;
	}
}

void Player::Aiming()
{
	Vector2 v = MOUSE_POS - _gunTrans->GetWorldPos();
	float angle = v.Angle();

	_gunTrans->GetAngle() = angle;
}

void Player::Fire()
{
	if (KEY_DOWN(VK_LBUTTON))
	{
		Vector2 v = MOUSE_POS - _gunTrans->GetWorldPos();
		v.Normallize();

		for (auto& bullet : _bullets)
		{
			if (bullet->isActive == false)
			{
				bullet->SetDirection(v);
				bullet->SetPosition(_gunTrans->GetWorldPos());
				bullet->isActive = true;
				break;
			}
		}
	}
}

void Player::AttackEnemy(shared_ptr<Enemy> enemy)
{
	for (auto& bullet : _bullets)
	{
		if (bullet->isActive == true)
		{
			if (bullet->GetCollider()->IsCollision(enemy->GetCollider()))
			{
				enemy->GetCollider()->SetRed();
			}
		}
	}
}
