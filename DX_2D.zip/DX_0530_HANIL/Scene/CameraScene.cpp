#include "framework.h"
#include "CameraScene.h"

CameraScene::CameraScene()
{
	_back = make_shared<Quad>(L"Resource/Castle.png");
	//_back->GetTransform()->GetPos() = { WIN_WIDTH * 0.5f , WIN_HEIGHT * 0.5f };
	_zelda = make_shared<Zelda>();
	_zeldaFollw = make_shared<Transform>();
	//_zelda->SetPostion(WIN_WIDTH * 0.5f, WIN_HEIGHT * 0.5f);
	Camera::GetInstance()->SetTarget(_zelda->GetTransform());
	Vector2 leftBottom = {-_back->GetHalfSize().x, -_back->GetHalfSize().y};
	Vector2 rightTop = {-_back->GetHalfSize().x, -_back->GetHalfSize().y};
	Camera::GetInstance()->SetLeftBottom(leftBottom);
	Camera::GetInstance()->SetRightTop(rightTop);
}

CameraScene::~CameraScene()
{
}

void CameraScene::Update()
{
	 _back->Update();
	_zelda->Update();
	float distance = _zelda->GetTransform()->GetPos().Distance(_zeldaFollw->GetPos());
	if (distance >= 30.0f)
	{
		_zeldaFollw->GetScale() = LEFP(_zeldaFollw->GetPos(), _zelda->GetTransform()->GetPos(), 2.0f);
	}
}

void CameraScene::Render()
{
	 _back->Render();
	_zelda->Render();
}

void CameraScene::PostRender()
{
}

void CameraScene::ZeldaMove()
{
	_zelda->SetPostion(_zeldaPos.x, _zeldaPos.y);
	if (KEY_PRESS('W'))
	{
		_zeldaPos.y += 50 * DELTA_TIME;
		_zelda->SetAnimation(Zelda::State::B_RUN);

		return;
	}

	if (KEY_PRESS('A'))
	{
		_zeldaPos.x -= 50 * DELTA_TIME;
		_zelda->SetAnimation(Zelda::State::L_RUN);

		return;
	}

	if (KEY_PRESS('S'))
	{
		_zeldaPos.y -= 50 * DELTA_TIME;
		_zelda->SetAnimation(Zelda::State::F_RUN);

		return;
	}

	if (KEY_PRESS('D'))
	{
		_zeldaPos.x += 50 * DELTA_TIME;
		_zelda->SetAnimation(Zelda::State::R_RUN);

		return;
	}
}
