#include "framework.h"
#include "CameraScene.h"

CameraScene::CameraScene()
{
	_back = make_shared<Quad>(L"Resource/Castle.png");
	//_back->GetTransform()->GetPos() = { WIN_WIDTH * 0.5f , WIN_HEIGHT * 0.5f };
	_zelda = make_shared<Zelda>();
	_zeldaFollw = make_shared<Transform>();
	Vector2 temp = this->LoadPos();
	_zelda->SetPostion(temp.x, temp.y);
	_zeldaFollw->GetPos()=_zelda->GetTransform()->GetPos();
	//_zelda->SetPostion(WIN_WIDTH * 0.5f, WIN_HEIGHT * 0.5f);
	Camera::GetInstance()->SetTarget(_zeldaFollw);
	Vector2 leftBottom = {-_back->GetHalfSize().x, -_back->GetHalfSize().y};
	Vector2 rightTop = {-_back->GetHalfSize().x, -_back->GetHalfSize().y};
	Camera::GetInstance()->SetLeftBottom(leftBottom);
	Camera::GetInstance()->SetRightTop(rightTop);
}

CameraScene::~CameraScene()
{
}

void CameraScene::Update()
{
	 _back->Update();
	_zelda->Update();
	float distance = _zelda->GetTransform()->GetPos().Distance(_zeldaFollw->GetPos());
	if (distance >= 30.0f)
	{
		_zeldaFollw->GetScale() = LEFP(_zeldaFollw->GetPos(), _zelda->GetTransform()->GetPos(), 2.0f);
	}
}

void CameraScene::Render()
{
	 _back->Render();
	_zelda->Render();
}

void CameraScene::PostRender()
{
}

void CameraScene::SavePos()
{
	BinaryWriter wirter(L"SAVE/Zeldinfo,zelda");
	vector<float> dataes;
	dataes.push_back(_zelda->GetTransform()->GetPos().x);
	dataes.push_back(_zelda->GetTransform()->GetPos().y);
	wirter.Uint(dataes.size());
	wirter.Byte(dataes.data(),sizeof(float)*dataes.size());
}

Vector2 CameraScene::LoadPos()
{
	BinaryRedaer reader(L"SAVE/Zeldinfo,zelda");
	UINT size = reader.Uint();
	vector<float> dataes;
	dataes.resize(size);
	void* ptr = (void*)dataes.data();
	reader.Byte(&ptr, sizeof(float) * dataes.size());
	
	Vector2 tempPos;
	if (dataes.size() == 0)
	{
		tempPos = { 0.0f,0.0f };
		return tempPos;
	}
	tempPos.x = dataes[0];
	tempPos.y = dataes[1];
	return tempPos;
}


