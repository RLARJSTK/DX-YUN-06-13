#include "framework.h"
#include "ZeldaScene.h"

ZeldaScene::ZeldaScene()
{
	_zelda = make_shared<Zelda>();
	//_zelda->SetAnimation();
	//_zelda->SetClip();

}

ZeldaScene::~ZeldaScene()
{
}

void ZeldaScene::Update()
{
	_zelda->Update();
	//if (KEY_PRESS('W'))
	//{
	//	_zelda->;
	//}
	//if (KEY_PRESS('S'))
	//{
	//	_zelda->GetTransform()->GetPos().y -= 100.0f * DELTA_TIME;
	//}
	//if (KEY_PRESS('A'))
	//{
	//	_zelda->GetTransform()->GetPos().x -= 100.0f * DELTA_TIME;
	//}
	//if (KEY_PRESS('D'))
	//{
	//	_zelda->GetTransform()->GetPos().x += 100.0f * DELTA_TIME;
	//}
}

void ZeldaScene::Render()
{
	_zelda->Render();
}

void ZeldaScene::PostRender()
{
	_zelda->PostRender();

}
