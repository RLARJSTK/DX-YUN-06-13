#include "framework.h"
#include "ZeldaScene.h"

ZeldaScene::ZeldaScene()
{
	_zelda = make_shared<Zelda>();
	_zeldaPos = { WIN_WIDTH * 0.5f, WIN_HEIGHT * 0.5f };
	_zelda->SetPostion(WIN_WIDTH * 0.5f, WIN_HEIGHT * 0.5f);
}

ZeldaScene::~ZeldaScene()
{
}

void ZeldaScene::Update()
{
	_zelda->Update();

	_zelda->SetPostion(_zeldaPos.x, _zeldaPos.y);
}

void ZeldaScene::Render()
{
	_zelda->Render();
}

void ZeldaScene::PostRender()
{
	_zelda->PostRender();
}


