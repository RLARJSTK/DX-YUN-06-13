#pragma once
class EffectScene :public Scene
{
public:
	EffectScene();
	virtual ~EffectScene();

	   virtual void Update()override;
	   virtual void Render()override;
	   virtual void PreRender()override;

private:
	//shared_ptr<Effect>_effect;
	shared_ptr<Quad> _quad;

};
