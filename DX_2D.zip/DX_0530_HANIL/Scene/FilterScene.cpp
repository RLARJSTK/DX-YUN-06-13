#include "framework.h"
#include "FilterScene.h"

FilterScene::FilterScene()
{
	_quad = make_shared<Quad>(L"Resource/Castle.png", L"Shaders/TextureVertexShader.hlsl",L"Shaders/FilterShader/FilterShader.hlsl");
	_quad->GetTransform()->GetPos() = { WIN_WIDTH * 0.5f , WIN_HEIGHT * 0.5f };
	_quad->GetTransform()->GetScale() *= 0.5f;

	_filter = make_shared<FilterBuffer>();
	_filter->data.value1 = 60;
	_image = make_shared<ImageSizeBuffer>();
	_image->data.size = _quad->GetHalfSize()*2.0f;

	_sun= make_shared<Quad>(L"Resource/sun.png", L"Shaders/TextureVertexShader.hlsl", L"Shaders/FilterShader/FilterShader.hlsl");
	_sun->GetTransform()->GetPos() = { WIN_WIDTH * 0.5f , WIN_HEIGHT * 0.5f };
	_sun->GetTransform()->GetScale() *= 0.2f;
	_filturn = make_shared<FilterBuffer>();
	_filturn->data.selected = 6;


}

FilterScene::~FilterScene()
{
}

void FilterScene::Update()
{
	_quad->Update();
	_sun->Update();
}

void FilterScene::Render()
{
	_quad->Render();
	_filter->SetPSBuffer(0);
	_image->SetPSBuffer(1);
	
	_sun->Render();
	_filturn->SetPSBuffer(0);

}

void FilterScene::PostRender()
{
	ImGui::SliderInt("Mosaic", &(_filter->data.value1), 0, 2160);
	ImGui::SliderInt("selected", &(_filter->data.selected), 0, 1980);
	ImGui::SliderInt("Mosaic", &(_filter->data.value1), 0, 100);
	ImGui::SliderInt("Blur", &(_filter->data.value2), 0, 30);
	ImGui::SliderInt("Radial", &(_filter->data.value3), 0, 50);
}
