#include "framework.h"
#include "TextureScene.h"

TextureScene::TextureScene()
{
	_quad = make_shared<Quad>(L"Resource/Bazel.png", L"Shaders/TextureVertexShader.hlsl", L"Shader/LeftRightPixelShader.hisl");
	_quad->GetTransform()->GetPos()=CENTER;
	_filter = make_shared<FilterBuffer>();
	_filter->data.selected = 1;
}

TextureScene::~TextureScene()
{
}

void TextureScene::Update()
{

	_quad->Update();
}

void TextureScene::Render()
{
	_filter->SetPSBuffer(0);
	_quad->Render();
}