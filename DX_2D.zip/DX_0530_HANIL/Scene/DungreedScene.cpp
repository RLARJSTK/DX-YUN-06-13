#include "framework.h"
#include "DungreedScene.h"

DungreedScene::DungreedScene()
{
	_player = make_shared<Player>();
	_aim = make_shared<Quad>(L"Resource/aim.png");
	_aim->GetTransform()->GetScale() *= 0.2f;

	_enemy = make_shared<Enemy>();

	_enemy->GetTransform()->GetPos() = Vector2(WIN_WIDTH, WIN_HEIGHT) * 0.8f;

	_zelda = make_shared<Sprite>(L"Resource/zelda.png", Vector2(10,8));
	_zelda->GetTransform()->GetPos() = Vector2(WIN_WIDTH, WIN_HEIGHT) * 0.5f;

	// action
	// 1200, 1040
	
	vector<Action::Clip> clips;
	float y = 1040 * 0.5f;
	float w = 1200 / 10;
	float h = 1040 / 8;

	{ // ������ �޸���
		clips.emplace_back(0		, y, w, h, Texture::Add(L"Resource/zelda.png"));
		clips.emplace_back(0 + w	, y, w, h, Texture::Add(L"Resource/zelda.png"));
		clips.emplace_back(0 + w * 2, y, w, h, Texture::Add(L"Resource/zelda.png"));
		clips.emplace_back(0 + w * 3, y, w, h, Texture::Add(L"Resource/zelda.png"));
		clips.emplace_back(0 + w * 4, y, w, h, Texture::Add(L"Resource/zelda.png"));
		clips.emplace_back(0 + w * 5, y, w, h, Texture::Add(L"Resource/zelda.png"));
		clips.emplace_back(0 + w * 6, y, w, h, Texture::Add(L"Resource/zelda.png"));
		clips.emplace_back(0 + w * 7, y, w, h, Texture::Add(L"Resource/zelda.png"));
		clips.emplace_back(0 + w * 8, y, w, h, Texture::Add(L"Resource/zelda.png"));
		clips.emplace_back(0 + w * 9, y, w, h, Texture::Add(L"Resource/zelda.png"));
	}

	_action = make_shared<Action>(clips);
	// Spite�� SetAction �߰�
}

DungreedScene::~DungreedScene()
{
}

void DungreedScene::Update()
{
	_player->Update();
	_enemy->Update();
	_aim->Update();

	_zelda->Update();
	_action->Update();
	_zelda->SetClip(_action->GetCurClip());

	_player->AttackEnemy(_enemy);

	_aim->GetTransform()->GetPos() = MOUSE_POS;
}

void DungreedScene::Render()
{
	_player->Render();
	_zelda->Render();
	_enemy->Render();
	_aim->Render();
}

void DungreedScene::PostRender()
{
}
