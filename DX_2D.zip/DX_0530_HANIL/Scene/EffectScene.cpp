#include "framework.h"
#include "EffectScene.h"

EffectScene::EffectScene()
{
	_effect = make_shared<Effect>();

}

EffectScene::~EffectScene()
{
}

void EffectScene::Update()
{
	_effect->Update();
}

void EffectScene::Render()
{
	_effect->Render();
}

void EffectScene::PreRender()
{
}
