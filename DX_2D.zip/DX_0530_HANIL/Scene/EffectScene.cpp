#include "framework.h"
#include "EffectScene.h"

EffectScene::EffectScene()
{
	EffectManger::GetInstance()->Add(L"Resource/Effects/skill_core_4x4.png", Vector2{ 4,4 }, 0.1f);
	//_effect->Player(CENTER);
}

EffectScene::~EffectScene()
{
}

void EffectScene::Update()
{
	//if (KEY_DOWN("W"))
	//{
	//	EffectManger::GetInstance()->Play("skill_core_4x4.png", CENTER);
	//}
	//_effect->Update();
}

void EffectScene::Render()
{
	//_effect->Render();
}

void EffectScene::PreRender()
{
}
