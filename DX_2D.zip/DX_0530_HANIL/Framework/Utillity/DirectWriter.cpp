#include "framework.h"
#include "DirectWriter.h"
DirectWrite* DirectWrite::_instance = nullptr;

DirectWrite::DirectWrite()
{
	assert(SUCCEEDED (DWriteCreateFactory (DWRITE_FACTORY_TYPE_SHARED, __uuidof(IDWriteFactory), (IUnknown**)&_writeFactory)));
	assert(SUCCEEDED (D2D1CreateFactory (D2D1_FACTORY_TYPE_MULTI_THREADED), _factory.GetAddressOf()));
	ComPtr<IDXGIDevice> dxgidDevice;
	assert(SUCCEEDED(DEVICE->QueryInterface(dxgidDevice.Get())));
	assert(SUCCEEDED(_factory->CreateDevice(dxgidDevice.Get(), _device.GetAddressOf())));
	assert(SUCCEEDED(_device->CreateDeviceContext(D2D1_DEVICE_CONTEXT_OPTIONS_ENABLE_MULTITHREADED_OPTIMIZATIONS, _deviceContext.GetAddressOf())));
	ComPtr<IDXGISurface> dxgiSurface;
	assert(SUCCEEDED(Device::GetInstance()->GetswapChain))
}
DirectWrite::~DirectWrite()
{
}
void DirectWrite::RenderText(wstring text, RECT rect, float fontSize, wstring font, XMFLOAT4 color, DWRITE_FONT_WEIGHT weight, DWRITE_FONT_STYLE style, DWRITE_FONT_STRETCH stretch)
{
	FontBrushDesc	brushDesc;
	brushDesc. _color = color;
	FontBrushDesc* findbrush = nullptr;
	for (FontBrushDesc& desc : _fontBrushes)
	{
		if(desc == brushDesc)
		{
			findbrush = &desc;
			return;
		}
	}
	if (findbrush == nullptr)
	{
		D2D1::ColorF colorF = D2D1::ColorF(color.x, color.y, color.z);
		_deviceContext->CreateSolidColorBrush(colorF, brushDesc, _brush.GetAddressOf());
		_fontBrushes
	}
}