class BinaryRedaer
{
public:
	BinaryRedaer(wstring filePath);
	~BinaryRedaer();
	int Int(int data);
	UINT Uint(UINT data);
	float Float(float data);
	string String(string data);
	void Byte(void** data, UINT datasize);
private:
	HANDLE _file;
	DWORD _size;
};