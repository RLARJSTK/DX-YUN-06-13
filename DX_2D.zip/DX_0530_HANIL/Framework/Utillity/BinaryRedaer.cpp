#include "framework.h"
#include "BinaryRedaer.h"

BinaryRedaer::BinaryRedaer(wstring filePath)
	:_size(0)
{
	_file = CreateFile(filePath.c_str(), GENERIC_READ,FILE_SHARE_READ,0,OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, nullptr);
}

BinaryRedaer::~BinaryRedaer()
{
	CloseHandle(_file);
}

int BinaryRedaer::Int()
{
	int temp;
	assert(ReadFile(_file, &temp, sizeof(int),OUT&_size, nullptr));
	return temp;
}

UINT BinaryRedaer::Uint()
{
	UINT temp;
	assert(ReadFile(_file, &temp, sizeof(UINT), OUT & _size, nullptr));
	return temp;
}

float BinaryRedaer::Float()
{
	float temp;
	assert(ReadFile(_file, &temp, sizeof(float), OUT & _size, nullptr));
	return temp;
}

string BinaryRedaer::String()
{
	UINT size = Uint();
	char* temp = new char[size + 1];
	assert(ReadFile(_file, temp, sizeof(char) * size, OUT & _size, nullptr));
	return temp;
}

void BinaryRedaer::Byte(void** data, UINT datasize)
{
	assert(ReadFile(_file, *data, datasize, OUT & _size, nullptr));
}
