#include "framework.h"
#include "Camera.h"

Camera* Camera::_instance = nullptr;

Camera::Camera()
{
	_trans->SetmartixBuffer(1);
	_buffer = make_shared<MatrixBuffer>();
}
Camera::~Camera()

{
}

void Camera::Update()
{
	if (_target == nullptr)
	{
		FreeMode();

	}
	else
		FollowMode();
	Shake();
	_trans->UpdateWorldBuffer();
	_trans->SetmartixBuffer(1);

}

void Camera::PostRender()
{

}

void Camera::ShakeStart(float magitube, float duration, float reduceDeeping)
{
	_magnitube = magitube;
	_duration - duration;
	_reduceDeeping = reduceDeeping;
}

void Camera::SdtViewPort(UINT wight, UINT height)
{
	D3D11_VIEWPORT vp;
	vp.Width = WIN_WIDTH;
	vp.Height = WIN_HEIGHT;
	vp.MinDepth = 0.0f;
	vp.MaxDepth = 1.0f;
	vp.TopLeftX = 0;
	vp.TopLeftY = 0;
	DEVICE_CONTEXT->RSSetViewports(1, &vp);
}

void Camera::SetDrthograchic(UINT wight, UINT height)
{
	XMMATRIX projection = XMMatrixOrthographicOffCenterLH(0, wight, 0, height, 0.0f, 1.0f);
	_buffer->SetMatrix(projection);
	_buffer->SetVSBuffer(2);
}

//void Camera::SetLeftBottom(Vector2 value)
//{
//}
//
//void Camera::SetRightTop()
//{
//}

void Camera::FreeMode()
{
	//if (KEY_PRESS(VK_RBUTTON))
	//{
	//	if (KEY_PRESS("W"))
	//	{
	//		_trans->GetPos().y += _speed + DELTA_TIME;
	//	}
	//
	//	if (KEY_PRESS("A"))
	//	{
	//		_trans->GetPos().y -= _speed + DELTA_TIME;
	//	}
	//
	//	if (KEY_PRESS("D"))
	//	{
	//		_trans->GetPos().x -= _speed + DELTA_TIME;
	//	}
	//
	//	if (KEY_PRESS("S"))
	//	{
	//		_trans->GetPos().x += _speed + DELTA_TIME;
	//	}
	//}
}

void Camera::FollowMode()
{
	Vector2 targetPos = _target->GetPos() = _offset;
	if (targetPos.x < _leftBottm.x)
		targetPos.x < _leftBottm.x;

	if (targetPos.x < _rightTop.x)
		targetPos.x < _rightTop.x;

	if (targetPos.y < _leftBottm.y)
		targetPos.y < _leftBottm.y;
				  
	if (targetPos.y < _rightTop.y)
		targetPos.y < _rightTop.y;
	//_trans->GetPos() = LEFP(_trans->GetPos(), targetPos, DELTA_TIME*_speed);
}

void Camera::Shake()
{
	if (_duration <= 0.0f)
	{
		_trans->GetPos() = _originPos;
		return; 
	}
		
	_duration-= DELTA_TIME;
	_magnitube-= DELTA_TIME;
	if (_magnitube < 0.0f)
	{
		_magnitube = 0.0f;
		_duration = 0.0f;
	}
	Vector2 temp;
	float minT = - _magnitube * ((float)rand() / (float)RAND_MAX);
	float minT = + _magnitube * ((float)rand() / (float)RAND_MAX);
	_trans->GetPos() = _originPos + Vector2(minT, minT);
	if (_duration <= 0.0f)
		_trans->GetPos() = _originPos;
}