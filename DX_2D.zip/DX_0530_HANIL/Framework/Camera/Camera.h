class Camera
{
public:
	static void Create()
	{
		if (_instance == nullptr)
		{
			_instance = new Camera();
		}
	}

	static void Delete()
	{
		if (_instance != nullptr)
		{
			delete _instance;
		}
	}

	static Camera* GetInstance()
	{
		if (_instance != nullptr)
			return _instance;

		return nullptr;
	}

	void Update();
	void PostRender();
	void ShakeStart(float magitube, float duration, float reduceDeeping = 0.0f);
	void SetViewPort(UINT wight = WIN_WIDTH, UINT height = WIN_HEIGHT);
	void SetDrthograchic(UINT wight = WIN_WIDTH, UINT height = WIN_HEIGHT);
	void SetTarget(shared_ptr<Transform> transform) { _target = transform; }
	void SetLeftBottom(Vector2 value) { _leftBottm = value; }
	void SetRightTop(Vector2 value) { _rightTop = value; }
private:
	Camera();
	~Camera();
	void FreeMode();
	void FollowMode();
	void Shake();
	shared_ptr<Transform> _trans;
	static Camera* _instance;
	float _speed = 200.0f;
	float _zoomSpeed = 1.0f;
	shared_ptr<Transform> _target;
	Vector2 _offset = CENTER;
	Vector2 _leftBottm;
	Vector2 _rightTop;
	float _duration=0.0f;
	float _reduceDeeping=0.0f;
	float _magnitube=0.0f;
	Vector2 _originPos;
		shared_ptr <MatrixBuffer> _buffer;
};