#include "framework.h"
#include "Shader.h"

Shader::Shader()
{
}

Shader::~Shader()
{
}
