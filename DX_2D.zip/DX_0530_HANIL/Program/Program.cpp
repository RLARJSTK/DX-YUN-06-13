#include "framework.h"
#include "Program.h"

#include "../Scene/TextureScene.h"
#include "../Scene/TextureWVPScene.h"
#include "../Scene/SolarSystemScene.h"
#include "../Scene/DungreedScene.h"
#include "../Scene/ColliderScene.h"
#include "../Scene/ZeldaScene.h"
#include "../Scene/FilterScene.h"
#include "../Scene/EffectScene.h"
#include "../Scene/CameraScene.h"

Program::Program()
{
	_scene = make_shared<CameraScene>();


	
	//Timer::GetInstance()->SetFPS(60);
}

Program::~Program()
{
}

void Program::Update()
{
	EffectManger::GetInstance()->Update();
	Camera::GetInstance()->Update();
	_scene->Update();
}

void Program::Render()
{
	Device::GetInstance()->Clear();

	ImGui_ImplDX11_NewFrame();
	ImGui_ImplWin32_NewFrame();
	ImGui::NewFrame();

	ALPHA_STATE->SetState();
	Camera::GetInstance()->SetViewPort();
	Camera::GetInstance()->SetDrthograchic();

	_viewBuffer->SetVSBuffer(1);
	_projectionBuffer->SetVSBuffer(2);

	_scene->PreRender();

	_scene->Render();
	EffectManger::GetInstance()->Render();
	//ImGui::Text("FPS : %d", Timer::GetInstance()->GetFPS());
	_scene->PostRender();

	ImGui::Render();
	ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());

	Device::GetInstance()->Present();
}
