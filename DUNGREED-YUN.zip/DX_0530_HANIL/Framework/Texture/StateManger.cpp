#include "framework.h"
#include "StateManger.h"
StateManger* StateManger::_instance = nullptr;

StateManger::StateManger()
{
	_samplerState =  make_shared<SamplerState>();
	_alphaState =    make_shared<BlendState>();
	_alphaState->Alpha();
	_additiveState = make_shared<BlendState>();
	_additiveState->Additive();
	_blendState =   make_shared<BlendState>();
	_rasterizerState = make_shared<RasterizerState >();

}
StateManger::~StateManger()
{
}
