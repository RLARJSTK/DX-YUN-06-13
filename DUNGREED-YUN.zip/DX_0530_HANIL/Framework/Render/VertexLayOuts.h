#pragma once

struct VertexPos
{
	XMFLOAT3 pos;
};

struct VertexUV
{
	XMFLOAT3 pos;
	XMFLOAT2 uv;
};