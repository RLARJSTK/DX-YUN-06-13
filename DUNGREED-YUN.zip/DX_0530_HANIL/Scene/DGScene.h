#pragma once
class DGScene : public Scene
{
public:
	DGScene();
	virtual ~DGScene();

	// Scene��(��) ���� ��ӵ�
	virtual void Update() override;
	virtual void Render() override;

private:
	shared_ptr<Arin> _arin;
	shared_ptr<Werpon> _bow;
	shared_ptr<Bullet> _bullet;

};