#pragma once
class Arin
{
public:
	Arin();
	~Arin();
	void Update();
	void Render();

	shared_ptr<TransForm> GetTransform() { return _transForm; }
	bool _isActive = true;
private:
	
	shared_ptr<TransForm> _transForm;
	shared_ptr<Texture> _arin;
	shared_ptr<MatrixBuffer> _worldBuffer;
	XMFLOAT2 _worldPos = { 0,0 };
};