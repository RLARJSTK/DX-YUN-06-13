#include "framework.h"
#include "Arin.h"

Arin::Arin()
{
	_arin = make_shared<Texture>(L"Resource/ARIN.png");
    _transForm = make_shared<TransForm>();
	
	_worldBuffer = make_shared<MatrixBuffer>();
}

Arin::~Arin()
{
}

void Arin::Update()
{
	if (GetAsyncKeyState(VK_LEFT))
	{
		_arin->GetTransform()->GetPos().x -= 5.0f;
	}
	if (GetAsyncKeyState(VK_RIGHT))
	{
		_arin->GetTransform()->GetPos().x += 5.0f;
	}
	if (GetAsyncKeyState(VK_UP))
	{
		_arin->GetTransform()->GetPos().y += 5.0f;
	}
	if (GetAsyncKeyState(VK_DOWN))
	{
		_arin->GetTransform()->GetPos().y -= 5.0f;
	}
    _transForm->UpdateWorldBuffer();
	_arin->Update();

	
	_worldBuffer->Update();
	
}

void Arin::Render()
{
	_worldBuffer->SetVSBuffer(0);
	_transForm->SetWorldBuffer(0);
	_arin->Render();
}
