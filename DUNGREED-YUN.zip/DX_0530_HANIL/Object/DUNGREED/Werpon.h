#pragma once
class Werpon
{
public:
	Werpon();
	~Werpon();
	void Update();
	void Render();

	shared_ptr<TransForm> GetTransform() { return _transForm; }
	float& GetBarrelAngle() { return _barrelAngle; }
	void Fire();
	bool BulletHit(shared_ptr<Arin> _arin);
	bool _isActive = true;
private:

	shared_ptr<TransForm> _transForm;
	shared_ptr<Texture> _bow;
	shared_ptr<Arin> _arin;
	shared_ptr<Bullet> _bullet;
	float _fireSpeed = 5.0f;
	float _barrelAngle = 0.0f;
};