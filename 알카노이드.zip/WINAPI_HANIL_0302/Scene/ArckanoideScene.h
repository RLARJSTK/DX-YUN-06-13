
class ArckanoideScene : public Scene
{
public:
	ArckanoideScene();
	virtual ~ArckanoideScene();

	virtual void Update() override;
	virtual void Render(HDC hdc) override;

private:
	unsigned int _poolCountX = 25;
	unsigned int _poolCountY = 25;
	shared_ptr<Ball> _ball;
	shared_ptr<Stick> _stick;
	shared_ptr<Block> _blocks;
	
	

};