#include "Framework.h"
#include "LineScene.h"

LineScene::LineScene()
: _isCollision(false)
{
	_line1 = make_shared<Line>();
	_line1->_startPos = { 50,550 };
	_line1->_endPos = { 700, 60 };
	_line2 = make_shared<Line>();
	_line2->_startPos = { 100,50 };
	_line2->_endPos = { 50, 550 };

	_shadow = make_shared<Line>();
	_shadow->_startPos = { 100,530 };
	_shadow->_endPos = { 300, 530 };

	_circle = make_shared<CircleCollider>(5, Vector2(0,0));

	_pens.push_back(CreatePen(PS_SOLID, 3, RGB(0, 255, 0)));
	_pens.push_back(CreatePen(PS_SOLID, 3, RGB(255, 0, 0)));
}

LineScene::~LineScene()
{
	for (auto& pen : _pens)
		DeleteObject(pen);
}

void LineScene::Update()
{
	_line2->_endPos._x = mousePos._x;
	_line2->_endPos._y = mousePos._y;

	Vector2 line1Vec = _line1->_endPos - _line1->_startPos;
	Vector2 line2Vec = _line2->_endPos - _line2->_startPos;

	float shadowLength = line2Vec.Shadow(line1Vec);
	_shadow->_endPos = { _shadow->_startPos._x + shadowLength, 530 };

	_isCollision = _line2->IsCollision(_line1);

	float crossA = line1Vec.Cross(line2Vec);
	float crossB = (_line2->_startPos - _line1->_startPos).Cross(line1Vec);

	float t = crossB / crossA;

	_circle->Move(_line2->_startPos + (_line2->_endPos - _line2->_startPos) * t);
}

void LineScene::Render(HDC hdc)
{
	if (_isCollision)
	{
		_circle->Render(hdc);
		SelectObject(hdc, _pens[1]);
	}
	else
	{
		SelectObject(hdc, _pens[0]);
	}

	_line1->Render(hdc);
	_line2->Render(hdc);
	_shadow->Render(hdc);
}
