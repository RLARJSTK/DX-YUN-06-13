#pragma once
class PaintScene : public Scene
{
public:
	PaintScene();
	virtual ~PaintScene();

	virtual void Update() override;
	virtual void Render(HDC hdc) override;

private:
	shared_ptr<Collider> _circleCol;
	shared_ptr<Collider> _circleCol2;
	shared_ptr<Collider> _rectCol;
	shared_ptr<Collider> _rectCol2;
};

