#include "Framework.h"
#include "PaintScene.h"
#include <string>

PaintScene::PaintScene()
{
	_circleCol = make_shared<CircleCollider>(100.0f, Vector2(500.0f, 500.0f));
	_circleCol2 = make_shared<CircleCollider>(100.0f, Vector2(500.0f, 500.0f));
	_rectCol = make_shared<RectCollider>(Vector2(100.0f,50.0f),Vector2(500.0f,250.0f));
	_rectCol2 = make_shared<RectCollider>(Vector2(100.0f,50.0f),Vector2(500.0f,250.0f));
}

PaintScene::~PaintScene()
{
}

void PaintScene::Update()
{
	// �� ���콺�� �� ���� ��ġ�� �� ���� ���������� �ٲٰ� �ʹ�.
	/*if (_circleCol->IsCollision(*_circleCol2))
	{
		_circleCol->SetRedColor();
		_circleCol2->SetRedColor();
	}
	else
	{
		_circleCol->SetGreenColor();
		_circleCol2->SetGreenColor();
	}*/

	if (_rectCol->IsCollision(*_rectCol2))
	{
		_rectCol->SetRedColor();
	}
	else
	{
		_rectCol->SetGreenColor();
	}

	_rectCol2->Move(mousePos);

	_circleCol->Update();
	_circleCol2->Update();
	_rectCol->Update();
	_rectCol2->Update();
}

void PaintScene::Render(HDC hdc)
{
	_circleCol->Render(hdc);
	_circleCol2->Render(hdc);
	_rectCol->Render(hdc);
	_rectCol2->Render(hdc);

	
}
