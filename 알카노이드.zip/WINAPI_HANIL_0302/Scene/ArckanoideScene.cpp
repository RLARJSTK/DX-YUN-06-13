#include "Framework.h"
#include "ArckanoideScene.h"

ArckanoideScene::ArckanoideScene()
{
	_ball = make_shared<Ball>();
	_stick = make_shared<Stick>();
	_blocks = make_shared<Block>();
}

ArckanoideScene::~ArckanoideScene()
{
}

void ArckanoideScene::Update()
{
	if (GetAsyncKeyState(VK_LEFT))
	{
		_stick->GetBody()->_center -= Vector2(1.0f, 0.0f) * 3.5;
	}
	if (GetAsyncKeyState(VK_RIGHT))
	{
		_stick->GetBody()->_center += Vector2(1.0f, 0.0f) * 3.5f;
	}
	if (GetAsyncKeyState(VK_UP))
	{
		_stick->GetBarrelAngle() -= 0.1f;
	}

	if (GetAsyncKeyState(VK_DOWN))
	{
		_stick->GetBarrelAngle() += 0.1f;
	}
	if (GetAsyncKeyState(VK_SPACE))
	{
		_stick->Fire();
	}
	_ball->Update();
	_stick->Update();
	_blocks->Update();
	
}

void ArckanoideScene::Render(HDC hdc)
{
	_ball->Render(hdc);
	_stick->Render(hdc);
	_blocks->Render(hdc);
}
