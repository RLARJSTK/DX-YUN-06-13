#include "Framework.h"
#include "Program.h"

#include "../Scene/PaintScene.h"
#include "../Scene/LineScene.h"
#include "../Scene/PotrisScene.h"
#include "../Scene/ArckanoideScene.h"

Program::Program()
{
	_scene = make_shared<ArckanoideScene>();
}

Program::Program(HWND hWnd)
{
	
	_scene = make_shared<ArckanoideScene>();
}

Program::~Program()
{

}

void Program::Update()
{
	_scene->Update();
}

void Program::Render(HDC hdc)
{
	
	_scene->Render(hdc);

}
