#pragma once
//����
class Bullet
{
public:
	Bullet();
	~Bullet();

	void Update();
	void Render(HDC hdc);

	void Fire(Vector2 vector, float speed, Vector2 startPos);
	bool IsCollision(shared_ptr<class Cannon> cannon);

	bool _isActive = true;

private:
	shared_ptr<CircleCollider> _bullet;
	Vector2 _moveVector;
	float _downVelocity = 0.0f;
	
};

