#include "Framework.h"
#include "Cannon.h"
//������
Cannon::Cannon()
{
	_body = make_shared<CircleCollider>(80, Vector2(CENTER_X, CENTER_Y));
	_barrel = make_shared<Line>();
	_barrel->_startPos = _body->GetCenter();
	_barrel->_endPos = Vector2(_body->_center._x + 150, _body->_center._y);


	for (int i = 0; i < _poolCount; i++)
	{
		shared_ptr<Bullet> temp = make_shared<Bullet>();
		temp->_isActive = false;
		_bullets.emplace_back(temp);
	}
}

Cannon::~Cannon()
{
}

void Cannon::Update()
{
	if (_isActive == false)
		return;

	// ��������
	_barrel->_startPos = _body->_center;
	_barrel->_endPos._x = _barrel->_startPos._x + cos(_barrelAngle) * 150;
	_barrel->_endPos._y = _barrel->_startPos._y + sin(_barrelAngle) * 150;

	_body->Update();
	_barrel->Update();
	for (auto& bullet : _bullets)
		bullet->Update();
}

void Cannon::Render(HDC hdc)
{
	if (_isActive == false)
		return;

	_body->Render(hdc);
	_barrel->Render(hdc);
	for (auto& bullet : _bullets)
		bullet->Render(hdc);
}

void Cannon::Fire()
{
	if (_isActive == false)
		return;


	Vector2 fireVector = _barrel->_endPos - _barrel->_startPos;
	for (auto& bullet : _bullets)
	{
		if (bullet->_isActive == false)
		{
			bullet->_isActive = true;
			bullet->Fire(fireVector, _fireSpeed, _barrel->_endPos);
			break;
		}
	}
	
}

bool Cannon::BulletHit(shared_ptr<Cannon> cannon)
{
	if (_isActive == false || cannon->_isActive == false)
		return false;

	for (auto& bullet : _bullets)
	{
		if (bullet->_isActive == false)
			continue;

		if (bullet->IsCollision(cannon))
		{
			bullet->_isActive = false;
			return true;
		}
	}

	return false;
}
