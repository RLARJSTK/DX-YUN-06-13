#include "Framework.h"
#include "Bullet.h"
//����
Bullet::Bullet()
: _moveVector(0,0)
{
	_bullet = make_shared<CircleCollider>(15, Vector2(0,0));
}

Bullet::~Bullet()
{
}

void Bullet::Update()
{
	if (_isActive == false)
		return;
	                               // �̺κ��̻������ �߷��ǿ����̻������
	_bullet->_center += _moveVector;// +Vector2(0, 1) * _downVelocity;
	_downVelocity += GRAVITY;
	//���忡�΋H��
	if (_bullet->_center._y <= STARTY+_bullet->GetRadius())
	{
		_moveVector._y *= -1;

	}
	//�Ʒ����΋H��
	if (_bullet->_center._y >= WIN_HEIGTH - _bullet->GetRadius())
	{
		_moveVector._y *= -1;

	}

	//���ʿ��΋H��
	if (_bullet->_center._x <= STARTX + _bullet->GetRadius())
	{
		_moveVector._x *= -1;

	}
	//�����ʿ��΋H��
	if (_bullet->_center._x >= WIN_WIDTH - _bullet->GetRadius())
	{
		_moveVector._x *= -1;

	}
}

void Bullet::Render(HDC hdc)
{
	if (_isActive == false)
		return;

	_bullet->Render(hdc);
}

void Bullet::Fire(Vector2 vector, float speed, Vector2 startPos)
{
	if (_isActive == false)
		return;

	_downVelocity = 0.0f;
	_bullet->_center = startPos;
	vector.Normallize();
	_moveVector = vector * speed * 3;
}

bool Bullet::IsCollision(shared_ptr<class Cannon> cannon)
{
	if (_isActive == false)
		return false;

	return _bullet->IsCollision(*cannon->GetBody().get());
}
