

#pragma once

class Stick
{
public:
	Stick();
	~Stick();

	void Update();
	void Render(HDC hdc);

	shared_ptr<RectCollider> GetBody() { return _body; }
	shared_ptr<Line> GetBarrel() { return _range; }
	float& GetBarrelAngle() { return _barrelAngle; }
	void Fire();
	bool BulletHit(shared_ptr<Stick> stick);
	bool _isActive = true;
private:
	shared_ptr<RectCollider> _body;
	shared_ptr<Line> _range;
	shared_ptr<Ball> _ball;
	//shared_ptr<Block> block;

	float _fireSpeed = 5.0f;
	float _barrelAngle = 0.0f;
};