#include "Framework.h"
#include "Ball.h"
#include "Framework.h"
#include "Ball.h"

Ball::Ball()
	: _moveVector(0, 0)
{
	_bullet = make_shared<CircleCollider>(15, Vector2(0, 0));
}

Ball::~Ball()
{
}

void Ball::Update()
{
	if (_isActive == false)
		return;

	_bullet->_center += _moveVector;
	_downVelocity += GRAVITY;
	//���忡�΋H��
	if (_bullet->_center._y <= STARTY + _bullet->GetRadius())
	{
		_moveVector._y *= -1;

	}
	///�Ʒ����΋H��
	//if (_bullet->_center._y >= WIN_HEIGTH - _bullet->GetRadius())
	//{
	//	_moveVector._y *= -1;
	//
	//}
   //
	//���ʿ��΋H��
	if (_bullet->_center._x <= STARTX + _bullet->GetRadius())
	{
		_moveVector._x *= -1;

	}
	//�����ʿ��΋H��
	if (_bullet->_center._x >= WIN_WIDTH - _bullet->GetRadius())
	{
		_moveVector._x *= -1;

	}
}

void Ball::Render(HDC hdc)
{
	if (_isActive == false)
		return;

	_bullet->Render(hdc);
}

void Ball::Fire(Vector2 vector, float speed, Vector2 startPos)
{
	if (_isActive == false)
		return;

	_downVelocity = 0.0f;
	_bullet->_center = startPos;
	vector.Normallize();
	_moveVector = vector * speed * 3;
}

bool Ball::IsCollision(shared_ptr<class Stick> cannon)
{
	if (_isActive == false)
		return false;

	return _bullet->IsCollision(*cannon->GetBody().get());
}
