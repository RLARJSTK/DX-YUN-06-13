#include "Framework.h"
#include "Stick.h"


Stick::Stick()
{
	_body = make_shared<RectCollider>(Vector2(100.0f, 15.0f), Vector2(CENTER_X, CENTER_Y+200));
	_range = make_shared<Line>();
	_range->_startPos = _body->GetCenter();
	_range->_endPos = Vector2(_body->_center._x + 150, _body->_center._y);
	_ball = make_shared<Ball>();
	_ball->_isActive = false;
	
}

Stick::~Stick()
{
}

void Stick::Update()
{
	if (_isActive == false)
		return;

	// ��������
	_range->_startPos = _body->_center;
	_range->_endPos._x = _range->_startPos._x + cos(_barrelAngle) * 150;
	_range->_endPos._y = _range->_startPos._y + sin(_barrelAngle) * 150;

	_body->Update();
	_range->Update();
	_ball->Update();
}

void Stick::Render(HDC hdc)
{
	if (_isActive == false)
		return;

	_body->Render(hdc);
	_range->Render(hdc);
	_ball->Render(hdc);
	
}
void Stick::Fire()
{
	if (_isActive == false)
		return;

	_ball->_isActive = true;
	Vector2 fireVector = _range->_endPos - _range->_startPos;
	_ball->Fire(fireVector, _fireSpeed, _range->_endPos);
	
}

bool Stick::BulletHit(shared_ptr<Stick> stick)
{
	if (_isActive == false || stick->_isActive == false)
		return false;
	if (_ball->IsCollision(stick))
	{
		_ball->_isActive = false;
		return true;
	}

	return false;
}
