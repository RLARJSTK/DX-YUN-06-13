#pragma once
class Block
{public:
	Block();
	~Block();

	void Update();
	void Render(HDC hdc);
	bool BallHit(shared_ptr<Stick>stick);
	bool _isActive = true;

private:
	
	shared_ptr<RectCollider> _rect1;
	shared_ptr<RectCollider> _rect2;
	shared_ptr<RectCollider> _rect3;
	shared_ptr<RectCollider> _rect4;
	shared_ptr<RectCollider> _rect5;
	shared_ptr<RectCollider> _rect6;
	shared_ptr<RectCollider> _rect7;
	shared_ptr<RectCollider> _rect8;
	shared_ptr<RectCollider> _rect9;
	shared_ptr<RectCollider> _rect10;
	shared_ptr<RectCollider> _rect11;
	shared_ptr<RectCollider> _rect12;
	shared_ptr<RectCollider> _rect13;
	shared_ptr<RectCollider> _rect14;
	shared_ptr<RectCollider> _rect15;
	shared_ptr<RectCollider> _rect16;
	shared_ptr<RectCollider> _rect17;
	shared_ptr<RectCollider> _rect18;
	shared_ptr<RectCollider> _rect19;
	shared_ptr<RectCollider> _rect20;
	shared_ptr<RectCollider> _rect21;
	shared_ptr<RectCollider> _rect22;
	shared_ptr<RectCollider> _rect23;
	shared_ptr<RectCollider> _rect24;
	shared_ptr<RectCollider> _rect25;
	shared_ptr<RectCollider> _rect26;
	shared_ptr<RectCollider> _rect27;
	shared_ptr<RectCollider> _rect28;
	shared_ptr<RectCollider> _rect29;
	shared_ptr<RectCollider> _rect30;
	shared_ptr<RectCollider> _rect31;
	shared_ptr<RectCollider> _rect32;
	shared_ptr<RectCollider> _rect33;
	shared_ptr<RectCollider> _rect34;
	shared_ptr<RectCollider> _rect35;
	shared_ptr<RectCollider> _rect36;
	shared_ptr<RectCollider> _rect37;
	shared_ptr<RectCollider> _rect38;
	shared_ptr<RectCollider> _rect39;
	shared_ptr<RectCollider> _rect40;
	shared_ptr<RectCollider> _rect41;
	shared_ptr<RectCollider> _rect42;
	shared_ptr<RectCollider> _rect43;
	shared_ptr<RectCollider> _rect44;
	shared_ptr<RectCollider> _rect45;
	shared_ptr<RectCollider> _rect46;
	shared_ptr<RectCollider> _rect47;
	shared_ptr<RectCollider> _rect48;
	shared_ptr<RectCollider> _rect49;
	shared_ptr<RectCollider> _rect50;
	shared_ptr<RectCollider> _rect51;
	shared_ptr<RectCollider> _rect52;
	shared_ptr<RectCollider> _rect53;
	shared_ptr<RectCollider> _rect54;
	shared_ptr<RectCollider> _rect55;
	shared_ptr<RectCollider> _rect56;
	shared_ptr<RectCollider> _rect57;
	shared_ptr<RectCollider> _rect58;
	shared_ptr<RectCollider> _rect59;
	shared_ptr<RectCollider> _rect60;
	
	shared_ptr<Ball> _ball;
	Vector2 _moveVector;
	
	float _downVelocity = 0.0f;
};