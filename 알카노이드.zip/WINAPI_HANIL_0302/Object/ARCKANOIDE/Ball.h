
#pragma once
class Ball
{
public:
	Ball();
	~Ball();

	void Update();
	void Render(HDC hdc);

	void Fire(Vector2 vector, float speed, Vector2 startPos);
	bool IsCollision(shared_ptr<class Stick> cannon);
	
	bool _isActive = true;

private:
	shared_ptr<CircleCollider> _bullet;
	
	Vector2 _moveVector;
	float _downVelocity = 0.0f;

};