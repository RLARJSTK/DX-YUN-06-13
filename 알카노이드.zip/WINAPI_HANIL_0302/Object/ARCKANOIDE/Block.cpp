#include "Framework.h"
#include "Block.h"

Block::Block()
{                                                      //+=����-=������ ,+= �Ʒ���-=����
	 _rect1 = make_shared<RectCollider>(Vector2(25, 10), Vector2(CENTER_X-500, CENTER_Y-250));
	 _rect2 = make_shared<RectCollider>(Vector2(25, 10), Vector2(CENTER_X-450, CENTER_Y-250));
	 _rect3 = make_shared<RectCollider>(Vector2(25, 10), Vector2(CENTER_X-400, CENTER_Y-250));
	 _rect4 = make_shared<RectCollider>(Vector2(25, 10), Vector2(CENTER_X-350, CENTER_Y-250));
	 _rect5 = make_shared<RectCollider>(Vector2(25, 10), Vector2(CENTER_X-300, CENTER_Y-250));
	 _rect6 = make_shared<RectCollider>(Vector2(25, 10), Vector2(CENTER_X-250, CENTER_Y-250));
	 _rect7 = make_shared<RectCollider>(Vector2(25, 10), Vector2(CENTER_X-200, CENTER_Y-250));
	 _rect8 = make_shared<RectCollider>(Vector2(25, 10), Vector2(CENTER_X-150, CENTER_Y-250));
	 _rect9 = make_shared<RectCollider>(Vector2(25, 10), Vector2(CENTER_X-100, CENTER_Y-250));
	_rect10 = make_shared<RectCollider>(Vector2(25, 10), Vector2(CENTER_X- 50, CENTER_Y-250));
	_rect11 = make_shared<RectCollider>(Vector2(25, 10), Vector2(CENTER_X-500, CENTER_Y-230));
	_rect12 = make_shared<RectCollider>(Vector2(25, 10), Vector2(CENTER_X-450, CENTER_Y-230));
	_rect13 = make_shared<RectCollider>(Vector2(25, 10), Vector2(CENTER_X-400, CENTER_Y-230));
	_rect14 = make_shared<RectCollider>(Vector2(25, 10), Vector2(CENTER_X-350, CENTER_Y-230));
	_rect15 = make_shared<RectCollider>(Vector2(25, 10), Vector2(CENTER_X-300, CENTER_Y-230));
	_rect16 = make_shared<RectCollider>(Vector2(25, 10), Vector2(CENTER_X-250, CENTER_Y-230));
	_rect17 = make_shared<RectCollider>(Vector2(25, 10), Vector2(CENTER_X-200, CENTER_Y-230));
	_rect18 = make_shared<RectCollider>(Vector2(25, 10), Vector2(CENTER_X-150, CENTER_Y-230));
	_rect19 = make_shared<RectCollider>(Vector2(25, 10), Vector2(CENTER_X-100, CENTER_Y-230));
	_rect20 = make_shared<RectCollider>(Vector2(25, 10), Vector2(CENTER_X- 50, CENTER_Y-230));
	_rect21 = make_shared<RectCollider>(Vector2(25, 10), Vector2(CENTER_X-500, CENTER_Y-210));
	_rect22 = make_shared<RectCollider>(Vector2(25, 10), Vector2(CENTER_X-450, CENTER_Y-210));
	_rect23 = make_shared<RectCollider>(Vector2(25, 10), Vector2(CENTER_X-400, CENTER_Y-210));
	_rect24 = make_shared<RectCollider>(Vector2(25, 10), Vector2(CENTER_X-350, CENTER_Y-210));
	_rect25 = make_shared<RectCollider>(Vector2(25, 10), Vector2(CENTER_X-300, CENTER_Y-210));
	_rect26 = make_shared<RectCollider>(Vector2(25, 10), Vector2(CENTER_X-250, CENTER_Y-210));
	_rect27 = make_shared<RectCollider>(Vector2(25, 10), Vector2(CENTER_X-200, CENTER_Y-210));
	_rect28 = make_shared<RectCollider>(Vector2(25, 10), Vector2(CENTER_X-150, CENTER_Y-210));
	_rect29 = make_shared<RectCollider>(Vector2(25, 10), Vector2(CENTER_X-100, CENTER_Y-210));
	_rect30 = make_shared<RectCollider>(Vector2(25, 10), Vector2(CENTER_X- 50, CENTER_Y-210));
	_rect31 = make_shared<RectCollider>(Vector2(25, 10), Vector2(CENTER_X + 500, CENTER_Y - 250));
	_rect32 = make_shared<RectCollider>(Vector2(25, 10), Vector2(CENTER_X + 450, CENTER_Y - 250));
	_rect33 = make_shared<RectCollider>(Vector2(25, 10), Vector2(CENTER_X + 400, CENTER_Y - 250));
	_rect34 = make_shared<RectCollider>(Vector2(25, 10), Vector2(CENTER_X + 350, CENTER_Y - 250));
	_rect35 = make_shared<RectCollider>(Vector2(25, 10), Vector2(CENTER_X + 300, CENTER_Y - 250));
	_rect36 = make_shared<RectCollider>(Vector2(25, 10), Vector2(CENTER_X + 250, CENTER_Y - 250));
	_rect37 = make_shared<RectCollider>(Vector2(25, 10), Vector2(CENTER_X + 200, CENTER_Y - 250));
	_rect38 = make_shared<RectCollider>(Vector2(25, 10), Vector2(CENTER_X + 150, CENTER_Y - 250));
	_rect39 = make_shared<RectCollider>(Vector2(25, 10), Vector2(CENTER_X + 100, CENTER_Y - 250));
	_rect40 = make_shared<RectCollider>(Vector2(25, 10), Vector2(CENTER_X + 50, CENTER_Y - 250));
	_rect41 = make_shared<RectCollider>(Vector2(25, 10), Vector2(CENTER_X + 500, CENTER_Y - 230));
	_rect42 = make_shared<RectCollider>(Vector2(25, 10), Vector2(CENTER_X + 450, CENTER_Y - 230));
	_rect43 = make_shared<RectCollider>(Vector2(25, 10), Vector2(CENTER_X + 400, CENTER_Y - 230));
	_rect44 = make_shared<RectCollider>(Vector2(25, 10), Vector2(CENTER_X + 350, CENTER_Y - 230));
	_rect45 = make_shared<RectCollider>(Vector2(25, 10), Vector2(CENTER_X + 300, CENTER_Y - 230));
	_rect46 = make_shared<RectCollider>(Vector2(25, 10), Vector2(CENTER_X + 250, CENTER_Y - 230));
	_rect47 = make_shared<RectCollider>(Vector2(25, 10), Vector2(CENTER_X + 200, CENTER_Y - 230));
	_rect48 = make_shared<RectCollider>(Vector2(25, 10), Vector2(CENTER_X + 150, CENTER_Y - 230));
	_rect49 = make_shared<RectCollider>(Vector2(25, 10), Vector2(CENTER_X + 100, CENTER_Y - 230));
	_rect50 = make_shared<RectCollider>(Vector2(25, 10), Vector2(CENTER_X + 50, CENTER_Y - 230));
	_rect51 = make_shared<RectCollider>(Vector2(25, 10), Vector2(CENTER_X + 500, CENTER_Y - 210));
	_rect52 = make_shared<RectCollider>(Vector2(25, 10), Vector2(CENTER_X + 450, CENTER_Y - 210));
	_rect53 = make_shared<RectCollider>(Vector2(25, 10), Vector2(CENTER_X + 400, CENTER_Y - 210));
	_rect54 = make_shared<RectCollider>(Vector2(25, 10), Vector2(CENTER_X + 350, CENTER_Y - 210));
	_rect55 = make_shared<RectCollider>(Vector2(25, 10), Vector2(CENTER_X + 300, CENTER_Y - 210));
	_rect56 = make_shared<RectCollider>(Vector2(25, 10), Vector2(CENTER_X + 250, CENTER_Y - 210));
	_rect57 = make_shared<RectCollider>(Vector2(25, 10), Vector2(CENTER_X + 200, CENTER_Y - 210));
	_rect58 = make_shared<RectCollider>(Vector2(25, 10), Vector2(CENTER_X + 150, CENTER_Y - 210));
	_rect59 = make_shared<RectCollider>(Vector2(25, 10), Vector2(CENTER_X + 100, CENTER_Y - 210));
	_rect60 = make_shared<RectCollider>(Vector2(25, 10), Vector2(CENTER_X + 50, CENTER_Y - 210));

}

Block::~Block()
{
}

void Block::Update()
{
	if (_isActive == false)
		return;
	_rect1 ->Update();
	_rect2 ->Update();
	_rect3 ->Update();
	_rect4 ->Update();
	_rect5 ->Update();
	_rect6 ->Update();
	_rect7 ->Update();
	_rect8 ->Update();
	_rect9 ->Update();
	_rect10->Update();
	_rect11->Update();
	_rect12->Update();
	_rect13->Update();
	_rect14->Update();
	_rect15->Update();
	_rect16->Update();
	_rect17->Update();
	_rect18->Update();
	_rect19->Update();
	_rect20->Update();
	_rect21->Update();
	_rect22->Update();
	_rect23->Update();
	_rect24->Update();
	_rect25->Update();
	_rect26->Update();
	_rect27->Update();
	_rect28->Update();
	_rect29->Update();
	_rect30->Update();
	_rect31->Update();
	_rect32->Update();
	_rect33->Update();
	_rect34->Update();
	_rect35->Update();
	_rect36->Update();
	_rect37->Update();
	_rect38->Update();
	_rect39->Update();
	_rect40->Update();
	_rect41->Update();
	_rect42->Update();
	_rect43->Update();
	_rect44->Update();
	_rect45->Update();
	_rect46->Update();
	_rect47->Update();
	_rect48->Update();
	_rect49->Update();
	_rect50->Update();
	_rect51->Update();
	_rect52->Update();
	_rect53->Update();
	_rect54->Update();
	_rect55->Update();
	_rect56->Update();
	_rect57->Update();
	_rect58->Update();
	_rect59->Update();
	_rect60->Update();
	
}

void Block::Render(HDC hdc)
{
	if (_isActive == false)
		return;
	_rect1->Render(hdc);
	_rect2->Render(hdc);
	_rect3->Render(hdc);
	_rect4->Render(hdc);
	_rect5->Render(hdc);
	_rect6->Render(hdc);
	_rect7->Render(hdc);
	_rect8->Render(hdc);
	_rect9->Render(hdc);
	_rect10->Render(hdc);
	_rect11->Render(hdc);
	_rect12->Render(hdc);
	_rect13->Render(hdc);
	_rect14->Render(hdc);
	_rect15->Render(hdc);
	_rect16->Render(hdc);
	_rect17->Render(hdc);
	_rect18->Render(hdc);
	_rect19->Render(hdc);
	_rect20->Render(hdc);
	_rect21->Render(hdc);
	_rect22->Render(hdc);
	_rect23->Render(hdc);
	_rect24->Render(hdc);
	_rect25->Render(hdc);
	_rect26->Render(hdc);
	_rect27->Render(hdc);
	_rect28->Render(hdc);
	_rect29->Render(hdc);
	_rect30->Render(hdc);
	_rect31->Render(hdc);
	_rect32->Render(hdc);
	_rect33->Render(hdc);
	_rect34->Render(hdc);
	_rect35->Render(hdc);
	_rect36->Render(hdc);
	_rect37->Render(hdc);
	_rect38->Render(hdc);
	_rect39->Render(hdc);
	_rect40->Render(hdc);
	_rect41->Render(hdc);
	_rect42->Render(hdc);
	_rect43->Render(hdc);
	_rect44->Render(hdc);
	_rect45->Render(hdc);
	_rect46->Render(hdc);
	_rect47->Render(hdc);
	_rect48->Render(hdc);
	_rect49->Render(hdc);
	_rect50->Render(hdc);
	_rect51->Render(hdc);
	_rect52->Render(hdc);
	_rect53->Render(hdc);
	_rect54->Render(hdc);
	_rect55->Render(hdc);
	_rect56->Render(hdc);
	_rect57->Render(hdc);
	_rect58->Render(hdc);
	_rect59->Render(hdc);
	_rect60->Render(hdc);
	
}
bool Block::BallHit(shared_ptr<Stick> stick)
{
	if (_isActive == false || stick->_isActive == false)
			return false;
		if (_ball->IsCollision(stick))
		{
			_ball->_isActive = false;
			return true;
		}

		return false;
	
	return false;
}
