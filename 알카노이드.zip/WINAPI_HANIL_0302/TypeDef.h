#pragma once
#define CENTER_X 640
#define CENTER_Y 360
#define PI 3.141592
#define GRAVITY 0.98
#define STARTX 0
#define STARTY 0


#define WIN_WIDTH 1280
#define WIN_HEIGTH 720

#define GREEN RGB(0, 255, 0)
#define RED RGB(255, 0, 0)
#define BLUE RGB(0, 0, 255)
#define YELLOW RGB(255, 255, 0)

