#pragma once
class Line
{
public:
	Line();
	~Line();

	void Update();
	void Render(HDC hdc);

	bool IsCollision(shared_ptr<Line> line);

public:
	Vector2 _startPos = { 0,0 };
	Vector2 _endPos = { 0,0 };
};

