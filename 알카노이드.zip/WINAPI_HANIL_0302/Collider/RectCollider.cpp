#include "Framework.h"
#include "RectCollider.h"

RectCollider::RectCollider()
{
	_type = ColType::RECT;
}

RectCollider::RectCollider(const Vector2& halfSize, const Vector2& center)
: _halfSize(halfSize)
{
	_center = center;
	_type = ColType::RECT;
}

RectCollider::~RectCollider()
{
}

void RectCollider::Update()
{
}

void RectCollider::Render(HDC hdc)
{
	// ���� ����
	Collider::Render(hdc);

	int left = Left();
	int right = Right();
	int top = Top();
	int bottom = Bottom();
	Rectangle(hdc, left, top, right, bottom);
}

bool RectCollider::IsCollision(const Vector2& pos) const
{
	if (pos._x < Left() || pos._x > Right())
		return false;
	if (pos._y < Top() || pos._y > Bottom())
		return false;

	return true;
}

bool RectCollider::IsCollision(const CircleCollider& col) const
{
	// �簢���� ���浹
	if (IsCollision(col.GetCenter()))
		return true;

	if ((col.GetCenter()._x > Left() && col.GetCenter()._x < Right())
		|| (col.GetCenter()._y > Top() && col.GetCenter()._y < Bottom()))
	{
		// ������ �簢��
		// ���� ��������ŭ Ȯ��
		if (col.GetCenter()._x < Left() - col.GetRadius() || col.GetCenter()._x > Right() + col.GetRadius())
			return false;
		if (col.GetCenter()._y < Top() - col.GetRadius() || col.GetCenter()._y > Bottom() + col.GetRadius())
			return false;

		return true;
	}

	if (col.IsCollision(Vector2(Right(), Top())))
		return true;
	if (col.IsCollision(Vector2(Left(), Top())))
		return true;
	if (col.IsCollision(Vector2(Right(), Bottom())))
		return true;
	if (col.IsCollision(Vector2(Left(), Bottom())))
		return true;

	return false;
}

bool RectCollider::IsCollision(const RectCollider& col) const
{
	Vector2 leftTop		 = { static_cast<float>(col.Left()), static_cast<float>(col.Top()) };
	Vector2 rightTop	 = { static_cast<float>(col.Right()), static_cast<float>(col.Top()) };
	Vector2 leftBottom	 = { static_cast<float>(col.Left()), static_cast<float>(col.Bottom()) };
	Vector2 rightBottom	 = { static_cast<float>(col.Right()), static_cast<float>(col.Bottom()) };

	if (IsCollision(leftTop) || IsCollision(rightTop)
		|| IsCollision(leftBottom) || IsCollision(rightBottom))
	{
		return true;
	}

	return false;
}
