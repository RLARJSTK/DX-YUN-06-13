#pragma once
class Zelda
{
public:
	enum State
	{
		F_IDLE,
		L_IDLE,
		B_IDLE,
		R_IDLE,

		F_RUN,
		L_RUN,
		B_RUN,
		R_RUN
	};

	Zelda();
	~Zelda();
	void CreateActions();
	void Update();
	void Render();
	void PostRender();
	void SetPosition(float x, float y);
	void SetAnimation(State aniState);
	void PrintMessage() { _massage = "�������̵�"; }

	shared_ptr<Transform> GetTransform() { return _transform; }

private:
	State _aniState = F_IDLE;
	shared_ptr<Collider> _coll;
	shared_ptr<Sprite> _zelda;
	vector<shared_ptr<Action>> _act;
	string _massage = "";

	shared_ptr<Transform> _transform;
	shared_ptr<FrameBuffer> _frameBuffer;


};