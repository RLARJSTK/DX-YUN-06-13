#include "framework.h"
#include "ZeldaScene.h"

ZeldaScene::ZeldaScene()
{
	_zelda = make_shared<Zelda>();

	//_zelda->SetAnimation();
	//_zelda->SetClip();

}

ZeldaScene::~ZeldaScene()
{
}

void ZeldaScene::Update()
{
	_zelda->Update();
	if (KEY_PRESS('W'))
	{
		_zeldaPos.y -= 100.0f * DELTA_TIME;
		_zelda->SetAnimation(Zelda::State::B_RUN);
		return;
	}
	if (KEY_PRESS('S'))
	{
		_zeldaPos.x += 100.0f * DELTA_TIME;
		_zelda->SetAnimation(Zelda::State::B_RUN);
		return;
	}
	if (KEY_PRESS('A'))
	{
		_zeldaPos.y += 100.0f * DELTA_TIME;
		_zelda->SetAnimation(Zelda::State::B_RUN);
		return;
	}
	if (KEY_PRESS('D'))
	{
		_zeldaPos. x-= 100.0f * DELTA_TIME;
		_zelda->SetAnimation(Zelda::State::B_RUN);
		return;
	}
	_zelda->SetPosition(_zeldaPos.x,_zeldaPos.y);
}

void ZeldaScene::Render()
{
	_zelda->Render();
}

void ZeldaScene::PostRender()
{
	_zelda->PostRender();

}
