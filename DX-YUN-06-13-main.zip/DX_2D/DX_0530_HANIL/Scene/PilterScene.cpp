#include "framework.h"
#include "PilterScene.h"

PilterScene::PilterScene()
{
	_quad = make_shared<Quad>();
	_quad->GetTransform()->GetPos() = {  }
	_quad->GetTransform()->GetScale() *= 0.5f;
	_filterBuffer = make_shared<PixelShader>();
	_filterBuffer->;
}

PilterScene::~PilterScene()
{
}

void PilterScene::Update()
{
	_quad->Update();
}

void PilterScene::Render()
{
	_quad->Render();
}

void PilterScene::PostRender()
{
}
