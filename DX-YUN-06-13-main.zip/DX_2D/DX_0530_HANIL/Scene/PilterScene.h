#pragma once
class PilterScene :public Scene
{
public:
	PilterScene();
	virtual ~PilterScene();

	virtual void Update() override;
	virtual void Render() override;
	virtual void PostRender()override;

private:
	shared_ptr <Quad> _quad;
	shared_ptr<PixelShader> _filterBuffer;
};

