#include "framework.h"
#include "TextureWVPScene.h"

TextureWVPScene::TextureWVPScene()
{
	_texture = make_shared<Quad>(L"Resource/Bazel.png");

	_worldBuffer = make_shared<MatrixBuffer>();
}

TextureWVPScene::~TextureWVPScene()
{
}

void TextureWVPScene::Update()
{
	//_cameraPos = { -300.0f,0 };
	//_angle += 0.001f;
	// S �� {1,1}
	//XMMATRIX cameraMatrix = XMMatrixRotationZ(_angle);
	//cameraMatrix = XMMatrixTranslation(_cameraPos.x, _cameraPos.y, 0);
	//_viewBuffer->SetMatrix(cameraMatrix);

	_texture->GetTransform()->GetPos()._x -= 0.1f;

	_worldBuffer->Update();

	_texture->Update();
}

void TextureWVPScene::Render()
{
	_worldBuffer->SetVSBuffer(0);

	_texture->Render();
}
