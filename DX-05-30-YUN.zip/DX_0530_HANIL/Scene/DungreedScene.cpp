#include "framework.h"
#include "DungreedScene.h"

DungreedScene::DungreedScene()
{
	_player = make_shared<Player>();
	_enemy1 = make_shared<Enemy>();
	_enemy1->GetTransfom()->GetPos() = Vector2(WIN_WIDTH * 0.3f, WIN_HEIGHT * 0.7f);
	_enemy2 = make_shared<Enemy>();												
	_enemy2->GetTransfom()->GetPos() = Vector2(WIN_WIDTH * 0.4f, WIN_HEIGHT * 0.7f);
	_enemy3 = make_shared<Enemy>();												
	_enemy3->GetTransfom()->GetPos() = Vector2(WIN_WIDTH * 0.5f, WIN_HEIGHT * 0.7f);
	_enemy4 = make_shared<Enemy>();							 					
	_enemy4->GetTransfom()->GetPos() = Vector2(WIN_WIDTH * 0.6f, WIN_HEIGHT * 0.7f);
	_enemy5 = make_shared<Enemy>();							 					
	_enemy5->GetTransfom()->GetPos() = Vector2(WIN_WIDTH * 0.7f, WIN_HEIGHT * 0.7f);
	_aim = make_shared<Quad>(L"Resource/aim.png");
	_sprite = make_shared<Quad>(L"Resource/zlda.png",Vector2(10,8));
	_sprite->GetTransform()->GetPos() = Vector2(WIN_WIDTH * 0.9f, WIN_HEIGHT * 0.7f);
}

DungreedScene::~DungreedScene()
{
}

void DungreedScene::Update()
{
	
	//if (_enemy->IsCollision(_bullet, true))
	//	_enemy->SetRed();
	//else
	//	_enemy->SetGreen();
	_player->Update();
	_enemy1->Update();
	_enemy2->Update();
	_enemy3->Update();
	_enemy4->Update();
	_enemy5->Update();
	_aim->Update();
	_sprite->Update();

	//_rectCollider->Update();

	_aim->GetTransform()->GetPos() = MOUSE_POS;

}

void DungreedScene::Render()
{
	_player->Render();
	_enemy1->Render();
	_enemy2->Render();
	_enemy3->Render();
	_enemy4->Render();
	_enemy5->Render();
	
	_aim->Render();
	_sprite->Render();


	//_rectCollider->Render();

	// Imgui
	//ImGui::SliderFloat("ColliderPosX", &_rectCollider->GetLocalPosition()._x, 0, 1280);
	//ImGui::SliderFloat("ColliderPosY", &_rectCollider->GetLocalPosition()._y, 0, 720);
}
