#include "framework.h"
#include "DungreedScene.h"

DungreedScene::DungreedScene()
{
	_player = make_shared<Player>();
	_enemy = make_shared<Enemy>();
	_aim = make_shared<Texture>(L"Resource/aim.png");

}

DungreedScene::~DungreedScene()
{
}

void DungreedScene::Update()
{
	
	//if (_enemy->IsCollision(_bullet, true))
	//	_enemy->SetRed();
	//else
	//	_enemy->SetGreen();
	_player->Update();
	_enemy->Update();
	_aim->Update();

	//_rectCollider->Update();

	_aim->GetTransform()->GetPos() = MOUSE_POS;

}

void DungreedScene::Render()
{
	_player->Render();
	_enemy->Render();
	_aim->Render();

	//_rectCollider->Render();

	// Imgui
	//ImGui::SliderFloat("ColliderPosX", &_rectCollider->GetLocalPosition()._x, 0, 1280);
	//ImGui::SliderFloat("ColliderPosY", &_rectCollider->GetLocalPosition()._y, 0, 720);
}
