#include "framework.h"
#include "SolarSystemScene.h"

SolarSystemScene::SolarSystemScene()
{
	_sun = make_shared<Quad>(L"Resource/sun.png");
	_earth = make_shared<Quad>(L"Resource/earth.png");
	_moon = make_shared<Quad>(L"Resource/moon.png");

	_earth->GetTransform()->SetParent(_sun->GetTransform());
	_earth->GetTransform()->GetPos()._x = 300;
	_earth->GetTransform()->GetScale()._x *= 0.5f;
	_earth->GetTransform()->GetScale()._y *= 0.5f;

	_moon->GetTransform()->SetParent(_earth->GetTransform());
	_moon->GetTransform()->GetPos()._x = 300;
	_moon->GetTransform()->GetScale()._x *= 0.5f;
	_moon->GetTransform()->GetScale()._y *= 0.5f;

}

SolarSystemScene::~SolarSystemScene()
{
}

void SolarSystemScene::Update()
{
	// 1�� 100�� Update ... angle : 0.1 -> DT : 1/100 => 0.1 * DT
	// 1�� 300�� Update ... angle : 0.3 -> DT : 1/300 => 0.3 * DT
	_sun->GetTransform()->GetPos()._x = MOUSE_POS._x;
	_sun->GetTransform()->GetPos()._y = MOUSE_POS._y;

	if (KEY_PRESS(VK_SPACE))
	{
		_sun->GetTransform()->GetAngle() += 1 * DELTA_TIME; // DELTA_TIME : 1 Tick�� �ɸ��� �ð�
		_earth->GetTransform()->GetAngle() += 1 * DELTA_TIME;
		_moon->GetTransform()->GetAngle() += 1 * DELTA_TIME;
	}

	if (KEY_DOWN(VK_LBUTTON))
	{

	}

	int temp = Timer::GetInstance()->GetFPS();

	_sun->Update();
	_earth->Update();
	_moon->Update();
}

void SolarSystemScene::Render()
{
	ALPHA_STATE->SetState();

	_sun->Render();
	_earth->Render();
	_moon->Render();
}
