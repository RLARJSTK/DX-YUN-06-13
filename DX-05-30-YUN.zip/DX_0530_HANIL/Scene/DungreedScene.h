#pragma once
class DungreedScene : public Scene
{
public:
	DungreedScene();
	virtual ~DungreedScene();

	virtual void Update() override;
	virtual void Render() override;

private:
	shared_ptr<Player> _player;
	shared_ptr<Bullet> _bullet;
	shared_ptr<Quad> _aim;
	shared_ptr<Enemy> _enemy1;
	shared_ptr<Enemy> _enemy2;
	shared_ptr<Enemy> _enemy3;
	shared_ptr<Enemy> _enemy4;
	shared_ptr<Enemy> _enemy5;
	shared_ptr<Transform> _transform;
	shared_ptr<Sprite> _sprite;

	float _guiTest = 0.0f;
};

