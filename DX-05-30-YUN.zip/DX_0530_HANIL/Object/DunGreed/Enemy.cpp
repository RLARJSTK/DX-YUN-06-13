#include "framework.h"
#include "Enemy.h"
Enemy::Enemy()
{
	_enemy = make_shared<Texture>(L"Resource/monster.png");
	_enemy->GetTransform()->GetScale() = { 0.5f,0.5f };  //�����̵�           �����̵�
	//_enemy->GetTransform()->GetPos() = Vector2(WIN_WIDTH * 0.5f, WIN_HEIGHT * 0.5f);

	_collider = make_shared<RectCollider>(Vector2{ 100, 100 });
	_collider->SetParent(_enemy->GetTransform());


}

Enemy::~Enemy()
{
}

void Enemy::Update()
{
	_enemy->Update();
	_collider->Update();
}

void Enemy::Render()
{
	_enemy->Render();
	_collider->Render();
}
//bool Enemy::AABB(shared_ptr<CircleCollider> circle)
//{
//	 �簢���� ���浹
//	if (IsCollision(circle->GetWorldPosition()))
//		return true;
//	
//	if ((circle->GetWorldPosition()._x > Left() && circle->GetWorldPosition()._x < Right())
//		|| (circle->GetWorldPosition()._y < Top() && circle->GetWorldPosition()._y > Bottom()))
//	{
//		// ������ �簢��
//		// ���� ��������ŭ Ȯ��
//		if (circle->GetWorldPosition()._x < Left() - circle->GetRadius() || circle->GetWorldPosition()._x > Right() + circle->GetRadius())
//			return false;
//		if (circle->GetWorldPosition()._y < Top() - circle->GetRadius() || circle->GetWorldPosition()._y > Bottom() + circle->GetRadius())
//			return false;
//	
//		return true;
//	}
//	
//	if (circle->IsCollision(Vector2(Right(), Top())))
//		return true;
//	if (circle->IsCollision(Vector2(Left(), Top())))
//		return true;
//	if (circle->IsCollision(Vector2(Right(), Bottom())))
//		return true;
//	if (circle->IsCollision(Vector2(Left(), Bottom())))
//		return true;
//	
//	return false;
//}