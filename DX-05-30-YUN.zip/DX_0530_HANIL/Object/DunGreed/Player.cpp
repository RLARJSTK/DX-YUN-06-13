#include "framework.h"
#include "Player.h"

Player::Player()
{
	_player = make_shared<Quad>(L"Resource/player.png");
	_player->GetTransform()->GetScale() = { 0.5f,0.5f };   //�÷��̾���ġ ����
	_player->GetTransform()->GetPos() = Vector2(WIN_WIDTH * 0.05f, WIN_HEIGHT * 0.1f);
	_gunTrans = make_shared<Transform>();
	_gunTrans->SetParent(_player->GetTransform());
	_gunTrans->GetPos()._x = 150;

	_gun = make_shared<Gun>();
	_gun->SetPlayer(_gunTrans);

	_bullets.reserve(30);
	for (int i = 0; i < _poolCount; i++)
	{
		shared_ptr<Bullet> bullet = make_shared<Bullet>();
		bullet->isActive = false;
		_bullets.push_back(bullet);
	}
	_collider = make_shared<RectCollider>(Vector2 {100, 100});
	_collider->SetParent(_player->GetTransform());
}

Player::~Player()
{
}

void Player::Update()
{
	Move();
	Aiming();
	Fire();

	_player->Update();

	_gunTrans->UpdateWorldBuffer();

	_gun->Update();

	for (auto& bullet : _bullets)
	{
		bullet->Update();
	}
	_collider->Update();
}

void Player::Render()
{
	_player->Render();


	_gun->Render();

	for (auto& bullet : _bullets)
	{
		bullet->Render();
	}
	_collider->Render();
}

void Player::AttackMonster(shared_ptr<class Enemy> ememy)
{

}


void Player::Move()
{
	if (KEY_PRESS('W'))
	{
		_player->GetTransform()->GetPos()._y += 100.0f * DELTA_TIME;
	}
	if (KEY_PRESS('S'))
	{
		_player->GetTransform()->GetPos()._y -= 100.0f * DELTA_TIME;
	}
	if (KEY_PRESS('A'))
	{
		_player->GetTransform()->GetPos()._x -= 100.0f * DELTA_TIME;
	}
	if (KEY_PRESS('D'))
	{
		_player->GetTransform()->GetPos()._x += 100.0f * DELTA_TIME;
	}
}

void Player::Aiming()
{
	Vector2 v = MOUSE_POS - _gunTrans->GetWorldPos();
	float angle = v.Angle();

	_gunTrans->GetAngle() = angle;
}

void Player::Fire()
{
	if (KEY_DOWN(VK_LBUTTON))
	{
		Vector2 v = MOUSE_POS - _gunTrans->GetWorldPos();
		v.Normallize();

		for (auto& bullet : _bullets)
		{
			if (bullet->isActive == false)
			{
				bullet->SetDirection(v);
				bullet->SetPosition(_gunTrans->GetWorldPos());
				bullet->isActive = true;
				break;
			}
		}
	}
}
