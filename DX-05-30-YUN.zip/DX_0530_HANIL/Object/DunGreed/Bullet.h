#pragma once
class Bullet
{
public:
	Bullet();
	~Bullet();

	void Update();
	void Render();

	shared_ptr<Transform> GetTransfom() { return _bullet->GetTransform(); }
	void SetDirection(Vector2 dir);
	void SetPosition(Vector2 pos) { _bullet->GetTransform()->GetPos() = pos; }
	//void IsCollision(shared_ptr<RectCollider> rect);
	bool isActive = false;

private:
	shared_ptr<Texture> _bullet;
	shared_ptr<Collider> _rock;
	Vector2 _direction;

	float _runTime = 0.0f;
	float _destroyTime = 3.0f;
};

