#pragma once
class Enemy
{
public:
	Enemy();
	~Enemy();
	void Update();
	void Render();
	//bool AABB(shared_ptr<class CircleCollider> other);
	shared_ptr<Transform>GetTransfom() { return _enemy->GetTransform(); };
private:
	shared_ptr<Quad> _enemy;
	shared_ptr<Collider> _collider;

	shared_ptr<Transform> _transform;
};

