#pragma once
class Enemy
{
public:
	Enemy();
	~Enemy();
	void Update();
	void Render();
	//bool AABB(shared_ptr<class CircleCollider> other);
private:
	shared_ptr<Texture> _enemy;
	shared_ptr<Collider> _collider;
};

