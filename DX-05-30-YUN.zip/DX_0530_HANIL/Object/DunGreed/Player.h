#pragma once
class Player
{
public:
	Player();
	~Player();

	void Update();
	void Render();
	void AttackMonster(shared_ptr<class Enemy> ememy);
	//bool IsCollision(shared_ptr<RectCollider> rect, bool obb = false);
private:

	void Move();
	void Aiming();
	void Fire();

	shared_ptr<Texture> _player;
	shared_ptr<Collider> _collider;
	//shared_ptr<Enemy> _mob;

	shared_ptr<class Gun> _gun;
	shared_ptr<Transform> _gunTrans;

	vector<shared_ptr<class Bullet>> _bullets;
	UINT _poolCount = 30;
};

