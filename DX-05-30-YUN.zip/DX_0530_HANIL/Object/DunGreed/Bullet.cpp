#include "framework.h"
#include "Bullet.h"

Bullet::Bullet()
{
	_bullet = make_shared<Quad>(L"Resource/bullet.png");
	_rock = make_shared<CircleCollider>(20);
	_rock ->SetParent(_bullet->GetTransform());
	_rock ->GetLocalPosition()._x+=30;
}

Bullet::~Bullet()
{
}

void Bullet::Update()
{
	if (isActive == false)
		return;

	_bullet->GetTransform()->GetPos() += _direction * 300.0f * DELTA_TIME;

	_bullet->Update();
	_rock->Update();

	_runTime += DELTA_TIME;

	if (_runTime > _destroyTime)
	{
		isActive = false;
		_runTime = 0.0f;
	}
}

void Bullet::Render()
{
	if (isActive == false)
		return;

	_bullet->Render();
	_rock->Render();
}

void Bullet::SetDirection(Vector2 dir)
{
	_direction = dir;
	_bullet->GetTransform()->GetAngle() = dir.Angle();
}


