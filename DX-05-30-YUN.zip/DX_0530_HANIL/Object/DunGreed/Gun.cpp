#include "framework.h"
#include "Gun.h"

Gun::Gun()
{
	_gun = make_shared<Texture>(L"Resource/gun.png");
}

Gun::~Gun()
{
}

void Gun::Update()
{
	_gun->Update();
}

void Gun::Render()
{
	_gun->Render();
}
