#pragma once
#pragma once
class Quad
{
public:
    Quad(wstring file);
    ~Quad();
    void Update();
    void Render();
    void CreateVertices();
    shared_ptr<Transform> GetTransform() { return _transform; }
    void SetParent(shared_ptr<Transform> parent) { _transform->SetParent(parent); }
    const Vector2& VectorSize() { return _halfSize; }


private:
    Vector2 _halfSize = { 1,1 };
    shared_ptr<Texture> _texture;

    shared_ptr<Transform> _transform;
    //Mash
    vector<VertexUV> _vertices;
    vector<UINT> _indicies;
    shared_ptr<VertexBuffer>    _vertexBuffer;
    shared_ptr<IndexBuffer>     _indexBuffer;
    //Marerial
    shared_ptr<VertexShader>    _vertexShader;
    shared_ptr<PixelShader>     _pixelShader;
};