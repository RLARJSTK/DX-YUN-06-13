#pragma once
class Texture
{
public:
	Texture(wstring file);
	~Texture();

	void Update();
	void Render();

    //�ı��
    void Set(UINT slot);
    Vector2& GetSize();
    void Delete();
    shared_ptr<Texture>Add(wstring file);
    //�����

    shared_ptr<Transform> GetTransform() { return _transform; }

private:
    void CreateVertices();

    shared_ptr<Transform> _transform;

    vector<VertexUV> _vertices;
    vector<UINT> _indicies;

    //Mash
    shared_ptr<VertexBuffer>    _vertexBuffer;
    shared_ptr<IndexBuffer>     _indexBuffer;

    //Marerial
    shared_ptr<VertexShader>    _vertexShader;
    shared_ptr<PixelShader>     _pixelShader;


    //Texture ���߿� �ı����
    wstring _file;
    ScratchImage _image;
    shared_ptr<SRV>             _srv;//�̵�������  Texture �̰ɺ��ΰ͵� �����ɷ� �߰�
    static unordered_map<wstring, shared_ptr<Texture>>_textureMc;
};

