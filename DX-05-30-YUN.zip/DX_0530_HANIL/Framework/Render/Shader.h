class Shader
{
public:
	Shader();
	virtual ~Shader();
	virtual void Set() abstract;

private:
	Microsoft::WRL::ComPtr<ID3DBlob> _blob;
};


