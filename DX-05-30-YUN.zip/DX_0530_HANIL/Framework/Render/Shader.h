class Shader
{
public:
	Shader();
	virtual ~Shader();
	virtual void Set() abstract;

private:
	wstring file;
	Microsoft::WRL::ComPtr<ID3DBlob> _blob;
};


