class Shader
{
public:
	Shader();
	virtual ~Shader();
	virtual void Set() abstract;

private:
	wstring _file;
	Microsoft::WRL::ComPtr<ID3DBlob> _blob;
};


