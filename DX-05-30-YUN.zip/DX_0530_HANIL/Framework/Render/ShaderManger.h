#pragma once
class ShaderManger
{

private:
	ShaderManger();
	~ShaderManger();

public:
	static void Create()
	{
		if (_instance == nullptr)
		{
			_instance = new ShaderManger();
		}
	}

	static void Delete()
	{
		if (_instance != nullptr)
		
			delete _instance;
		
	}

	static ShaderManger* GetInstance()
	{
		if (_instance != nullptr)
			return _instance;
	}
	shared_ptr<VertexShader>AddVS(wstring file);
	shared_ptr<PixelShader>AddPS(wstring file);
private:
	static ShaderManger* _instance;
	unordered_map<string, shared_ptr<Shader>> _shadersMap;
};

