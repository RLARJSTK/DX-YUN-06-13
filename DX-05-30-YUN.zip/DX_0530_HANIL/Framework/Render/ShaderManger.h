#pragma once
class ShaderManger
{

private:
	ShaderManger();
	~ShaderManger();

public:
	static void Create()
	{
		if (_instance == nullptr)
		{
			_instance = new ShaderManger();
		}
	}

	static void Delete()
	{
		if (_instance != nullptr)
		{
			delete _instance;
		}
	}

	static ShaderManger* GetInstance()
	{
		if (_instance != nullptr)
			return _instance;

		
	}

private:
	static ShaderManger* _instance;
	//map<string,shared_ptr<ShaderManger>
};

