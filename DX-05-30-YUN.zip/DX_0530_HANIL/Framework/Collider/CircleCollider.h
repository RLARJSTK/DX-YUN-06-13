#pragma once
class CircleCollider :public Collider
{
public:
	CircleCollider(float radius);
	virtual~CircleCollider();
	virtual void CreateData()override;
	virtual void Update()override;
	virtual void Render()override;
	virtual bool IsCollision(const Vector2& pos)override;
	virtual bool IsCollision(shared_ptr<RectCollider> rect, bool obb = false)override;
	virtual bool IsCollision(shared_ptr<class CircleCollider> other, bool obb = false)override;

	float GetRadius() { return _radius * _transform->GetWorldScale()._x; }

private:

	float _radius;
	
};

