#pragma once
class RectCollider :public Collider
{
private:
	struct ObbDesc
	{
		Vector2 _position;
		Vector2 _direction[2];
		float _length[2];
	};

public:
	RectCollider(const Vector2& halfSize = { 1.0f,1.0f });
	virtual~RectCollider();
	virtual void Update()override;
	virtual void Render()override;
	virtual void CreateData()override;
	
	float Left() 
	{
		Vector2 temp = GetWorldPosition();
		return temp._x - _halfSize._x; 
	}
	float Right()
	{ 
		Vector2 temp = GetWorldPosition();
		return temp._x + _halfSize._x;
	}
	float Top()
	{
		Vector2 temp = GetWorldPosition();
		return temp._y + _halfSize._y;
	}
	float Bottom() 
	{ 
		Vector2 temp = GetWorldPosition();
		return temp._y - _halfSize._y;
	}


	ObbDesc GetObb();

	bool AABB(shared_ptr<RectCollider> rect);
	bool OBB(shared_ptr<RectCollider> rect);

	bool AABB(shared_ptr<class CircleCollider> other);
	bool OBB(shared_ptr<class CircleCollider> other);

	virtual bool IsCollision(const Vector2& pos)override;
	virtual bool IsCollision(shared_ptr<RectCollider> rect, bool obb = false)override;
	virtual bool IsCollision(shared_ptr<class CircleCollider> other, bool obb = false)override;

	float SepareateAxis(Vector2 separate, Vector2 e1, Vector2 e2);

	const float& GetWorldPositionX() { return _halfSize._x* GetWorldScale()._x; }
	const float& GetWorldPositionY() { return _halfSize._y* GetWorldScale()._y; }
private:
	Vector2 _halfSize = { 0,0 };

	shared_ptr<Collider> _collider;

};

