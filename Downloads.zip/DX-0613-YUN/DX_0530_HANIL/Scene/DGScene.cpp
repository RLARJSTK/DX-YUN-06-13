#include "framework.h"
#include "DGScene.h"

DGScene::DGScene()
{
	_arin = make_shared<Arin>();
}

DGScene::~DGScene()
{
}

void DGScene::Update()
{
	_arin->Update();
}

void DGScene::Render()
{
	_arin->Render();
}
