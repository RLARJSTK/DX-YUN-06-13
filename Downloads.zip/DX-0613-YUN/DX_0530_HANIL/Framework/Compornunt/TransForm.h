#pragma once
class TransForm
{
public:
	TransForm();
	~TransForm();
    void UpdateWorldBuffer();
    void SetWorldBuffer(int slot=0);
    Vector2& GetPos() { return _pos; }
    Vector2& GetScale() { return _scale; }
    float& GetAnagle() { return _angle; }
    Vector2 GetWorldPos()
    {
        Vector2 worldPos;
        XMFLOAT4X4 matrix;
        XMStoreFloat4x4(&matrix, _srt_Matrix);
        worldPos.x = matrix._41;
        worldPos.y = matrix._42;
        return worldPos;
    }
    XMMATRIX* GetMatrix() { return &_srt_Matrix; }
    void SetParent(XMMATRIX* matrix) { _parentMatrix = matrix; }
private:


    Vector2 _scale = { 1,1 };
    float _angle = { 0.0f };
    Vector2 _pos = { 0,0 };
    XMMATRIX _srt_Matrix;
    XMMATRIX* _parentMatrix = nullptr;
    shared_ptr<MatrixBuffer> _worldBuffer;
};
