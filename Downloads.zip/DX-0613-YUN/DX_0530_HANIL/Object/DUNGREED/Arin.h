#pragma once
class Arin
{
public:
	Arin();
	~Arin();
	void Update();
	void Render();
	void AIming();
private:
	void Move();
	shared_ptr<Texture> _arin;
	shared_ptr<class Werpon> _bow;
	shared_ptr<TransForm> _werpon;
};