class Werpon
{
public:
	Werpon();
	~Werpon();
	void Update();
	void Render();
	void SetArin(TransForm* transform)
	{ 
		_bow->GetTransform()->SetParent(transform->GetMatrix());
	}
private:
	shared_ptr<Texture> _bow;
};