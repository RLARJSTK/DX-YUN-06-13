#include "framework.h"
#include "Bullet.h"

Bullet::Bullet()
{
	_bullet = make_shared<Texture>(L"Resource/BULLET.png");
}

Bullet::~Bullet()
{
}

void Bullet::Update()
{
	_bullet->Update();
	
}

void Bullet::Render()
{
	_bullet->Render();
}
