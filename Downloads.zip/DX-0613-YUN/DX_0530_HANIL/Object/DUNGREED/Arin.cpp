#include "framework.h"
#include "Arin.h"

Arin::Arin()
{
	_arin = make_shared<Texture>(L"Resource/ARIN.png");
	_werpon = make_shared < TransForm > ();
	_werpon->SetParent(_arin->GetTransform()->GetMatrix());
	_werpon->GetPos().x = 50;

	_bow = make_shared<Werpon>();
	_bow->SetArin(_werpon);
}

Arin::~Arin()
{
}

void Arin::Update()
{
	Move();
	AIming();
	_werpon->UpdateWorldBuffer();
	_arin->Update();
	_bow->Update();
}

void Arin::Render()
{
	_arin->Render();
	_bow->Render();

}



void Arin::Move()
{
	if (KEY_PRESS('W'))
	{
		_arin->GetTransform()->GetPos().y -= 5.0f*DELTA_TIME;
	}
	if (KEY_PRESS('A'))
	{
		_arin->GetTransform()->GetPos().x -= 5.0f*DELTA_TIME;
	}
	if (KEY_PRESS('S'))
	{
		_arin->GetTransform()->GetPos().y += 5.0f* DELTA_TIME;
	}
	if (KEY_PRESS('D'))
	{
		_arin->GetTransform()->GetPos().x += 5.0f* DELTA_TIME;
	}
}
void Arin::AIming()
{
	Vector2 v = MOUSE_POS - _werpon->GetWorldPos();
	float angle = v.Angle();
	//_werpon->GetAngle();
}