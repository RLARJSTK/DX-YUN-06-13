#include "framework.h"
#include "Werpon.h"

Werpon::Werpon()
{
	_bow = make_shared<Texture>(L"Resource/BOW.png");
}

Werpon::~Werpon()
{
}

void Werpon::Update()
{
	_bow->Update();
	
}

void Werpon::Render()
{
	_bow->Render();
}
