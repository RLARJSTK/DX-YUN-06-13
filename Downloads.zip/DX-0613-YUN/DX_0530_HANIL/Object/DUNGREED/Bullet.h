class Bullet
{
public:
	Bullet();
	~Bullet();
	void Update();
	void Render();
	void SetDirection();
	bool _isActive = true;
	shared_ptr<TransForm> GetTransform() { return _transForm; }
private:
	shared_ptr<Texture> _bullet;
	shared_ptr<TransForm> _transForm;
	Vector2 _direction;
};