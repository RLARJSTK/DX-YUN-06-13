#include "framework.h"
#include "DGScene.h"

DGScene::DGScene()
{
	_arin = make_shared<Arin>();
	_bow = make_shared<Werpon>();
	_bullet = make_shared<Bullet>();

}

DGScene::~DGScene()
{
	
}

void DGScene::Update()
{
	

	_arin->Update();
	_bow->Update();
	_bullet->Update();
	
}

void DGScene::Render()
{
	


	_arin->Render();
	_bow->Render();
	_bullet->Render();

}
