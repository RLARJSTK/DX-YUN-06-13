#include "framework.h"
#include "Werpon.h"

Werpon::Werpon()
{
	_bow = make_shared<Texture>(L"Resource/BOW.png");
	_bow->GetTransform()->SetParent(_arin->GetTransform()->GetMatrix());
	_bow->GetTransform()->GetPos().x = 195;
    _transForm = make_shared<TransForm>();
  
}

Werpon::~Werpon()
{
}

void Werpon::Update()
{ 
	if (GetAsyncKeyState(VK_F1))
	{
		_bow->GetTransform()->GetAnagle() -= 0.1f;
	}
	if (GetAsyncKeyState(VK_F2))
	{
		_bow->GetTransform()->GetAnagle() += 0.1f;
	}
    _transForm->UpdateWorldBuffer();
	
	_bow->Update();
	_bullet->Update();
	_arin->Update();
	

}

void Werpon::Render()
{ 
    _transForm->SetWorldBuffer(0);
	_bow->Render();
	_bullet->Render();
	_arin->Render();
	
}

void Werpon::Fire()
{
	if (_isActive == false)
		return;
	_bullet->_isActive = true;
	Vector2 fireVector = _bow->GetTransform()->GetEndPos() - _bow->GetTransform()->GetStartPos();
	_bullet->Fire(fireVector, _fireSpeed, _bow->GetTransform()->GetEndPos());
}

bool Werpon::BulletHit(shared_ptr<Arin> _arin)
{
	if (_isActive == false || _arin->_isActive == false)
		return false;

	return false;
}
