#pragma once
class Bullet
{
public:
	Bullet();
	~Bullet();
	void Update();
	void Render();
	void Fire(Vector2 vector, float speed, Vector2 startPos);
	bool IsCollision(shared_ptr<class Cannon> cannon);


	bool _isActive = true;
		shared_ptr<TransForm> GetTransform() { return _transForm; }
private:

	shared_ptr<TransForm> _transForm;
	shared_ptr<Texture> _bullet;
	shared_ptr<Texture> _bow;
	Vector2 _moveVector;
	float _gravity = 0.0f;
	
};