#include "framework.h"
#include "Bullet.h"

Bullet::Bullet()
    : _moveVector(0, 0)
{
    _bullet = make_shared<Texture>(L"Resource/BULLET.png");
}

Bullet::~Bullet()
{
}

void Bullet::Update()
{
    if (_isActive == false)
        return;
  
    _bullet->Update();
    _bullet->GetTransform()->GetCenter() += _moveVector * _gravity;
    _gravity += 0.98f;
}

void Bullet::Render()
{ 
    if (_isActive == false)
        return;
    _bullet->Render();
}

void Bullet::Fire(Vector2 vector, float speed, Vector2 startPos)
{
    if (_isActive == false)
        return;
    _gravity = 0.0f;
    _bullet->GetTransform()->GetCenter() = startPos;
	vector.Normallize();
	_moveVector = vector * speed * 3;
}

bool Bullet::IsCollision(shared_ptr<class Cannon> cannon)
{
    if (_isActive == false)
        return;
}
