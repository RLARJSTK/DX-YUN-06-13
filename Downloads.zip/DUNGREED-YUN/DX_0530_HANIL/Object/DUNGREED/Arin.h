#pragma once
class Arin
{
public:
	Arin();
	~Arin();
	void Update();
	void Render();


	bool _isActive = true;
	shared_ptr<TransForm> GetTransform() { return _transForm; }
private:
	
	shared_ptr<TransForm> _transForm;
	shared_ptr<Texture> _arin;
	shared_ptr<MatrixBuffer> _worldBuffer;
	XMFLOAT2 _worldPos = { 0,0 };
};