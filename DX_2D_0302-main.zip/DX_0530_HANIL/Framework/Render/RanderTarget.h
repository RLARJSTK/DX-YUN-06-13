#pragma once
class RanderTarget 
{
public:
	RanderTarget(float width,float height);
	~RanderTarget();
	void Set();

	Microsoft::WRL::ComPtr<ID3D11ShaderResourceView>GetSRV() { return _srv; }
	Microsoft::WRL::ComPtr<ID3D11RenderTargetView>GetRTV() { return _rtv; }


private:
	Microsoft::WRL::ComPtr<ID3D11ShaderResourceView>_srv;
	Microsoft::WRL::ComPtr<ID3D11Texture2D>_rtvtex;
	Microsoft::WRL::ComPtr<ID3D11RenderTargetView>_rtv;
	Microsoft::WRL::ComPtr<ID3D11Texture2D>_dsvtex;

};

