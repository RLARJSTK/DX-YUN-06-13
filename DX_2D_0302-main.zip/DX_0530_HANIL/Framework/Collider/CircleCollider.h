#pragma once
class CircleCollider
{
private:
	struct ObbDesc
	{
		Vector2 _position;
		Vector2 _direction[2];
		float _length[2];
	};

public:
	CircleCollider();
	~CircleCollider();

	void CreateData();

	void Update();
	void Render();



	ObbDesc GetObb();

	bool AABB(shared_ptr<CircleCollider> circle);
	bool OBB(shared_ptr<CircleCollider> circle);

	bool IsCollision(shared_ptr<CircleCollider> circle, bool obb = false);
	bool IsCollision(const Vector2& pos);

	float SepareateAxis(Vector2 separate, Vector2 e1, Vector2 e2);

	const Vector2& GetWorldPosition() { return _transform->GetWorldPos(); }
	Vector2& GetLocalPosition() { return _transform->GetPos(); }
	float& GetAngle() { return _transform->GetAngle(); }
	shared_ptr<Transform> GetTransform() { return _transform; }
	bool _isActive;
	bool _isCollision;

private:
	Vector2 _halfSize = { 0,0 };
	Vector2 _center;
	float _radius;
	float _originRadius;
	// Mesh
	vector<VertexPos> _vertices;
	shared_ptr<VertexBuffer> _vertexBuffer;

	shared_ptr<VertexShader> _vertexShader;
	shared_ptr<PixelShader> _pixelShader;

	// Collider �ʷϻ����� ���� ������ �Ǿ��ִ�.
	shared_ptr<ColorBuffer> _colorBuffer;

	shared_ptr<Transform> _parent;
	shared_ptr<Transform> _transform;
};

