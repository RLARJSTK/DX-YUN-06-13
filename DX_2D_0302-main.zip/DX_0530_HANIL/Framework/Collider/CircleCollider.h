#pragma once
class CircleCollider :public Collider
{
public:
	CircleCollider(float radius);
	~CircleCollider();



	void Update();
	void Render();

	bool IsCollision(const Vector2& pos);
	bool IsCollision(shared_ptr<CircleCollider> other);
	bool IsCollision(shared_ptr<class RectCollider> other, bool obb = false);

	float GetRadius() { return _radius * _transform->GetScale()._x; }

private:

	float _radius;
	void CreateData();
	
};

