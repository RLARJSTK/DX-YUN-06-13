#pragma once
class Collider
{
public:
	Collider();
	 ~Collider();
	 void Update();
	 void Render();

	void SetParent(shared_ptr<Transform> parent) { _parent = parent; }
	const Vector2& GetWorldPosition() { return _transform->GetWorldPos(); }
	Vector2& GetLocalPosition() { return _transform->GetPos(); }
	float& GetAngle() { return _transform->GetAngle(); }
	void SetRed() { _colorBuffer->SetColor(RED); }
	void SetGreen() { _colorBuffer->SetColor(GREEN); }
protected:
	Vector2 _center;
	virtual void CreateData();
	// Mesh
	vector<VertexPos> _vertices;
	shared_ptr<VertexBuffer> _vertexBuffer;

	shared_ptr<VertexShader> _vertexShader;
	shared_ptr<PixelShader> _pixelShader;

	// Collider �ʷϻ����� ���� ������ �Ǿ��ִ�.
	shared_ptr<ColorBuffer> _colorBuffer;

	shared_ptr<Transform> _parent;
	shared_ptr<Transform> _transform;
};

