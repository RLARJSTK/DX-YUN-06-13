#include "framework.h"
#include "Collider.h"

Collider::Collider()
{
}

Collider::~Collider()
{
}

void Collider::Update()
{
}

void Collider::Render()
{
}

void Collider::CreateData()
{
}
