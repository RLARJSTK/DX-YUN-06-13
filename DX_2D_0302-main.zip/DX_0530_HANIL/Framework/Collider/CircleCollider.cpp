#include "framework.h"
#include "CircleCollider.h"

CircleCollider::CircleCollider(float radius)
: _radius(radius)
{
	CreateData();
}

CircleCollider::~CircleCollider()
{
}

void CircleCollider::CreateData()
{
	VertexPos vertex;
	
	// ���� ����
	for (int i = 0; i < 37; i++)
	{
		float theta = PI * 2 / 36;
		vertex.pos.x = _radius * cosf(theta * i);
		vertex.pos.y = _radius * sinf(theta * i);
		vertex.pos.z = 0;

		_vertices.push_back(vertex);
	}

	//_vertexShader = make_shared<VertexShader>(L"Shaders/ColliderShader/ColliderVertexShader.hlsl");
	//_pixelShader = make_shared<PixelShader>(L"Shaders/ColliderShader/ColliderPixelShader.hlsl");
	//
	//_vertexBuffer = make_shared<VertexBuffer>(_vertices.data(), sizeof(VertexPos), _vertices.size());
	//_colorBuffer = make_shared<ColorBuffer>();
	//_colorBuffer->SetColor(GREEN);
	//
	//_transform = make_shared<Transform>();
	//_parent = nullptr;
}

void CircleCollider::Update()
{
	//_center = GetLocalPosition();
	//
	//_transform->UpdateWorldBuffer();
	//_colorBuffer->Update();
}

void CircleCollider::Render()
{
	//_transform->SetWorldBuffer(0);
	//_colorBuffer->SetPSBuffer(0);
	//
	//_vertexBuffer->IASet(0);
	//DEVICE_CONTEXT->IASetPrimitiveTopology(D3D_PRIMITIVE_TOPOLOGY_LINESTRIP);
	//
	//
	//_vertexShader->Set();
	//_pixelShader->PSSet();
	//
	//DEVICE_CONTEXT->Draw(_vertices.size(), 0);
}

bool CircleCollider::IsCollision(const Vector2& pos)
{
	float distance = _transform->GetWorldPos().Distance(pos);
	float radius = GetRadius();
	if (distance < GetRadius())
		return true;

	return false;
}

bool CircleCollider::IsCollision(shared_ptr<CircleCollider> other)
{
	Vector2 t = other->GetWorldPosition();
	Vector2 t2 = this->GetWorldPosition();
	Vector2 t3 = t2 - t;
	float distance = (t3).Length();
	if (distance < GetRadius() + other->GetRadius())
		return true;

	return false;
}

bool CircleCollider::IsCollision(shared_ptr<RectCollider> other, bool obb)
{
	return other->IsCollision(make_shared<CircleCollider>(*this), obb);
}
