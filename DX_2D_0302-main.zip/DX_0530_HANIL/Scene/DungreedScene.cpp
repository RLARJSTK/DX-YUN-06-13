#include "framework.h"
#include "DungreedScene.h"

DungreedScene::DungreedScene()
{
	_player = make_shared<Player>();
	_aim = make_shared<Texture>(L"Resource/aim.png");

	_rectCollider = make_shared<RectCollider>(Vector2{ 100.0f,100.0f });
}

DungreedScene::~DungreedScene()
{
}

void DungreedScene::Update()
{
	_player->Update();
	_aim->Update();

	_rectCollider->Update();

	_aim->GetTransform()->GetPos() = MOUSE_POS;
}

void DungreedScene::Render()
{
	_player->Render();
	_aim->Render();

	_rectCollider->Render();

	// Imgui
	ImGui::SliderFloat("ColliderPosX", &_rectCollider->GetLocalPosition()._x, 0, 1280);
	ImGui::SliderFloat("ColliderPosY", &_rectCollider->GetLocalPosition()._y, 0, 720);
}
