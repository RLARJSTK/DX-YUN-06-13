#include "framework.h"
#include "Scene.h"

Scene::Scene()
{
}

Scene::~Scene()
{
}
