#pragma once
class PantasmScene : public Scene
{
public:
	PantasmScene();
	virtual ~PantasmScene();

	// Scene��(��) ���� ��ӵ�
	virtual void Update() override;
	virtual void Render() override;
	virtual void PostRender() override;

private:
	shared_ptr<Challenger> _cha;

	Vector2 _loadPos = { 0,0 };
};