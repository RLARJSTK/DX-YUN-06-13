#pragma once
class CameraScene : public Scene
{
public:
	CameraScene();
	virtual ~CameraScene();

	virtual void Update() override;
	virtual void Render() override;
	virtual void PostRender() override;
	virtual void PreRender() override;

	void SavePos();
	void Test(int test);
	Vector2 LoadPos();

private:
	shared_ptr<Quad> _backGround;
	shared_ptr<Zelda> _zelda;
	shared_ptr<Transform> _zeldaFollowTrans;

	shared_ptr<Button> _button;
	shared_ptr<RanderTarget> _rtv;
	shared_ptr<Quad> _targetTextrue;


};