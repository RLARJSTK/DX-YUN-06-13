#include "framework.h"
#include "CameraScene.h"

CameraScene::CameraScene()
{
	_backGround = make_shared<Quad>(L"Resource/LostArk.png");

	_zelda = make_shared<Zelda>();

	_zeldaFollowTrans = make_shared<Transform>();
	Vector2 temp = this->LoadPos();
	_zelda->SetPostion(temp.x,temp.y);
	_zeldaFollowTrans->GetPos() = _zelda->GetTransform()->GetPos();

	Camera::GetInstance()->SetTarget(_zeldaFollowTrans);
	Vector2 leftBottom = { -_backGround->GetHalfSize().x, -_backGround->GetHalfSize().y };
	Vector2 rightTop = { _backGround->GetHalfSize().x, _backGround->GetHalfSize().y };
	Camera::GetInstance()->SetLeftBottom(leftBottom);
	Camera::GetInstance()->SetRightTop(rightTop);

	_button = make_shared<Button>();
	_button->SetScale(Vector2(0.1f, 0.1f));
	_button->SetPosition({ 100,WIN_HEIGHT - 100 });
	_button->SetText("Save");

	_button->SetEvent(std::bind(&CameraScene::SavePos,this));
	_button->SetEventParam(std::bind(&CameraScene::Test, this, placeholders::_1), 13);

	_rtv = make_shared<RanderTarget>(WIN_WIDTH,WIN_HEIGHT);
	_targetTextrue= make_shared<Quad>(L"Resource/LostArk.png");
	shared_ptr<Texture> texture = Texture::Add(L"Resource/LostArk.png", _rtv->GetSRV());
	_targetTextrue->GetTransform()->GetPos() = CENTER;
	_targetTextrue->GetTransform()->GetScale() *= 0.1f;
}

CameraScene::~CameraScene()
{
}

void CameraScene::Update()
{
	_backGround->Update();
	_zelda->Update();
	_targetTextrue->Update();
	

	float distance = _zelda->GetTransform()->GetPos().Distance(_zeldaFollowTrans->GetPos());
	if (distance >= 30.0f)
	{
		_zeldaFollowTrans->GetPos() = LERP(_zeldaFollowTrans->GetPos(), _zelda->GetTransform()->GetPos(), 0.001f);
	}

	_button->Update();
}

void CameraScene::Render()
{
	_backGround->Render();
	_zelda->Render();

}

void CameraScene::PostRender()
{
	_button->PostRender();
}

void CameraScene::PreRender()
{
	_rtv->Set();
	_targetTextrue->Render();
}

void CameraScene::SavePos()
{
	BinaryWriter writer(L"Save/ZeldaInfo.zelda");

	vector<float> dataes;

	dataes.push_back(_zelda->GetTransform()->GetPos().x);
	dataes.push_back(_zelda->GetTransform()->GetPos().y);

	writer.Uint(dataes.size());
	writer.Uint(dataes.size() * sizeof(float));
	writer.Byte(dataes.data(), sizeof(float) * dataes.size());
}

void CameraScene::Test(int test)
{
	int a = test;
}

Vector2 CameraScene::LoadPos()
{
	BinaryReader reader(L"Save/ZeldaInfo.zelda");

	UINT size = reader.Uint();
	UINT byteSize = reader.Uint();

	vector<float> dataes;
	dataes.resize(size);

	void* ptr = (void*)dataes.data();

	reader.Byte(&ptr, byteSize);

	Vector2 tempPos;

	if (dataes.size() == 0)
	{
		tempPos = { 0.0f,0.0f };
		return tempPos;
	}

	tempPos.x = dataes[0];
	tempPos.y = dataes[1];

	return tempPos;
}
