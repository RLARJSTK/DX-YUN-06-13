#pragma once
class DungreedScene : public Scene
{
public:
	DungreedScene();
	virtual ~DungreedScene();

	virtual void Update() override;
	virtual void Render() override;

private:
	shared_ptr<Player> _player;
	shared_ptr<Texture> _aim;

	shared_ptr<RectCollider> _rectCollider;

	float _guiTest = 0.0f;
};

