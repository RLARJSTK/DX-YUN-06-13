#include "framework.h"
#include "PantasmScene.h"

PantasmScene::PantasmScene()
{
	_cha = make_shared <Challenger >();
	_loadPos = { WIN_WIDTH * 0.5f, WIN_HEIGHT * 0.5f };
	_cha -> SetPostion(WIN_WIDTH * 0.5f, WIN_HEIGHT * 0.5f);
}

PantasmScene::~PantasmScene()
{
}

void PantasmScene::Update()
{
	_cha->Update();

	_cha->SetPostion(_loadPos.x, _loadPos.y);
}

void PantasmScene::Render()
{
	_cha->Render();
}

void PantasmScene::PostRender()
{
}

