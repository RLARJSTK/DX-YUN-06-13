#include "framework.h"
#include "ColliderScene.h"

ColliderScene::ColliderScene()
{
	//_rectCollider1 = make_shared<RectCollider>(Vector2(100, 50));
	//_rectCollider2 = make_shared<RectCollider>(Vector2(50, 100));
	//
	//_rectCollider2->GetLocalPosition() = Vector2(WIN_WIDTH * 0.5f, WIN_HEIGHT * 0.5f);
	_circleCollider1 = make_shared<CircleCollider>(75.0f);
	_circleCollider1->GetTransform()->GetPos() = { CENTER_X - 100,CENTER_Y - 200 };

}

ColliderScene::~ColliderScene()
{
}

void ColliderScene::Update()
{
	//_rectCollider1->IsCollision(_rectCollider2,true);
	//_rectCollider2->IsCollision(MOUSE_POS);
	//
	//_rectCollider1->Update();
	//_rectCollider2->Update();
	_circleCollider1->Update();
}

void ColliderScene::Render()
{
	_circleCollider1->Render();
	//_rectCollider1->Render();
	//_rectCollider2->Render();
}

void ColliderScene::PostRender()
{
	//ImGui::SliderFloat("Rect1 PosX", &_rectCollider1->GetLocalPosition()._x,0,WIN_WIDTH);
	//ImGui::SliderFloat("Rect1 PosY", &_rectCollider1->GetLocalPosition()._y,0,WIN_HEIGHT);
	//
	//ImGui::SliderFloat("Rect1 Angle", &_rectCollider1->GetAngle(),0,2 * PI);
}
