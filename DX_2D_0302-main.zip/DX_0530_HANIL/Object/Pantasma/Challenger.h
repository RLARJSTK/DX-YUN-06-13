#pragma once
class Challenger 
{
public:
	enum State
	{
		F_IDLE,
		L_IDLE,
		B_IDLE,
		R_IDLE,

		F_RUN,
		L_RUN,
		B_RUN,
		R_RUN,
	};
	Challenger();
	~Challenger();
	void CreateActions();

	void Update();
	void Render();
	void PostRender();

	void SetPostion(float x, float y);
	void SetAnimation(State aniState);
	void ChallengerMoveByKeyBoard();
	void SetIDLE();

	void SetMessage() { _message = "Right RUN!!!"; }

	shared_ptr<Transform> GetTransform() { return _sprite->GetTransform(); }

private:
	State _aniState = F_IDLE;

	Vector2 _loadPos = { 0,0 };
	shared_ptr<Sprite> _sprite;
	vector<shared_ptr<Action>> _act;
	shared_ptr<Collider> _coll;

	string _message = "Hello";

};



