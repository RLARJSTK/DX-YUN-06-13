#include "framework.h"
#include "Challenger.h"

Challenger::Challenger()
{
	_sprite = make_shared<Sprite>(L"Resource/challenger.png", Vector2(10, 8));
	_sprite->GetTransform()->GetPos() = Vector2(WIN_WIDTH, WIN_HEIGHT) * 0.5f;
	_coll = make_shared<RectCollider>(_sprite->GetHalfFrameSize());
	_coll->SetParent(_sprite->GetTransform());

	CreateActions();
}

Challenger::~Challenger()
{
	_act.reserve(8);

	// Action ����
	{
		vector<Action::Clip> clips;
		float w = 1200.0f / 10.0f;
		float h = 1040.0f / 8.0f;

		// �� ������
		float y = 0;
		{
			clips.emplace_back(0, y, w, h, Texture::Add(L"Resource/challenger.png"));
			clips.emplace_back(0 + w, y, w, h, Texture::Add(L"Resource/challenger.png"));
			clips.emplace_back(0 + w * 2, y, w, h, Texture::Add(L"Resource/challenger.png"));
		}
		_act.push_back(make_shared<Action>(clips, "F_IDLE"));
		clips.clear();

		// �� ������
		y = 1040.0f * (1.0f / 8.0f);
		{
			clips.emplace_back(0, y, w, h, Texture::Add(L"Resource/challenger.png"));
			clips.emplace_back(0 + w, y, w, h, Texture::Add(L"Resource/challenger.png"));
			clips.emplace_back(0 + w * 2, y, w, h, Texture::Add(L"Resource/challenger.png"));
		}
		_act.push_back(make_shared<Action>(clips, "L_IDLE"));
		clips.clear();

		// �� ������
		y = 1040.0f * (2.0f / 8.0f);
		{
			clips.emplace_back(0, y, w, h, Texture::Add(L"Resource/challenger.png"));
		}
		_act.push_back(make_shared<Action>(clips, "B_IDLE"));
		clips.clear();

		// �� ������
		y = 1040.0f * (3.0f / 8.0f);
		{
			clips.emplace_back(0, y, w, h, Texture::Add(L"Resource/challenger.png"));
			clips.emplace_back(0 + w, y, w, h, Texture::Add(L"Resource/challenger.png"));
			clips.emplace_back(0 + w * 2, y, w, h, Texture::Add(L"Resource/challenger.png"));
		}
		shared_ptr<Action> rightIDLE = make_shared<Action>(clips, "R_IDLE");
		_act.push_back(rightIDLE);
		clips.clear();

		y = 1040 * 0.5f;
		// ������ �޸���
		{
			clips.emplace_back(0, y, w, h, Texture::Add(L"Resource/challenger.png"));
			clips.emplace_back(0 + w, y, w, h, Texture::Add(L"Resource/challenger.png"));
			clips.emplace_back(0 + w * 2, y, w, h, Texture::Add(L"Resource/challenger.png"));
			clips.emplace_back(0 + w * 3, y, w, h, Texture::Add(L"Resource/challenger.png"));
			clips.emplace_back(0 + w * 4, y, w, h, Texture::Add(L"Resource/challenger.png"));
			clips.emplace_back(0 + w * 5, y, w, h, Texture::Add(L"Resource/challenger.png"));
			clips.emplace_back(0 + w * 6, y, w, h, Texture::Add(L"Resource/challenger.png"));
			clips.emplace_back(0 + w * 7, y, w, h, Texture::Add(L"Resource/challenger.png"));
			clips.emplace_back(0 + w * 8, y, w, h, Texture::Add(L"Resource/challenger.png"));
			clips.emplace_back(0 + w * 9, y, w, h, Texture::Add(L"Resource/challenger.png"));
		}
		_act.push_back(make_shared<Action>(clips, "F_RUN"));
		clips.clear();

		y = 1040 * (5.0f / 8.0f);
		// ������ �޸���
		{
			clips.emplace_back(0, y, w, h, Texture::Add(L"Resource/challenger.png"));
			clips.emplace_back(0 + w, y, w, h, Texture::Add(L"Resource/challenger.png"));
			clips.emplace_back(0 + w * 2, y, w, h, Texture::Add(L"Resource/challenger.png"));
			clips.emplace_back(0 + w * 3, y, w, h, Texture::Add(L"Resource/challenger.png"));
			clips.emplace_back(0 + w * 4, y, w, h, Texture::Add(L"Resource/challenger.png"));
			clips.emplace_back(0 + w * 5, y, w, h, Texture::Add(L"Resource/challenger.png"));
			clips.emplace_back(0 + w * 6, y, w, h, Texture::Add(L"Resource/challenger.png"));
			clips.emplace_back(0 + w * 7, y, w, h, Texture::Add(L"Resource/challenger.png"));
			clips.emplace_back(0 + w * 8, y, w, h, Texture::Add(L"Resource/challenger.png"));
			clips.emplace_back(0 + w * 9, y, w, h, Texture::Add(L"Resource/challenger.png"));
		}
		_act.push_back(make_shared<Action>(clips, "L_RUN"));
		clips.clear();

		y = 1040 * (6.0f / 8.0f);
		// �ڷ� �޸���
		{
			clips.emplace_back(0, y, w, h, Texture::Add(L"Resource/challenger.png"));
			clips.emplace_back(0 + w, y, w, h, Texture::Add(L"Resource/challenger.png"));
			clips.emplace_back(0 + w * 2, y, w, h, Texture::Add(L"Resource/challenger.png"));
			clips.emplace_back(0 + w * 3, y, w, h, Texture::Add(L"Resource/challenger.png"));
			clips.emplace_back(0 + w * 4, y, w, h, Texture::Add(L"Resource/challenger.png"));
			clips.emplace_back(0 + w * 5, y, w, h, Texture::Add(L"Resource/challenger.png"));
			clips.emplace_back(0 + w * 6, y, w, h, Texture::Add(L"Resource/challenger.png"));
			clips.emplace_back(0 + w * 7, y, w, h, Texture::Add(L"Resource/challenger.png"));
			clips.emplace_back(0 + w * 8, y, w, h, Texture::Add(L"Resource/challenger.png"));
			clips.emplace_back(0 + w * 9, y, w, h, Texture::Add(L"Resource/challenger.png"));
		}
		_act.push_back(make_shared<Action>(clips, "B_RUN"));
		clips.clear();

		y = 1040 * (7.0f / 8.0f);
		// ���� �޸���
		{
			clips.emplace_back(0, y, w, h, Texture::Add(L"Resource/challenger.png"));
			clips.emplace_back(0 + w, y, w, h, Texture::Add(L"Resource/challenger.png"));
			clips.emplace_back(0 + w * 2, y, w, h, Texture::Add(L"Resource/challenger.png"));
			clips.emplace_back(0 + w * 3, y, w, h, Texture::Add(L"Resource/challenger.png"));
			clips.emplace_back(0 + w * 4, y, w, h, Texture::Add(L"Resource/challenger.png"));
			clips.emplace_back(0 + w * 5, y, w, h, Texture::Add(L"Resource/challenger.png"));
			clips.emplace_back(0 + w * 6, y, w, h, Texture::Add(L"Resource/challenger.png"));
			clips.emplace_back(0 + w * 7, y, w, h, Texture::Add(L"Resource/challenger.png"));
			clips.emplace_back(0 + w * 8, y, w, h, Texture::Add(L"Resource/challenger.png"));
			clips.emplace_back(0 + w * 9, y, w, h, Texture::Add(L"Resource/challenger.png"));
		}
		shared_ptr<Action> rightRUN = make_shared<Action>(clips, "R_RUN");
		// ��¥ �߿�
		//rightRUN->SetEndEvent(std::bind(&Zelda::SetMessage, this));
		_act.push_back(rightRUN);
		clips.clear();

	}

	for (auto& action : _act)
		action->Pause();

	_act[_aniState]->Play();
}

void Challenger::CreateActions()
{
}

void Challenger::Update()
{
	_sprite->Update();
	_coll->Update();

	ChallengerMoveByKeyBoard();

	for (auto& action : _act)
	{
		action->Update();
		if (!action->IsPlay())
			continue;
		_sprite->SetClipToActionBuffer(action->GetCurClip());
	}
}

void Challenger::Render()
{
	_sprite->Render();

}

void Challenger::PostRender()
{
	ImGui::Text(_message.data());

	_coll->Render();
}

void Challenger::SetPostion(float x, float y)
{
	_sprite->GetTransform()->GetPos() = { x,y };
	_loadPos = { x,y };
}

void Challenger::SetAnimation(State aniState)
{
	if (_act[aniState]->IsPlay() && _act[aniState]->GetAnimType() == Action::LOOP)
		return;

	for (auto& action : _act)
	{
		if (action->IsPlay() && _aniState == aniState)
			continue;

		action->Reset();
	}

	_act[aniState]->Play();
	_aniState = aniState;
}

void Challenger::ChallengerMoveByKeyBoard()
{
	this->SetPostion(_loadPos.x, _loadPos.y);

	if (KEY_PRESS('W'))
	{
		_loadPos.y += 150 * DELTA_TIME;
		this->SetAnimation(Challenger::State::B_RUN);

		return;
	}

	if (KEY_PRESS('A'))
	{
		_loadPos.x -= 150 * DELTA_TIME;
		this->SetAnimation(Challenger::State::L_RUN);

		return;
	}

	if (KEY_PRESS('S'))
	{
		_loadPos.y -= 150 * DELTA_TIME;
		this->SetAnimation(Challenger::State::F_RUN);

		return;
	}

	if (KEY_PRESS('D'))
	{
		_loadPos.x += 150 * DELTA_TIME;
		this->SetAnimation(Challenger::State::R_RUN);

		return;
	}

	SetIDLE();
}



void Challenger::SetIDLE()
{
	switch (_aniState)
	{
	case Challenger::F_RUN:
		SetAnimation(State::F_IDLE);
		break;
	case Challenger::L_RUN:
		SetAnimation(State::L_IDLE);
		break;
	case Challenger::B_RUN:
		SetAnimation(State::B_IDLE);
		break;
	case Challenger::R_RUN:
		SetAnimation(State::R_IDLE);
		break;
	default:
		break;
	}
}
