#include "framework.h"
#include "Player.h"

Player::Player()
{
	_texture = make_shared<Texture>(L"Resource/player.png");
	_texture->GetTransform()->GetScale() = { 0.5f,0.5f };

	_gunTrans = make_shared<Transform>();
	_gunTrans->SetParent(_texture->GetTransform());
	_gunTrans->GetPos()._x = 150;

	_gun = make_shared<Gun>();
	_gun->SetPlayer(_gunTrans);

	_bullets.reserve(30);
	for (int i = 0; i < _poolCount; i++)
	{
		shared_ptr<Bullet> bullet = make_shared<Bullet>();
		bullet->isActive = false;
		_bullets.push_back(bullet);
	}
}

Player::~Player()
{
}

void Player::Update()
{
	Move();
	Aiming();
	Fire();

	_texture->Update();
	_gunTrans->UpdateWorldBuffer();

	_gun->Update();

	for (auto& bullet : _bullets)
	{
		bullet->Update();
	}
}

void Player::Render()
{
	_texture->Render();

	_gun->Render();

	for (auto& bullet : _bullets)
	{
		bullet->Render();
	}
}

void Player::Move()
{
	if (KEY_PRESS('W'))
	{
		_texture->GetTransform()->GetPos()._y += 100.0f * DELTA_TIME;
	}
	if (KEY_PRESS('S'))
	{
		_texture->GetTransform()->GetPos()._y -= 100.0f * DELTA_TIME;
	}
	if (KEY_PRESS('A'))
	{
		_texture->GetTransform()->GetPos()._x -= 100.0f * DELTA_TIME;
	}
	if (KEY_PRESS('D'))
	{
		_texture->GetTransform()->GetPos()._x += 100.0f * DELTA_TIME;
	}
}

void Player::Aiming()
{
	Vector2 v = MOUSE_POS - _gunTrans->GetWorldPos();
	float angle = v.Angle();

	_gunTrans->GetAngle() = angle;
}

void Player::Fire()
{
	if (KEY_DOWN(VK_LBUTTON))
	{
		Vector2 v = MOUSE_POS - _gunTrans->GetWorldPos();
		v.Normallize();

		for (auto& bullet : _bullets)
		{
			if (bullet->isActive == false)
			{
				bullet->SetDirection(v);
				bullet->SetPosition(_gunTrans->GetWorldPos());
				bullet->isActive = true;
				break;
			}
		}
	}
}
