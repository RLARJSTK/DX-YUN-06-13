#include "framework.h"
#include "Enemy.h"

Enemy::Enemy()
{
	_quad = make_shared<Quad>(L"Resource/enemy.png");
	_quad->GetTransform()->GetScale() = { 0.5f,0.5f };

	_col = make_shared<RectCollider>(_quad->GetHalfSize());
	_col->SetParent(_quad->GetTransform());
}

Enemy::~Enemy()
{
}

void Enemy::Update()
{
	_quad->Update();
	_col->Update();
}

void Enemy::Render()
{
	_quad->Render();
	_col->Render();
}
