#pragma once
class TextureWVPScene : public Scene
{
public:
	TextureWVPScene(); 
	virtual ~TextureWVPScene(); 
	
	// Scene��(��) ���� ��ӵ�
	virtual void Update() override;
	virtual void Render() override;

private:
	shared_ptr<Texture> _texture;
	XMFLOAT2 _scale = { 1,1 };
	XMFLOAT2 _pos = { 0,0 };
	XMMATRIX _srt_matrix;
	shared_ptr<MatrixBuffer> _worldBuffer;
	XMFLOAT2 _worldPos = { 0,0 };

	shared_ptr<MatrixBuffer> _viewBuffer;
	XMFLOAT2 _cameraPos = { 0,0 };
	float _angle = { 0.0f };

	shared_ptr<MatrixBuffer> _projectionBuffer;
};

